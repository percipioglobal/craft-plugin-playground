--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.commerce_orderhistories DROP CONSTRAINT IF EXISTS fk_zoqodqekmfnrxukizczvmkaspyrshlkxfjmx;
ALTER TABLE IF EXISTS ONLY public.shunnedmessages DROP CONSTRAINT IF EXISTS fk_zmytnqzwxvwyxlalwmuzfihwzzfwiakuzkrw;
ALTER TABLE IF EXISTS ONLY public.commerce_products DROP CONSTRAINT IF EXISTS fk_zhzomzhhqamzcudcgpyabwwqyasanhadcixx;
ALTER TABLE IF EXISTS ONLY public.fieldlayouttabs DROP CONSTRAINT IF EXISTS fk_zgmmkwatoyerbkmsbjqmbhmshbqkfxpsnknc;
ALTER TABLE IF EXISTS ONLY public.structureelements DROP CONSTRAINT IF EXISTS fk_zgcnsikamldxpcfakavjqxdepiimfvrylzbn;
ALTER TABLE IF EXISTS ONLY public.content DROP CONSTRAINT IF EXISTS fk_zfktpyropeyfmwjohmdnbncuptamnexjuelw;
ALTER TABLE IF EXISTS ONLY public.commerce_taxzone_states DROP CONSTRAINT IF EXISTS fk_ywbfahqrzqbtxhdndfmltmglvmomgplbjeqp;
ALTER TABLE IF EXISTS ONLY public.userpermissions_usergroups DROP CONSTRAINT IF EXISTS fk_yqulmbimpxudzmyrwaoegvybemclvkboyogy;
ALTER TABLE IF EXISTS ONLY public.categorygroups DROP CONSTRAINT IF EXISTS fk_yolklpaershtaaglydqfjprdujlgpeehciwl;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fk_yitauxmmtnuwiwvwzwqgwvxkvwzkbxqwwuzv;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingzone_countries DROP CONSTRAINT IF EXISTS fk_yfuwplypuzwybvggselnynigntfskklmwwwt;
ALTER TABLE IF EXISTS ONLY public.templatecacheelements DROP CONSTRAINT IF EXISTS fk_ydmzllmuzdeekqicibyduyatadmcibdeupiv;
ALTER TABLE IF EXISTS ONLY public.structureelements DROP CONSTRAINT IF EXISTS fk_ycmfqrjvmukoeqemsuzdtxarsfbktxvdalkj;
ALTER TABLE IF EXISTS ONLY public.userpermissions_users DROP CONSTRAINT IF EXISTS fk_ycfpbpyxrjseuzhfwavvqdrhrqizgylimgjc;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_ybetntyltxnhvzlvszelynyvomwezazlgdbs;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_yazytdfmchonrcycbcgihezkqnrosanusqai;
ALTER TABLE IF EXISTS ONLY public.elements_sites DROP CONSTRAINT IF EXISTS fk_yazgezehqickjsziauckasmcuawxugrtngma;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS fk_xuaecucojibdspbhpblagfegjhmupsjsryam;
ALTER TABLE IF EXISTS ONLY public.commerce_subscriptions DROP CONSTRAINT IF EXISTS fk_xtkmvflcclrxanaysntrvvhwldshliywgdbw;
ALTER TABLE IF EXISTS ONLY public.commerce_taxzone_countries DROP CONSTRAINT IF EXISTS fk_xseqvwupygzzlgyzidghtsbwlamffliidcpk;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_wwkgjkrgpvwizznwnnewxkqffbxlvesyyarq;
ALTER TABLE IF EXISTS ONLY public.commerce_customer_discountuses DROP CONSTRAINT IF EXISTS fk_wtryfwtrhislfmholtvytujqpcgmkvvstnun;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_taxcategories DROP CONSTRAINT IF EXISTS fk_wqcyyvjaffbvgbjyehhbeqcfemvggvorzclq;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingzone_states DROP CONSTRAINT IF EXISTS fk_wphsueehprkhmyfdqxngaizfeuvmvmvouodl;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_categories DROP CONSTRAINT IF EXISTS fk_wngjmzrwdhmbwvvznsyffnmehiflagjtpweu;
ALTER TABLE IF EXISTS ONLY public.commerce_transactions DROP CONSTRAINT IF EXISTS fk_wmxshmafawkzckrvtgsrmhcobolnlnxrongb;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fk_whftarriaittdruyuvtvaakunjwzayxatjwc;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_wdgjmspxcaguulajfwnpiiayweefcjntndff;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_wczcrgfcvdtvxiqcwbuqduiekbdepxlyelbg;
ALTER TABLE IF EXISTS ONLY public.commerce_donations DROP CONSTRAINT IF EXISTS fk_wcgoomxirjhhtovawqvixbrlhtrpidilwoea;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fk_vyjoaswidmyesgqpfcxcvrqglvuqxzhujqzu;
ALTER TABLE IF EXISTS ONLY public.commerce_variants DROP CONSTRAINT IF EXISTS fk_vvcndfnmwagipzozjwgazahvitutucfzerhx;
ALTER TABLE IF EXISTS ONLY public.gqltokens DROP CONSTRAINT IF EXISTS fk_vkvlviiwvndcsefqtzuoiqaryjgvzqjrxcun;
ALTER TABLE IF EXISTS ONLY public.commerce_paymentsources DROP CONSTRAINT IF EXISTS fk_vjgnsbcnqyitnmrzgjksudfzjulmpaptbyhw;
ALTER TABLE IF EXISTS ONLY public.drafts DROP CONSTRAINT IF EXISTS fk_vjfzebffuevnmwcuftbrlessixdmxznqincq;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingzone_countries DROP CONSTRAINT IF EXISTS fk_vfcjzeigahwkcsdiznepaqgttswuaorjlxxz;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingrule_categories DROP CONSTRAINT IF EXISTS fk_uzzvqfirraecrsjnwxdwsddtvovhtvmfxwbw;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_uwspafvvdmapcpedznzpdhewdisftenrimqj;
ALTER TABLE IF EXISTS ONLY public.commerce_subscriptions DROP CONSTRAINT IF EXISTS fk_uucznzsqflipvyewxtyczedkuwvxfbgzumls;
ALTER TABLE IF EXISTS ONLY public.assetindexdata DROP CONSTRAINT IF EXISTS fk_usikblbmsghhumhrvtvseafvrrvmxhpzumpw;
ALTER TABLE IF EXISTS ONLY public.categorygroups_sites DROP CONSTRAINT IF EXISTS fk_uqapugytroxucxuoajsjndcpdjcarlvevgdq;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_unkajiuadccacytxlgjabzfcqoksfwmojnnd;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fk_ukpxsfnerzuibcpnlgxviuexctytfuupuhzt;
ALTER TABLE IF EXISTS ONLY public.userpermissions_users DROP CONSTRAINT IF EXISTS fk_uiymkzvvrmprdqgtznecusmojqkandzholai;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_uacaclprlcoxnhmotwwrajyeesmwrunvfqyy;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_categories DROP CONSTRAINT IF EXISTS fk_txmojydogibkubdzxpjltpvcxidrqclafikq;
ALTER TABLE IF EXISTS ONLY public.commerce_taxrates DROP CONSTRAINT IF EXISTS fk_tobrfkbgtqgzoexewtmqrtqaukcfpdyqdreo;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_sites DROP CONSTRAINT IF EXISTS fk_tmybzuncpsjxptlncqcucyhvafdchaxrmvfo;
ALTER TABLE IF EXISTS ONLY public.commerce_emails DROP CONSTRAINT IF EXISTS fk_tdxdzebexebdjywgcpzbrsgkoxklmwfvdixl;
ALTER TABLE IF EXISTS ONLY public.usergroups_users DROP CONSTRAINT IF EXISTS fk_tblbjnbtkediapdbaztdebojofnkiretntvl;
ALTER TABLE IF EXISTS ONLY public.commerce_subscriptions DROP CONSTRAINT IF EXISTS fk_srtkisydkrdowzjgdsakxwivybiulteddvmw;
ALTER TABLE IF EXISTS ONLY public.commerce_customers DROP CONSTRAINT IF EXISTS fk_rrwfcpbwiggmrpdwsjtohcftcygtdnevixcr;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_rpnkophnczddnocvormwqkrdkfzuraszxdbx;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_rbpmceytubfouwgueqvpqixikrazlemtsleq;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS fk_qzieetwqqbjjpexjonmghimgvzasqkjdrowg;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_shippingcategories DROP CONSTRAINT IF EXISTS fk_qvsjyqgsywqopnbhjkiwaqcbirehtcduyqna;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_usergroups DROP CONSTRAINT IF EXISTS fk_qvjhtzohxnjjyuxvcukbdewlylpyvrhkzswb;
ALTER TABLE IF EXISTS ONLY public.fields DROP CONSTRAINT IF EXISTS fk_qrbrttegfrazrbihemawpspoiodcjmrubdbr;
ALTER TABLE IF EXISTS ONLY public.templatecaches DROP CONSTRAINT IF EXISTS fk_qphihgnecgrwdvxoffndjnquxntyauuowivq;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_usergroups DROP CONSTRAINT IF EXISTS fk_qobbdlalhkyauyuuireriivjsncsbkrojxmf;
ALTER TABLE IF EXISTS ONLY public.entrytypes DROP CONSTRAINT IF EXISTS fk_qgjmuniermdubmgrusprqqasnpzccibdgnpg;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_pypiirbrwykotzhvobizivhqzibzulyujadh;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_sites DROP CONSTRAINT IF EXISTS fk_psdzohfjqzxuhaguetanbqbgyasirdpdqnkg;
ALTER TABLE IF EXISTS ONLY public.sections_sites DROP CONSTRAINT IF EXISTS fk_ppbsgtvnlzvkcywesqzyqjpqwhesmgncihpy;
ALTER TABLE IF EXISTS ONLY public.commerce_products DROP CONSTRAINT IF EXISTS fk_poczrokpjiczhtbotqemlmqvacgeyvdbvfan;
ALTER TABLE IF EXISTS ONLY public.matrixblocktypes DROP CONSTRAINT IF EXISTS fk_pjmkygolxfdcvthjxrdjtluckbpoahtywwcx;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_phzzzasfcazktgobzsppyygcmhgpdhdetgdm;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_pfhgrtmyuzovolnivsxpfuvaxjpudvdvyzrr;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS fk_oxxypvaalxiywstbnbodgcfcobscwijnbozl;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_owjzpiguwgikpjzveslrcyqvycbpnnykoomn;
ALTER TABLE IF EXISTS ONLY public.craftidtokens DROP CONSTRAINT IF EXISTS fk_ovytnsnwdcmjrzcsrifqhvorytvlyxvomilg;
ALTER TABLE IF EXISTS ONLY public.commerce_customers DROP CONSTRAINT IF EXISTS fk_ouwsplykiudgkdumolgolgegmmrctnympzbo;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_purchasables DROP CONSTRAINT IF EXISTS fk_otgcmsyqrznnnqzfxzkmxmkccwvazkuxkmqs;
ALTER TABLE IF EXISTS ONLY public.globalsets DROP CONSTRAINT IF EXISTS fk_oryyniaekcvinsozexsabdwngvytgadnfzrq;
ALTER TABLE IF EXISTS ONLY public.commerce_taxrates DROP CONSTRAINT IF EXISTS fk_oprsbrebmsbyxwzfbmmohkdpbsnazjtqmssl;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS fk_omfmbudyfyhvftclwrflvevjjjkhcajvreut;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_ojrlnoxsziehjsxlwrfyysswfnbldhfmpoqb;
ALTER TABLE IF EXISTS ONLY public.globalsets DROP CONSTRAINT IF EXISTS fk_ogdylokqoylyddcujmdzakfzbrdzltuzpwrg;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_usergroups DROP CONSTRAINT IF EXISTS fk_obwtyrbtpzwectmtaobyqvqhjdvuxouyrcld;
ALTER TABLE IF EXISTS ONLY public.commerce_variants DROP CONSTRAINT IF EXISTS fk_nzhsulufsfbzxomrsmskpgkvpbsckcqfiuwj;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS fk_nzehdwtxfhfwsaqgynbygyjdfztgzllilhkd;
ALTER TABLE IF EXISTS ONLY public.commerce_paymentsources DROP CONSTRAINT IF EXISTS fk_nynvvrshkdbeggkggxdiwdligxijmoemowcd;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingrules DROP CONSTRAINT IF EXISTS fk_nthunomqjpqrqpguyrwzzqcqczutsuuqrpdb;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_nrrdiueuhgzxtekzikcwrycymitvndawmdrd;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_usergroups DROP CONSTRAINT IF EXISTS fk_njednqwwqxpcsniopaavbtjudrqjaqylpoqf;
ALTER TABLE IF EXISTS ONLY public.commerce_customer_discountuses DROP CONSTRAINT IF EXISTS fk_nfqgesvmmtnxyyuqioguemkrrgqlhatgpppz;
ALTER TABLE IF EXISTS ONLY public.commerce_customers_addresses DROP CONSTRAINT IF EXISTS fk_nfidazuslptrablqmxwbndiheprckmmsngkw;
ALTER TABLE IF EXISTS ONLY public.commerce_taxzone_countries DROP CONSTRAINT IF EXISTS fk_mxlrudcpixcgsyflxetuwopeepxkmgqvpmcy;
ALTER TABLE IF EXISTS ONLY public.commerce_purchasables DROP CONSTRAINT IF EXISTS fk_mqawjvsalsbcmayqacqirtptgwrouwjhpwxq;
ALTER TABLE IF EXISTS ONLY public.commerce_orderhistories DROP CONSTRAINT IF EXISTS fk_mnnwtyclnbeyymbbrbgpwcjwejmwehfcojko;
ALTER TABLE IF EXISTS ONLY public.commerce_subscriptions DROP CONSTRAINT IF EXISTS fk_mixoikxypmrrngeropmreetlnbwrkifwmcyc;
ALTER TABLE IF EXISTS ONLY public.commerce_addresses DROP CONSTRAINT IF EXISTS fk_mhgrggnsypidyaqephacydxekbyfhmusdale;
ALTER TABLE IF EXISTS ONLY public.commerce_plans DROP CONSTRAINT IF EXISTS fk_lzxjarxgeaswatxvmvmaxvpbneoygwlvkito;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS fk_lxtitebyqvrghmuskchakjmchejvbgaiaxgj;
ALTER TABLE IF EXISTS ONLY public.volumefolders DROP CONSTRAINT IF EXISTS fk_lowfilqtyknwtiglaztplxcwhaxcbrexwudo;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_categories DROP CONSTRAINT IF EXISTS fk_lldpcflccowawihanxkiiawasripexhoonvk;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_shippingcategories DROP CONSTRAINT IF EXISTS fk_lganxxedadmjwfedtsttsmthwwmobjvpsfox;
ALTER TABLE IF EXISTS ONLY public.commerce_email_discountuses DROP CONSTRAINT IF EXISTS fk_lamxnjvafmnxjhphklpxhxosvfrpukgvnycj;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingzone_states DROP CONSTRAINT IF EXISTS fk_kzrpcdqlvnyeipcnvlvdzkfvwinzcdfnjtjc;
ALTER TABLE IF EXISTS ONLY public.commerce_orderstatus_emails DROP CONSTRAINT IF EXISTS fk_kwtmclqojbcdcpfufbmukcusjolzgqtjgvmy;
ALTER TABLE IF EXISTS ONLY public.commerce_orderhistories DROP CONSTRAINT IF EXISTS fk_ktegpncvwbjpltwaxzugcapiibcmuwwpdafv;
ALTER TABLE IF EXISTS ONLY public.drafts DROP CONSTRAINT IF EXISTS fk_krqilftiftzlmfjsftkcahppldhvfyoyfhga;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingrule_categories DROP CONSTRAINT IF EXISTS fk_klleobhmxetqmgquaecovcujdaxloreyabcb;
ALTER TABLE IF EXISTS ONLY public.userpreferences DROP CONSTRAINT IF EXISTS fk_kjypmgdrnirmrxdqztjhdpffgcytxuhrngma;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_kjpskunohsohggrmjbbxldximbzfchqxkjua;
ALTER TABLE IF EXISTS ONLY public.commerce_lineitems DROP CONSTRAINT IF EXISTS fk_jypvvjjnotneeqqkyonlhqcyhxglahzoanys;
ALTER TABLE IF EXISTS ONLY public.sections DROP CONSTRAINT IF EXISTS fk_jselgxbbpwgjecdmawqlepafwaawkoqopetw;
ALTER TABLE IF EXISTS ONLY public.commerce_customers DROP CONSTRAINT IF EXISTS fk_jpxjqurnkwvqpoadpkyjyusgqwtbussffdmu;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS fk_jjseedhwpbvxlnywkoaseemsybghspkorbih;
ALTER TABLE IF EXISTS ONLY public.commerce_transactions DROP CONSTRAINT IF EXISTS fk_jjlwvskbjtvtkgawpckdzyqvtumlkmrrsxab;
ALTER TABLE IF EXISTS ONLY public.commerce_customers_addresses DROP CONSTRAINT IF EXISTS fk_jevtjnhebcvcbdpzphpxwpgytuptwxevkwmm;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_jehjjxybmpyaknxflepsgotydenphiclzzww;
ALTER TABLE IF EXISTS ONLY public.commerce_subscriptions DROP CONSTRAINT IF EXISTS fk_jayhyvpmjehooqsavksuxnpswcyskcaydxct;
ALTER TABLE IF EXISTS ONLY public.content DROP CONSTRAINT IF EXISTS fk_itwkpifhrypitgjqntfxyczmcmyrfhgyyvmd;
ALTER TABLE IF EXISTS ONLY public.commerce_addresses DROP CONSTRAINT IF EXISTS fk_invewoxhrrodemfpfeygzpxoxywxpglxnucm;
ALTER TABLE IF EXISTS ONLY public.elements_sites DROP CONSTRAINT IF EXISTS fk_imuyfgkkupfoyyeskijpskbqrqchqqqzcbso;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes DROP CONSTRAINT IF EXISTS fk_iinztdpfbsqcauntlpugezfpphjaddcrrkbt;
ALTER TABLE IF EXISTS ONLY public.commerce_lineitems DROP CONSTRAINT IF EXISTS fk_ibjldchdrevnwvgdpngivaozeevjakgxbvwk;
ALTER TABLE IF EXISTS ONLY public.entrytypes DROP CONSTRAINT IF EXISTS fk_hwoweujuyowcvdujyhegqhumsamsfpkduyal;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_hshdlicugirhtidtswvwmpxulglmsqnbejfp;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_hrlmnvkeokqgemfsmemjtwayavqsoyzgujln;
ALTER TABLE IF EXISTS ONLY public.commerce_transactions DROP CONSTRAINT IF EXISTS fk_hpvfqluevhgbtdgbyqsdvxbsocudroqtlmss;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_purchasables DROP CONSTRAINT IF EXISTS fk_hoffcvenhgkjqphittqhvwxpginqitstfufl;
ALTER TABLE IF EXISTS ONLY public.commerce_orderhistories DROP CONSTRAINT IF EXISTS fk_himbsabwyqkpnfflhqwpsbbvxoealdshgegt;
ALTER TABLE IF EXISTS ONLY public.sections_sites DROP CONSTRAINT IF EXISTS fk_hbddztvxpjokcjrfujgzmpdvauxtnkjuxvoc;
ALTER TABLE IF EXISTS ONLY public.commerce_orderstatus_emails DROP CONSTRAINT IF EXISTS fk_hagysabttydfugwwjangxlihjokbpwpdrfto;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_gznynmxvrhcqvdfphatgspbkduxyzmbtasbi;
ALTER TABLE IF EXISTS ONLY public.categorygroups_sites DROP CONSTRAINT IF EXISTS fk_gyutpopgtaaqingdvcgcfmrhlzznpbjvvcua;
ALTER TABLE IF EXISTS ONLY public.commerce_transactions DROP CONSTRAINT IF EXISTS fk_ggijmtqswancldbfvlshogavfzpnacrsqkuq;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_fyvnujmjatlukvdxdlhgdootvrbcsjodadgt;
ALTER TABLE IF EXISTS ONLY public.usergroups_users DROP CONSTRAINT IF EXISTS fk_fvcedqiogpwqhkcnrfslrxwuppviaqfrwsge;
ALTER TABLE IF EXISTS ONLY public.commerce_plans DROP CONSTRAINT IF EXISTS fk_fbdheoqedxrirelolmdzecbwayfmjdbpwcym;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_ewzbndystyuncxsfzemxoeukpwnrnsdrzikx;
ALTER TABLE IF EXISTS ONLY public.commerce_lineitems DROP CONSTRAINT IF EXISTS fk_eumuwfwseqfmzjzjthccguwgiccidnrxwcla;
ALTER TABLE IF EXISTS ONLY public.volumefolders DROP CONSTRAINT IF EXISTS fk_erkezfmmaweyijmffzroookhgxeqvqqoennm;
ALTER TABLE IF EXISTS ONLY public.revisions DROP CONSTRAINT IF EXISTS fk_eqywjdtxlsckxykjhqxrmeqpqofwdetfdthq;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS fk_enmhxzjvdnallfrjxfxfgmgpldwigpxikzjv;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_emhmsvpvioooucrgsoyycisowmoilrretrng;
ALTER TABLE IF EXISTS ONLY public.volumes DROP CONSTRAINT IF EXISTS fk_ejckjanqqirnogycweueaihtotwswmidnlue;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_ehghabarawarwfwlkgmtbuqipjlefyouzbqv;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS fk_ebzclfrkjucqnkydcbtjdeeobedusbljfzlv;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_dzwohcvcrwjkvmwoojiunqstckvntqsdzfih;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_dwsskpbpbakyiemdswumuvvhhkjrbaxmvmyf;
ALTER TABLE IF EXISTS ONLY public.commerce_lineitems DROP CONSTRAINT IF EXISTS fk_dwrleecjoueozeelsvdxknltbhmyrxpmpatx;
ALTER TABLE IF EXISTS ONLY public.commerce_products DROP CONSTRAINT IF EXISTS fk_duzbffkikulrjqibflhljqremaxandqbiuhd;
ALTER TABLE IF EXISTS ONLY public.userpermissions_usergroups DROP CONSTRAINT IF EXISTS fk_dnwuuemmwurbfvgahslhcdcbxlhfkkbzwdsf;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_dewoijnjekuklnkywolfyftxsovmjiifgysa;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_demhfioylqipieutnxxuyqqrnegbrxrkctkp;
ALTER TABLE IF EXISTS ONLY public.commerce_orderadjustments DROP CONSTRAINT IF EXISTS fk_dcynjqnuzcivtmqtghekarskmmgukqslutas;
ALTER TABLE IF EXISTS ONLY public.commerce_products DROP CONSTRAINT IF EXISTS fk_cywwdreigvvzmihwqdcthyhrcntgsvbbdouh;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingrules DROP CONSTRAINT IF EXISTS fk_ctlzerjobspxwnisozhssczwpciqncwqzvma;
ALTER TABLE IF EXISTS ONLY public.commerce_states DROP CONSTRAINT IF EXISTS fk_coqoyiieslftvvfrzzvbbiphgijrxtaizgiq;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_taxcategories DROP CONSTRAINT IF EXISTS fk_cokusibyztqlztjazfmtjljarezxhpddvoze;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_purchasables DROP CONSTRAINT IF EXISTS fk_cndvkjbcyjriltlbsapwfoqvtwsjwpwbcdwx;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_categories DROP CONSTRAINT IF EXISTS fk_cmzdwaxylwaomxxrnsmtzdqbqaohvzobaxcf;
ALTER TABLE IF EXISTS ONLY public.templatecacheelements DROP CONSTRAINT IF EXISTS fk_ckssdngslanhifzfhtksmxcvbnxzpvrpfjco;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fk_chskglbafppyotpzwlyimopienlhbznjzzve;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_purchasables DROP CONSTRAINT IF EXISTS fk_cebldfzvgnqdzdigtxxjiweupmgcpbboxwgg;
ALTER TABLE IF EXISTS ONLY public.taggroups DROP CONSTRAINT IF EXISTS fk_cclroktevzvmuqlgznoywykyajttjbepqpqq;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_byzuriukcsbojpsbmxjhgxscnbyofbnknyda;
ALTER TABLE IF EXISTS ONLY public.commerce_taxzone_states DROP CONSTRAINT IF EXISTS fk_bxkplcrjnaaivqeqcktajlqgxntfukxtyrec;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fk_bwgbalogcuuppqcyovrwmpqalrzxhiqkcqvk;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_bucvikkiowhlzvcvircegqppzwrbjzitvbbg;
ALTER TABLE IF EXISTS ONLY public.revisions DROP CONSTRAINT IF EXISTS fk_bpdgoamdevklyqxybqwbmwzhqhdatyoypoii;
ALTER TABLE IF EXISTS ONLY public.categorygroups DROP CONSTRAINT IF EXISTS fk_bivwaryjolykbyveoiqifgjwbzcbwfprtyav;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS fk_bhnmihgmrefiavmaiyfccamsmvxxzhwvoywo;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS fk_bhiqypmupmsdxpfzgkgbwrycyuzhmtsyzoma;
ALTER TABLE IF EXISTS ONLY public.notifications_notifications DROP CONSTRAINT IF EXISTS fk_arsuzfopecbadxsxxdbahdqgghpuhcqetivb;
ALTER TABLE IF EXISTS ONLY public.widgets DROP CONSTRAINT IF EXISTS fk_alwtcqgtbusmplowojkyhvkrgnvjiicvyzcj;
ALTER TABLE IF EXISTS ONLY public.templatecachequeries DROP CONSTRAINT IF EXISTS fk_akhiihbwxcxibdxemypylnzragwxtmvdyhob;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes DROP CONSTRAINT IF EXISTS fk_aarjcjmwbimwdlzwivdliocpsipfxjbgifpa;
ALTER TABLE IF EXISTS ONLY public.matrixblocktypes DROP CONSTRAINT IF EXISTS fk_aagdbbwnjqddpkaatzusnkomevwsgzldvtzr;
DROP INDEX IF EXISTS public.idx_zxfwrqshbxjgnxxavhmnwhxqjoezrpdotqac;
DROP INDEX IF EXISTS public.idx_ztrezchlaifvmtpuzxtopodvapspfevdwxcj;
DROP INDEX IF EXISTS public.idx_zthkypdkrmnlzwwpelgwixmghdaggqzbeubo;
DROP INDEX IF EXISTS public.idx_zqsdglsfsadeplqdqibbxnepbwjsfyjqfffk;
DROP INDEX IF EXISTS public.idx_zpsukvmedbenatxbmfnvdaolfkfqzfvhuyph;
DROP INDEX IF EXISTS public.idx_zkdcfmgquvbtkfthynczzncficjjzoyvzfwq;
DROP INDEX IF EXISTS public.idx_zjiqmoxikfilqcgnvtdihnyfmiiblhdamsug;
DROP INDEX IF EXISTS public.idx_zjepwigkkluwcirxnwncrxcpjrfmrtxehial;
DROP INDEX IF EXISTS public.idx_zhgjnzsfuoetkcvqjtdmkgdyuvdofofhighg;
DROP INDEX IF EXISTS public.idx_yxisactfpkuyzxmwzdokphxmncmjlpaxltaq;
DROP INDEX IF EXISTS public.idx_ywohovlunfgtmrxxkuexmfxaqwnytxerijok;
DROP INDEX IF EXISTS public.idx_yvqjnicbhqionvkhzsilexyejolgyefffexd;
DROP INDEX IF EXISTS public.idx_yuiemuqdfwqegtakvuzimvsxeskzqmkjksmn;
DROP INDEX IF EXISTS public.idx_yswayfjjbvyjhbpvtilnqlbamsllnukktbip;
DROP INDEX IF EXISTS public.idx_ystwmqgzihreewcmvhkglrxcssagsvyerryc;
DROP INDEX IF EXISTS public.idx_yoyxytjmvtzllpduepfzeawusontlpyogbfj;
DROP INDEX IF EXISTS public.idx_ykqsqtwifdqkvpzjimbeawdwecfblxabtsov;
DROP INDEX IF EXISTS public.idx_yjpxdcltmhwhiuoxxapsdbhadklpcdzrpftl;
DROP INDEX IF EXISTS public.idx_ygwwmkxgwwifzbwzdidljxodebfcazimipzc;
DROP INDEX IF EXISTS public.idx_ygsrpbzxenwodgrhisvlzawlgsmakipagysz;
DROP INDEX IF EXISTS public.idx_ygsllzriyzesushuxxbgjcbwbovtchcrmwmb;
DROP INDEX IF EXISTS public.idx_ycazfojrlasibaewyuxwuvcdvogmvwcrqzai;
DROP INDEX IF EXISTS public.idx_xzsubmwjpknpzfbydgwfgnfbwehmxsfvzazq;
DROP INDEX IF EXISTS public.idx_xykgsykuowfsqbrwcbknnadfhhltdmnqzgnu;
DROP INDEX IF EXISTS public.idx_xwxkytqdrbqlapsgxzlinixjqjyaswfcfogf;
DROP INDEX IF EXISTS public.idx_xwtohhgbngjyythdpdfuhoxfawemhcawpvyy;
DROP INDEX IF EXISTS public.idx_xsifkizwgnuycnsvvtsbmucxaritjydkwjwl;
DROP INDEX IF EXISTS public.idx_xrchggkiavhnbioqhzlugdnqsfnzrlmjqjyg;
DROP INDEX IF EXISTS public.idx_xqvdevkgmhavxluxzgdwebtqsknzzccwwoag;
DROP INDEX IF EXISTS public.idx_xlgxshojwabhxyioocsedraxwxplqaxuflsp;
DROP INDEX IF EXISTS public.idx_xkvxdtgbyuvvmkvkckfcrkpyegzsqtizagsz;
DROP INDEX IF EXISTS public.idx_xigsxqpcsmgbkytpnqywomdbadowvgxofgqp;
DROP INDEX IF EXISTS public.idx_xgglropxjhkjmhdhjfaheocawicdsqqjjjnd;
DROP INDEX IF EXISTS public.idx_wwhddddbdohpvqnytqfoqewbnbpyygqfdlow;
DROP INDEX IF EXISTS public.idx_wusonvxsdodtreykagtbifqekpkubphrltro;
DROP INDEX IF EXISTS public.idx_wsllyoxqgxxminqcrximlhgbgbumguskqtdn;
DROP INDEX IF EXISTS public.idx_wrikeprjzsrgtmhjsyvnwnvwvbtftqfulpjq;
DROP INDEX IF EXISTS public.idx_wpigaplsfribrqyxeezmtbumlgjlgdlsodud;
DROP INDEX IF EXISTS public.idx_wncuqptutgwoftsidzrlfkzcpenjyjicnevj;
DROP INDEX IF EXISTS public.idx_vxifsastwygflrbjjsqlxammjiwzzsneasgs;
DROP INDEX IF EXISTS public.idx_vtzhkhbqggrefmnjxazxdalujhdcphmmmojr;
DROP INDEX IF EXISTS public.idx_vnvccgelzalvsphbjmkgargwzikvwwtskhej;
DROP INDEX IF EXISTS public.idx_vnbyvdtmfuuxaqlblamcngpiktotgoqnabva;
DROP INDEX IF EXISTS public.idx_vmejvhqdmikcozjnibwtemsempfgpgdgehgg;
DROP INDEX IF EXISTS public.idx_vknzmoaqxavafnatagglvavshkubtixqbfhu;
DROP INDEX IF EXISTS public.idx_vjfuugibixmdvtfcfdxqsumzxeewoctzjnfq;
DROP INDEX IF EXISTS public.idx_vibbxigkzzwmedtfrwotpitpssczkumfbawz;
DROP INDEX IF EXISTS public.idx_vhxqvaeqrccsljednchxbamkojmmuwesxedb;
DROP INDEX IF EXISTS public.idx_vdtwjdudbgoppnlzugsvdjoptndfauxtjwiw;
DROP INDEX IF EXISTS public.idx_vdpmbpoecqkdrxnttlawfkzvejmotrugteuq;
DROP INDEX IF EXISTS public.idx_vcuhlwaccfhpakjnrchipglfipslgixmjhqr;
DROP INDEX IF EXISTS public.idx_uzgsewbvmvwhluxsoycdfwynnguiopxopyje;
DROP INDEX IF EXISTS public.idx_uxhofdmtlqcpuwaprxjldgyabxjumysyzzwu;
DROP INDEX IF EXISTS public.idx_utwcdtsabclrfgitwkldsknkuvrybujtssrm;
DROP INDEX IF EXISTS public.idx_uttzkejlkohajdcatqwyiklavhdnvuluqydc;
DROP INDEX IF EXISTS public.idx_usjqnqhqgcaayrtditivklumkqinzhtfknkz;
DROP INDEX IF EXISTS public.idx_umltwpvzlmytwlbagereibbvbjmiyykyhukq;
DROP INDEX IF EXISTS public.idx_ullkthcynpucynbvtyklifeqfmsmgucurpxf;
DROP INDEX IF EXISTS public.idx_uflrpihiyvleyzfzlyrztakxcuevttzinoku;
DROP INDEX IF EXISTS public.idx_udjuowwwvtorvqynstrrqcnxijztckyjvmqw;
DROP INDEX IF EXISTS public.idx_udjhnfcjwbgowhbuqlyxfrtiovcizgdvmacq;
DROP INDEX IF EXISTS public.idx_tyzmkafkkssbgemudiizjcgpdjijhdtyfrsd;
DROP INDEX IF EXISTS public.idx_tyoviyocctyycjaepmpmloqrlzwtokqevuth;
DROP INDEX IF EXISTS public.idx_twtphdthxflvqvigxeeyqswrynwjvwiwstgf;
DROP INDEX IF EXISTS public.idx_twpeunwyimjwqqrtpikkyjlwivkflfdgbexv;
DROP INDEX IF EXISTS public.idx_tviuvfpsfptmwrdcvowibkenifafzkexyvrp;
DROP INDEX IF EXISTS public.idx_tvaynuqjgduivyslheposyobtsxfcrisvhbv;
DROP INDEX IF EXISTS public.idx_trpagvyghogqsqvwknidugmtwuiplstgebpo;
DROP INDEX IF EXISTS public.idx_trjsjcmjpwotssywpfgvpllfdqhhkafkzniz;
DROP INDEX IF EXISTS public.idx_tpcwtwrutekaxwpfpjigzxvbkdvgswqopzot;
DROP INDEX IF EXISTS public.idx_tmyvxuyirjthsakzwdymuysijvpxxtxoncie;
DROP INDEX IF EXISTS public.idx_tksxbdjxowdqzvjwxecrvubwektkfgomjqgf;
DROP INDEX IF EXISTS public.idx_tfijseowtulmbnkjuynkmjaccxeqgjpellfs;
DROP INDEX IF EXISTS public.idx_sxqdfiapnozrwolhiyezodyjxbtulizebvwk;
DROP INDEX IF EXISTS public.idx_skaspxiuhgyxxyupdqqowxdmewzixifhodmx;
DROP INDEX IF EXISTS public.idx_sgyuzsccjdvrtvksahcnzsuazqelvtxhnbvi;
DROP INDEX IF EXISTS public.idx_sctvnbctykajfdpcheytqcvtkxmgkkghmnse;
DROP INDEX IF EXISTS public.idx_ryedczukermyjzcuqvjpmweouavyodkcuuou;
DROP INDEX IF EXISTS public.idx_rxiapgnmpdwtmschjwavgofoslfhpiiapqvx;
DROP INDEX IF EXISTS public.idx_rspbcdknclhxxofrygvnaznwwvbskcbavogi;
DROP INDEX IF EXISTS public.idx_rofnutryrpqjpwijamgxzmcnaclkulwqpxem;
DROP INDEX IF EXISTS public.idx_rfzkbbijpmmfvascmxwupifftekirqaflbxu;
DROP INDEX IF EXISTS public.idx_rezqwosdmpyfcafhxnmsqmbxwwzxnyvprack;
DROP INDEX IF EXISTS public.idx_qzpihsmqittuviwtvhhmebhqvasagyjvhzrw;
DROP INDEX IF EXISTS public.idx_qxxccdqxqjzpdulzgwhydjqmtzmcddhrmzgc;
DROP INDEX IF EXISTS public.idx_qpkwcavrmmqzjpoczlldqmtjeidmatujeqrw;
DROP INDEX IF EXISTS public.idx_qlebivigbrkldqdfovpkztnharieijjgvann;
DROP INDEX IF EXISTS public.idx_qkwmmfpegqeoizqlysihjnafonltktgcbrio;
DROP INDEX IF EXISTS public.idx_qizeyjrrcbtcnnxtucjycgxfwbstwyxpxzpe;
DROP INDEX IF EXISTS public.idx_qfgmjnbvskqiyloicdqcvfdglfufjolwyhie;
DROP INDEX IF EXISTS public.idx_qdszqrcvonierkpgfihifafgtogzvrtovvgu;
DROP INDEX IF EXISTS public.idx_qcbgykhomzcqhmgrkjufymmmnkpvlyzdifks;
DROP INDEX IF EXISTS public.idx_qbukyfxgpmzsllbtgrsgyhycfoxlzimhyknh;
DROP INDEX IF EXISTS public.idx_pxvvdrrepgwlyndjbucxowjsiuomsvblkruk;
DROP INDEX IF EXISTS public.idx_pjuzdkzydylquvgccnmrgswzujkzlbwnqkkb;
DROP INDEX IF EXISTS public.idx_phlwgdkvjubeswizrisfpthuxgqdmsmgohya;
DROP INDEX IF EXISTS public.idx_pdfpchpclmsywlxzmejeuqjfboaqfdjvnuta;
DROP INDEX IF EXISTS public.idx_ozammsgzefcltindpnfzegyzcpoflxnatybv;
DROP INDEX IF EXISTS public.idx_oxliyzqcttlxnzjpolzmphbwlqlkyqmfryvh;
DROP INDEX IF EXISTS public.idx_oudhtxxpwogoxomvhnfbdsopruretxecneps;
DROP INDEX IF EXISTS public.idx_otkqzvqdlfmengxykzcdocaomuohbcybdhsa;
DROP INDEX IF EXISTS public.idx_oqfraklzfisehbrmxhhbdqfbzpxybjjcmfdv;
DROP INDEX IF EXISTS public.idx_opejvfhowfbfojdhtbqazadlrqlnimfrtgcw;
DROP INDEX IF EXISTS public.idx_opawetaljibjypvskvrzxobwgbworopztdjy;
DROP INDEX IF EXISTS public.idx_oimhxuvkdpiylwzetbwahvibrbxdtjervlqo;
DROP INDEX IF EXISTS public.idx_oebzdmjwiatuuwmeihafpbvxtnpsiwrcfhms;
DROP INDEX IF EXISTS public.idx_odsplaxxickmpfiyhmjeoddvzekqlnthniqy;
DROP INDEX IF EXISTS public.idx_octbfffcgqpzrzdzmfmiexjujexzjwygnzpu;
DROP INDEX IF EXISTS public.idx_nuzntsosdssqngtakjrmvakkanrdqgwvdycf;
DROP INDEX IF EXISTS public.idx_nmedoqmnxclgkuujuxwotkoxqftjqnygmwfi;
DROP INDEX IF EXISTS public.idx_nkhdpasqrdyaniwpapqsspaccvnxtsopkfcl;
DROP INDEX IF EXISTS public.idx_neugrfdiawryaaaegixctvzhytkkycrqrcgy;
DROP INDEX IF EXISTS public.idx_ndmdsovmogvkaeppzwwmrhtevsxcvvictlmi;
DROP INDEX IF EXISTS public.idx_ncsppalwznqkkuwqeivventlroxtpqpychzm;
DROP INDEX IF EXISTS public.idx_nawwtyyaqzdaygnylqtpakfziwcwasjlpbsu;
DROP INDEX IF EXISTS public.idx_myixkzaorhyxmnentkgycxlmgiwmlkjomtno;
DROP INDEX IF EXISTS public.idx_mskvnanygqxmvroopgnkycpabticwfoosixr;
DROP INDEX IF EXISTS public.idx_mmrneqcbrttybkkcsreuzuyituyqfbyaxpum;
DROP INDEX IF EXISTS public.idx_mmmmwtdtsnizaayyddobtjtjygwtfcsbagqn;
DROP INDEX IF EXISTS public.idx_mhngbldvqrdjpmbeyxkewpsfltfglmssiuko;
DROP INDEX IF EXISTS public.idx_mfnjhqwawcroapgkxezdmiwlgymmuehzdqgq;
DROP INDEX IF EXISTS public.idx_mebahqtgfflzurwlcvlnhhchhyvvlselqsss;
DROP INDEX IF EXISTS public.idx_mclpzytqzmfpywdqznjgcrlfdaxehtwyvppg;
DROP INDEX IF EXISTS public.idx_lwzskedenaqunnndoltnundzbywvpagaqvcp;
DROP INDEX IF EXISTS public.idx_lpiimkelzpewzbwknzjbujcdegbuipcywfkj;
DROP INDEX IF EXISTS public.idx_loiklhvxxjgegyfuxjuarkefyrymyotpopuj;
DROP INDEX IF EXISTS public.idx_lnojfsavsxdatsdpgbubvmxlcelqtfdqcihp;
DROP INDEX IF EXISTS public.idx_lkvuiifvsecyyaoyqnzkrnjfsjcqobexnvrm;
DROP INDEX IF EXISTS public.idx_lfvskgltxlciazvgjcanwofwwcvoikxfgdyd;
DROP INDEX IF EXISTS public.idx_lbsudnurawtvixpzhmqufcbhtcethpzdmrqk;
DROP INDEX IF EXISTS public.idx_lbihxbdlgsnbbfxgpzyuicqlostunahaqspp;
DROP INDEX IF EXISTS public.idx_lasbvrnnighuxjwiguvgvcvwrchyqwbjtdhw;
DROP INDEX IF EXISTS public.idx_kzmolfejubylvoujwnwmfzsduacscbocvale;
DROP INDEX IF EXISTS public.idx_kzantqlbtibisjvuejfijhayhdwvrsyvgpro;
DROP INDEX IF EXISTS public.idx_kxhroyycakkexzqrjwthcbxqhlbkflrilpgr;
DROP INDEX IF EXISTS public.idx_kwlpffymonrepyjbandvgjrgqbvebtleinno;
DROP INDEX IF EXISTS public.idx_kwfnkzttubeymglaontvkxvstcqttwqnvutf;
DROP INDEX IF EXISTS public.idx_kutijtogxhrffgxkuywlswnjpknxznzkqtng;
DROP INDEX IF EXISTS public.idx_ktkojjvwykyhyjtbwcnmtottywkaxuiianao;
DROP INDEX IF EXISTS public.idx_krcznfrladdzhbtjivleybwbndeipxhurnhq;
DROP INDEX IF EXISTS public.idx_kqiapgpbpsbhxyhrrtdmyupkqideucrhieoa;
DROP INDEX IF EXISTS public.idx_kqggkxihbcwiwnnduvkxstecwpzffucruhim;
DROP INDEX IF EXISTS public.idx_kfuxnevougsusyvpbthykcmvvwvfwthgazss;
DROP INDEX IF EXISTS public.idx_kdzscdrepbblmgownvtysvrmbbcnkhggivte;
DROP INDEX IF EXISTS public.idx_kdzoyanmafeynmbekkywdmrbpimhwgfronow;
DROP INDEX IF EXISTS public.idx_kcbomxooutuozlehjmyautxujdethtejnxds;
DROP INDEX IF EXISTS public.idx_kawqxmqnnwnxfaugkgpcpwdoacocetwenjiz;
DROP INDEX IF EXISTS public.idx_jzefgisfjblbjsmkzljsbdjegpecqyhwqmdr;
DROP INDEX IF EXISTS public.idx_jyytzkwagjpmcvigzalmqcqmeofvfyorezys;
DROP INDEX IF EXISTS public.idx_jvehjueeqcejszpgnzxsdjhxfwhhtgxqbktb;
DROP INDEX IF EXISTS public.idx_juciovhxwhjfaqgtpenfwcxcofygagdapect;
DROP INDEX IF EXISTS public.idx_jitalolaoaydplakhaitkaqichsptcznibiz;
DROP INDEX IF EXISTS public.idx_jgnracwztijwqegxtsfvxpolotxrcfbaftem;
DROP INDEX IF EXISTS public.idx_jfdjbwksbzjluopyuhyhmdkueugalcyucxkt;
DROP INDEX IF EXISTS public.idx_jefzljnhmlexodbngwznytsadsdqzpaayxeh;
DROP INDEX IF EXISTS public.idx_jctialjqobquviojlyfwthyjfazghqdnbnzl;
DROP INDEX IF EXISTS public.idx_itydklpssxkmrbnbpcjkvsbcsejprkcvwtlf;
DROP INDEX IF EXISTS public.idx_iniucavfkrtpaumfkagzfplejnuchsrjnouc;
DROP INDEX IF EXISTS public.idx_iljogqqmsgysdecymqlhlhjwtwvnqheyxyfe;
DROP INDEX IF EXISTS public.idx_ikvznhtlepdlemnamwxrlazkqwvszgrxdmtn;
DROP INDEX IF EXISTS public.idx_igrfbgetyiqtfwhbkykssmcttytajwiohpan;
DROP INDEX IF EXISTS public.idx_iaocgizstkkzhwxxhinmnxbbacluktwiugmh;
DROP INDEX IF EXISTS public.idx_hwzuvvauuejacoidpwbmdnvveqxykffqwbcr;
DROP INDEX IF EXISTS public.idx_hvcuhaxzcevtghzhbkrhrhlfhxxvoglvwsez;
DROP INDEX IF EXISTS public.idx_hndorsrwqpvexmphmzvrcdhcpvfambrxmcbx;
DROP INDEX IF EXISTS public.idx_hlxdkszaodskubpgrzaiyxngjecvjgrkapas;
DROP INDEX IF EXISTS public.idx_hlqzlzacntpfxdswhqsuekjjnsnjmylijxjj;
DROP INDEX IF EXISTS public.idx_hijydsrtjpittnijhicmhlsiojoudvzlsedw;
DROP INDEX IF EXISTS public.idx_hhluumemidkzntavspsmcmgxgzakruirbqvl;
DROP INDEX IF EXISTS public.idx_hcdqcjreuosatyjfeibrowtelvzdektrtjsg;
DROP INDEX IF EXISTS public.idx_gvoeatxhwrpipbwoyhyqmxpftjyzkhintlxo;
DROP INDEX IF EXISTS public.idx_gvkerckmoeffgjixtjhkkxddrbvbaphjbynk;
DROP INDEX IF EXISTS public.idx_glraadhhdzxhdyhsxnalibezueqlaqxvbpvr;
DROP INDEX IF EXISTS public.idx_ggbvrxhmkotirxfmhnrcgmmvhtsjedwoytxt;
DROP INDEX IF EXISTS public.idx_ggbfqidqtoesxfgxikdhbpnrrvyiadxcynba;
DROP INDEX IF EXISTS public.idx_gfabkpfjicfujzlhphyuskujepossskmdrxl;
DROP INDEX IF EXISTS public.idx_gesxbragfdvugtymufinedkyodksjyahlbrt;
DROP INDEX IF EXISTS public.idx_fyylavqtazchlpyjwachyvywtxfwggruwdsf;
DROP INDEX IF EXISTS public.idx_frcpssdmjtoyxjvxsskysqzhzclxkntfxeqs;
DROP INDEX IF EXISTS public.idx_fqyjgsrwmupaefcatotxuzuoebecnwblfryy;
DROP INDEX IF EXISTS public.idx_fqemlkinixvocbduvasrclnrnkbahybwptys;
DROP INDEX IF EXISTS public.idx_fmqfsuuigjqjudspsmzptxvbacyffpsxylxp;
DROP INDEX IF EXISTS public.idx_fmbaokhngmmxhuuwgpbphnmcjowffwxkdsxn;
DROP INDEX IF EXISTS public.idx_fjqlropkplcobfqkditsathkbrqvmbrgrvxp;
DROP INDEX IF EXISTS public.idx_fiotqomhfcfsoninveiwcfymynkuqykudnje;
DROP INDEX IF EXISTS public.idx_fgvzwfhauolbvjytfnvblzlgaeswsqusmchq;
DROP INDEX IF EXISTS public.idx_fdmdmzzajetxvuqlsqwtipefhlijcucywbcp;
DROP INDEX IF EXISTS public.idx_fdjqmdvnxkmiyqovhsonfkmxlbgsjwntfkok;
DROP INDEX IF EXISTS public.idx_fclqivugdrgyiyesmdmyvpzfsikoddapdjua;
DROP INDEX IF EXISTS public.idx_eyzrepscwmvwxakxvqbhyvmoatsncsbrlrrq;
DROP INDEX IF EXISTS public.idx_etuvyakpgajnsyjqprhcfuuvrbvwvqbiecsd;
DROP INDEX IF EXISTS public.idx_eseawstpsdvneykakvktlndabhvxxsfjqfvp;
DROP INDEX IF EXISTS public.idx_ekrxmwhslbfodecygunefzshrneiwqizubna;
DROP INDEX IF EXISTS public.idx_eivuntwvbmlkbhrqkieazmenggxbpsfvwjut;
DROP INDEX IF EXISTS public.idx_ehgaapnmsuikyesmitntjuryejesrtbzjthm;
DROP INDEX IF EXISTS public.idx_egqftctiqgraqvswoqtrjoszaczsmwjdabxi;
DROP INDEX IF EXISTS public.idx_efztwmtejjhenjtdcwthujqlbxubnkvgvekm;
DROP INDEX IF EXISTS public.idx_ednuoljyujvirbhemwmkjtrjvdgbqsmjaoey;
DROP INDEX IF EXISTS public.idx_dxqpptxjuiocdcvvwphzzlcffrrlilhcjitk;
DROP INDEX IF EXISTS public.idx_drjqaggvukzgfvziyqgaaejmtcomhgeugamh;
DROP INDEX IF EXISTS public.idx_dqaskhnhcuynmihnklxwldebuzypnfdrafgv;
DROP INDEX IF EXISTS public.idx_dijgtktifyfoqykytovyicuecrohzdqumqhj;
DROP INDEX IF EXISTS public.idx_dhxltwilxngmcmlyfjxlaipbeftfzmgkwnwq;
DROP INDEX IF EXISTS public.idx_demeweycgmroyzgcxtsfrlgahiaisdqwedbo;
DROP INDEX IF EXISTS public.idx_dcfcjckntfxvhhgwuhljqxomknrzaqkfckqp;
DROP INDEX IF EXISTS public.idx_cvbiarrbmgvzxzczaoylyaxnnznoeoerfqcs;
DROP INDEX IF EXISTS public.idx_cscesuhvnsiiisfgljzggdcebcyywwjizxzo;
DROP INDEX IF EXISTS public.idx_crwemskghxjpeeudrfjbtctnrqaybzgirtwm;
DROP INDEX IF EXISTS public.idx_crszhxfxihvkyoawvwtjmepghtsehxcmkitn;
DROP INDEX IF EXISTS public.idx_crkixispsnxwuaukbnfokrlsklzwkvbsudws;
DROP INDEX IF EXISTS public.idx_criilhtrpmwctmkduvxobvfuxnonpbouycpu;
DROP INDEX IF EXISTS public.idx_cqtitetydkfybjlepdetqqnrbjyhsaspqhuw;
DROP INDEX IF EXISTS public.idx_cpdvbuhjcbtfdjhlgkujgynfoekjkxfzbyvw;
DROP INDEX IF EXISTS public.idx_cpbbimgzffjjgwiyjeblhlpaymxvxbrdunig;
DROP INDEX IF EXISTS public.idx_cnatsyyuqicuvppghulkjizkidxqsgvzgrqh;
DROP INDEX IF EXISTS public.idx_clpvdyxflkqdiaahkcwglfrentgyqlkincys;
DROP INDEX IF EXISTS public.idx_cjmafclqklslphsvetcqyydijamnmizlrnwl;
DROP INDEX IF EXISTS public.idx_cjedtyuwhamicbaczsdgcvobrzjpuatmeyxp;
DROP INDEX IF EXISTS public.idx_cgpaoxnyrpxlkctdpzxbhxkgozdmibybgwtr;
DROP INDEX IF EXISTS public.idx_cbccyolqrulukoulrwudkirhnocfytifkzre;
DROP INDEX IF EXISTS public.idx_cazhhwuzsvhvzrwjxihccdyonjqqzhnbjbpv;
DROP INDEX IF EXISTS public.idx_bxpwflgksyljzgrmtooinedycufusxcgtuho;
DROP INDEX IF EXISTS public.idx_bwrkvswpwwjzjlknczplosnserfkfwiekzcu;
DROP INDEX IF EXISTS public.idx_buplrzgemhtnnrkjpqpsizfadnyypgkydboi;
DROP INDEX IF EXISTS public.idx_bodxekujufzztqjkzlmbnkajzizeoraihaob;
DROP INDEX IF EXISTS public.idx_bntiwezkugulxobukfdqelxgxlgikvpauruz;
DROP INDEX IF EXISTS public.idx_blmioumkoagclgtsxyjjcqeyavclclczvuwh;
DROP INDEX IF EXISTS public.idx_bkzyylmcwunyonorbikalxxkblatstdjfcmf;
DROP INDEX IF EXISTS public.idx_bkgtovdafkhcjgegpfzrhsrqpmbksorfmgiw;
DROP INDEX IF EXISTS public.idx_bdqiqnmyrlyhrixgvgtnkmazbtmttfaluohf;
DROP INDEX IF EXISTS public.idx_bdpfnkkucqunuohfadtvtdupvrwilmmeisyi;
DROP INDEX IF EXISTS public.idx_bcfctmvdawlqsiiqjimdxbvdecppuoiiqzou;
DROP INDEX IF EXISTS public.idx_bcdcqozykeyarwvsjzwoekfxujofpnxanlge;
DROP INDEX IF EXISTS public.idx_azvvrqrsyeuhwioovzwrliiffxqysragxgtm;
DROP INDEX IF EXISTS public.idx_awuqaezdjmyivyfyjziywfrbjljoizhhqvun;
DROP INDEX IF EXISTS public.idx_avxbfrpkcxjafbxrppggvjwdkcrkulqungez;
DROP INDEX IF EXISTS public.idx_auwpxixtkbdsxgkbvhrggorivycioncuwtma;
DROP INDEX IF EXISTS public.idx_aqabkfbbvcwnbjyujmlrfjpfwogemdppvqem;
DROP INDEX IF EXISTS public.idx_apbdcesmcamgqkapdizvjtxkwddimmkcvxrv;
DROP INDEX IF EXISTS public.idx_aoooznzrxigjjspaxajuqvbbccrhmtbkyhfv;
DROP INDEX IF EXISTS public.idx_aoclkzaieatbucfoqdhnzwhmirmavhwuctno;
DROP INDEX IF EXISTS public.idx_amjtnbpohdxvmcqozqejeivgrrniypmfbjlr;
DROP INDEX IF EXISTS public.idx_aludtlfzbgxmnwyfffemehjnzxjcvdwryzvh;
DROP INDEX IF EXISTS public.idx_aggskbgctifsiylwjgkctoaoiowshawetwtj;
DROP INDEX IF EXISTS public.idx_afongotwoenepoggkeojrvvhihjuspdwiaja;
DROP INDEX IF EXISTS public.idx_adsyevclxnyewfrqevrntxljwmuxyslhlcmd;
DROP INDEX IF EXISTS public.idx_acqhkfbibulwakypskmpwanmediqepskxlkk;
DROP INDEX IF EXISTS public.idx_aabsxshiywozgoavvraythyvxdselmxpecyz;
ALTER TABLE IF EXISTS ONLY public.widgets DROP CONSTRAINT IF EXISTS widgets_pkey;
ALTER TABLE IF EXISTS ONLY public.volumes DROP CONSTRAINT IF EXISTS volumes_pkey;
ALTER TABLE IF EXISTS ONLY public.volumefolders DROP CONSTRAINT IF EXISTS volumefolders_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.userpreferences DROP CONSTRAINT IF EXISTS userpreferences_pkey;
ALTER TABLE IF EXISTS ONLY public.userpermissions_users DROP CONSTRAINT IF EXISTS userpermissions_users_pkey;
ALTER TABLE IF EXISTS ONLY public.userpermissions_usergroups DROP CONSTRAINT IF EXISTS userpermissions_usergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.userpermissions DROP CONSTRAINT IF EXISTS userpermissions_pkey;
ALTER TABLE IF EXISTS ONLY public.usergroups_users DROP CONSTRAINT IF EXISTS usergroups_users_pkey;
ALTER TABLE IF EXISTS ONLY public.usergroups DROP CONSTRAINT IF EXISTS usergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.tokens DROP CONSTRAINT IF EXISTS tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.templatecaches DROP CONSTRAINT IF EXISTS templatecaches_pkey;
ALTER TABLE IF EXISTS ONLY public.templatecachequeries DROP CONSTRAINT IF EXISTS templatecachequeries_pkey;
ALTER TABLE IF EXISTS ONLY public.templatecacheelements DROP CONSTRAINT IF EXISTS templatecacheelements_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_pkey;
ALTER TABLE IF EXISTS ONLY public.taggroups DROP CONSTRAINT IF EXISTS taggroups_pkey;
ALTER TABLE IF EXISTS ONLY public.systemmessages DROP CONSTRAINT IF EXISTS systemmessages_pkey;
ALTER TABLE IF EXISTS ONLY public.structures DROP CONSTRAINT IF EXISTS structures_pkey;
ALTER TABLE IF EXISTS ONLY public.structureelements DROP CONSTRAINT IF EXISTS structureelements_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sitegroups DROP CONSTRAINT IF EXISTS sitegroups_pkey;
ALTER TABLE IF EXISTS ONLY public.shunnedmessages DROP CONSTRAINT IF EXISTS shunnedmessages_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.sequences DROP CONSTRAINT IF EXISTS sequences_pkey;
ALTER TABLE IF EXISTS ONLY public.sections_sites DROP CONSTRAINT IF EXISTS sections_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sections DROP CONSTRAINT IF EXISTS sections_pkey;
ALTER TABLE IF EXISTS ONLY public.revisions DROP CONSTRAINT IF EXISTS revisions_pkey;
ALTER TABLE IF EXISTS ONLY public.resourcepaths DROP CONSTRAINT IF EXISTS resourcepaths_pkey;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS relations_pkey;
ALTER TABLE IF EXISTS ONLY public.queue DROP CONSTRAINT IF EXISTS queue_pkey;
ALTER TABLE IF EXISTS ONLY public.projectconfignames DROP CONSTRAINT IF EXISTS projectconfignames_pkey;
ALTER TABLE IF EXISTS ONLY public.projectconfig DROP CONSTRAINT IF EXISTS projectconfig_pkey;
ALTER TABLE IF EXISTS ONLY public.plugins DROP CONSTRAINT IF EXISTS plugins_pkey;
ALTER TABLE IF EXISTS ONLY public.searchindex DROP CONSTRAINT IF EXISTS pk_nxjbljpgwgkvuinqitxqcynjgdqjpihktzkd;
ALTER TABLE IF EXISTS ONLY public.notifications_notifications DROP CONSTRAINT IF EXISTS notifications_notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.migrations DROP CONSTRAINT IF EXISTS migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.matrixblocktypes DROP CONSTRAINT IF EXISTS matrixblocktypes_pkey;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS matrixblocks_pkey;
ALTER TABLE IF EXISTS ONLY public.info DROP CONSTRAINT IF EXISTS info_pkey;
ALTER TABLE IF EXISTS ONLY public.gqltokens DROP CONSTRAINT IF EXISTS gqltokens_pkey;
ALTER TABLE IF EXISTS ONLY public.gqlschemas DROP CONSTRAINT IF EXISTS gqlschemas_pkey;
ALTER TABLE IF EXISTS ONLY public.globalsets DROP CONSTRAINT IF EXISTS globalsets_pkey;
ALTER TABLE IF EXISTS ONLY public.fields DROP CONSTRAINT IF EXISTS fields_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldlayouttabs DROP CONSTRAINT IF EXISTS fieldlayouttabs_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldlayouts DROP CONSTRAINT IF EXISTS fieldlayouts_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fieldlayoutfields_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldgroups DROP CONSTRAINT IF EXISTS fieldgroups_pkey;
ALTER TABLE IF EXISTS ONLY public.entrytypes DROP CONSTRAINT IF EXISTS entrytypes_pkey;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS entries_pkey;
ALTER TABLE IF EXISTS ONLY public.elements_sites DROP CONSTRAINT IF EXISTS elements_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS elements_pkey;
ALTER TABLE IF EXISTS ONLY public.elementindexsettings DROP CONSTRAINT IF EXISTS elementindexsettings_pkey;
ALTER TABLE IF EXISTS ONLY public.drafts DROP CONSTRAINT IF EXISTS drafts_pkey;
ALTER TABLE IF EXISTS ONLY public.deprecationerrors DROP CONSTRAINT IF EXISTS deprecationerrors_pkey;
ALTER TABLE IF EXISTS ONLY public.craftidtokens DROP CONSTRAINT IF EXISTS craftidtokens_pkey;
ALTER TABLE IF EXISTS ONLY public.content DROP CONSTRAINT IF EXISTS content_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_variants DROP CONSTRAINT IF EXISTS commerce_variants_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_transactions DROP CONSTRAINT IF EXISTS commerce_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_taxzones DROP CONSTRAINT IF EXISTS commerce_taxzones_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_taxzone_states DROP CONSTRAINT IF EXISTS commerce_taxzone_states_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_taxzone_countries DROP CONSTRAINT IF EXISTS commerce_taxzone_countries_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_taxrates DROP CONSTRAINT IF EXISTS commerce_taxrates_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_taxcategories DROP CONSTRAINT IF EXISTS commerce_taxcategories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_subscriptions DROP CONSTRAINT IF EXISTS commerce_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_states DROP CONSTRAINT IF EXISTS commerce_states_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingzones DROP CONSTRAINT IF EXISTS commerce_shippingzones_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingzone_states DROP CONSTRAINT IF EXISTS commerce_shippingzone_states_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingzone_countries DROP CONSTRAINT IF EXISTS commerce_shippingzone_countries_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingrules DROP CONSTRAINT IF EXISTS commerce_shippingrules_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingrule_categories DROP CONSTRAINT IF EXISTS commerce_shippingrule_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingmethods DROP CONSTRAINT IF EXISTS commerce_shippingmethods_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_shippingcategories DROP CONSTRAINT IF EXISTS commerce_shippingcategories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_sales DROP CONSTRAINT IF EXISTS commerce_sales_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_usergroups DROP CONSTRAINT IF EXISTS commerce_sale_usergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_purchasables DROP CONSTRAINT IF EXISTS commerce_sale_purchasables_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_sale_categories DROP CONSTRAINT IF EXISTS commerce_sale_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_purchasables DROP CONSTRAINT IF EXISTS commerce_purchasables_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_taxcategories DROP CONSTRAINT IF EXISTS commerce_producttypes_taxcategories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_sites DROP CONSTRAINT IF EXISTS commerce_producttypes_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes_shippingcategories DROP CONSTRAINT IF EXISTS commerce_producttypes_shippingcategories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_producttypes DROP CONSTRAINT IF EXISTS commerce_producttypes_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_products DROP CONSTRAINT IF EXISTS commerce_products_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_plans DROP CONSTRAINT IF EXISTS commerce_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_pdfs DROP CONSTRAINT IF EXISTS commerce_pdfs_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_paymentsources DROP CONSTRAINT IF EXISTS commerce_paymentsources_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_paymentcurrencies DROP CONSTRAINT IF EXISTS commerce_paymentcurrencies_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_orderstatuses DROP CONSTRAINT IF EXISTS commerce_orderstatuses_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_orderstatus_emails DROP CONSTRAINT IF EXISTS commerce_orderstatus_emails_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_orders DROP CONSTRAINT IF EXISTS commerce_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_orderhistories DROP CONSTRAINT IF EXISTS commerce_orderhistories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_orderadjustments DROP CONSTRAINT IF EXISTS commerce_orderadjustments_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_lineitemstatuses DROP CONSTRAINT IF EXISTS commerce_lineitemstatuses_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_lineitems DROP CONSTRAINT IF EXISTS commerce_lineitems_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_gateways DROP CONSTRAINT IF EXISTS commerce_gateways_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_emails DROP CONSTRAINT IF EXISTS commerce_emails_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_email_discountuses DROP CONSTRAINT IF EXISTS commerce_email_discountuses_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_donations DROP CONSTRAINT IF EXISTS commerce_donations_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_discounts DROP CONSTRAINT IF EXISTS commerce_discounts_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_usergroups DROP CONSTRAINT IF EXISTS commerce_discount_usergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_purchasables DROP CONSTRAINT IF EXISTS commerce_discount_purchasables_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_discount_categories DROP CONSTRAINT IF EXISTS commerce_discount_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_customers DROP CONSTRAINT IF EXISTS commerce_customers_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_customers_addresses DROP CONSTRAINT IF EXISTS commerce_customers_addresses_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_customer_discountuses DROP CONSTRAINT IF EXISTS commerce_customer_discountuses_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_countries DROP CONSTRAINT IF EXISTS commerce_countries_pkey;
ALTER TABLE IF EXISTS ONLY public.commerce_addresses DROP CONSTRAINT IF EXISTS commerce_addresses_pkey;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS changedfields_pkey;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS changedattributes_pkey;
ALTER TABLE IF EXISTS ONLY public.categorygroups_sites DROP CONSTRAINT IF EXISTS categorygroups_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.categorygroups DROP CONSTRAINT IF EXISTS categorygroups_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.assettransforms DROP CONSTRAINT IF EXISTS assettransforms_pkey;
ALTER TABLE IF EXISTS ONLY public.assettransformindex DROP CONSTRAINT IF EXISTS assettransformindex_pkey;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_pkey;
ALTER TABLE IF EXISTS ONLY public.assetindexdata DROP CONSTRAINT IF EXISTS assetindexdata_pkey;
ALTER TABLE IF EXISTS public.widgets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.volumes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.volumefolders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpreferences ALTER COLUMN "userId" DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpermissions_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpermissions_usergroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpermissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.usergroups_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.usergroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.templatecaches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.templatecachequeries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.templatecacheelements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.taggroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.systemmessages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.structures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.structureelements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sitegroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.shunnedmessages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sections_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sections ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.revisions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.relations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.queue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plugins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications_notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matrixblocktypes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.info ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gqltokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gqlschemas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.globalsets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldlayouttabs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldlayouts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldlayoutfields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldgroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.entrytypes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elements_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elementindexsettings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.drafts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deprecationerrors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.craftidtokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.content ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_taxzones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_taxzone_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_taxzone_countries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_taxrates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_taxcategories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_subscriptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_shippingzones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_shippingzone_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_shippingzone_countries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_shippingrules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_shippingrule_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_shippingmethods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_shippingcategories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_sales ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_sale_usergroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_sale_purchasables ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_sale_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_purchasables ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_producttypes_taxcategories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_producttypes_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_producttypes_shippingcategories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_producttypes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_pdfs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_paymentsources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_paymentcurrencies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_orderstatuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_orderstatus_emails ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_orderhistories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_orderadjustments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_lineitemstatuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_lineitems ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_gateways ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_emails ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_email_discountuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_donations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_discounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_discount_usergroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_discount_purchasables ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_discount_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_customers_addresses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_customers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_customer_discountuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_countries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commerce_addresses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categorygroups_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categorygroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assettransforms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assettransformindex ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assetindexdata ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.widgets_id_seq;
DROP TABLE IF EXISTS public.widgets;
DROP SEQUENCE IF EXISTS public.volumes_id_seq;
DROP TABLE IF EXISTS public.volumes;
DROP SEQUENCE IF EXISTS public.volumefolders_id_seq;
DROP TABLE IF EXISTS public.volumefolders;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public."userpreferences_userId_seq";
DROP TABLE IF EXISTS public.userpreferences;
DROP SEQUENCE IF EXISTS public.userpermissions_users_id_seq;
DROP TABLE IF EXISTS public.userpermissions_users;
DROP SEQUENCE IF EXISTS public.userpermissions_usergroups_id_seq;
DROP TABLE IF EXISTS public.userpermissions_usergroups;
DROP SEQUENCE IF EXISTS public.userpermissions_id_seq;
DROP TABLE IF EXISTS public.userpermissions;
DROP SEQUENCE IF EXISTS public.usergroups_users_id_seq;
DROP TABLE IF EXISTS public.usergroups_users;
DROP SEQUENCE IF EXISTS public.usergroups_id_seq;
DROP TABLE IF EXISTS public.usergroups;
DROP SEQUENCE IF EXISTS public.tokens_id_seq;
DROP TABLE IF EXISTS public.tokens;
DROP SEQUENCE IF EXISTS public.templatecaches_id_seq;
DROP TABLE IF EXISTS public.templatecaches;
DROP SEQUENCE IF EXISTS public.templatecachequeries_id_seq;
DROP TABLE IF EXISTS public.templatecachequeries;
DROP SEQUENCE IF EXISTS public.templatecacheelements_id_seq;
DROP TABLE IF EXISTS public.templatecacheelements;
DROP TABLE IF EXISTS public.tags;
DROP SEQUENCE IF EXISTS public.taggroups_id_seq;
DROP TABLE IF EXISTS public.taggroups;
DROP SEQUENCE IF EXISTS public.systemmessages_id_seq;
DROP TABLE IF EXISTS public.systemmessages;
DROP SEQUENCE IF EXISTS public.structures_id_seq;
DROP TABLE IF EXISTS public.structures;
DROP SEQUENCE IF EXISTS public.structureelements_id_seq;
DROP TABLE IF EXISTS public.structureelements;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.sitegroups_id_seq;
DROP TABLE IF EXISTS public.sitegroups;
DROP SEQUENCE IF EXISTS public.shunnedmessages_id_seq;
DROP TABLE IF EXISTS public.shunnedmessages;
DROP SEQUENCE IF EXISTS public.sessions_id_seq;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.sequences;
DROP SEQUENCE IF EXISTS public.sections_sites_id_seq;
DROP TABLE IF EXISTS public.sections_sites;
DROP SEQUENCE IF EXISTS public.sections_id_seq;
DROP TABLE IF EXISTS public.sections;
DROP TABLE IF EXISTS public.searchindex;
DROP SEQUENCE IF EXISTS public.revisions_id_seq;
DROP TABLE IF EXISTS public.revisions;
DROP TABLE IF EXISTS public.resourcepaths;
DROP SEQUENCE IF EXISTS public.relations_id_seq;
DROP TABLE IF EXISTS public.relations;
DROP SEQUENCE IF EXISTS public.queue_id_seq;
DROP TABLE IF EXISTS public.queue;
DROP TABLE IF EXISTS public.projectconfignames;
DROP TABLE IF EXISTS public.projectconfig;
DROP SEQUENCE IF EXISTS public.plugins_id_seq;
DROP TABLE IF EXISTS public.plugins;
DROP SEQUENCE IF EXISTS public.notifications_notifications_id_seq;
DROP TABLE IF EXISTS public.notifications_notifications;
DROP SEQUENCE IF EXISTS public.migrations_id_seq;
DROP TABLE IF EXISTS public.migrations;
DROP SEQUENCE IF EXISTS public.matrixblocktypes_id_seq;
DROP TABLE IF EXISTS public.matrixblocktypes;
DROP TABLE IF EXISTS public.matrixblocks;
DROP SEQUENCE IF EXISTS public.info_id_seq;
DROP TABLE IF EXISTS public.info;
DROP SEQUENCE IF EXISTS public.gqltokens_id_seq;
DROP TABLE IF EXISTS public.gqltokens;
DROP SEQUENCE IF EXISTS public.gqlschemas_id_seq;
DROP TABLE IF EXISTS public.gqlschemas;
DROP SEQUENCE IF EXISTS public.globalsets_id_seq;
DROP TABLE IF EXISTS public.globalsets;
DROP SEQUENCE IF EXISTS public.fields_id_seq;
DROP TABLE IF EXISTS public.fields;
DROP SEQUENCE IF EXISTS public.fieldlayouttabs_id_seq;
DROP TABLE IF EXISTS public.fieldlayouttabs;
DROP SEQUENCE IF EXISTS public.fieldlayouts_id_seq;
DROP TABLE IF EXISTS public.fieldlayouts;
DROP SEQUENCE IF EXISTS public.fieldlayoutfields_id_seq;
DROP TABLE IF EXISTS public.fieldlayoutfields;
DROP SEQUENCE IF EXISTS public.fieldgroups_id_seq;
DROP TABLE IF EXISTS public.fieldgroups;
DROP SEQUENCE IF EXISTS public.entrytypes_id_seq;
DROP TABLE IF EXISTS public.entrytypes;
DROP TABLE IF EXISTS public.entries;
DROP SEQUENCE IF EXISTS public.elements_sites_id_seq;
DROP TABLE IF EXISTS public.elements_sites;
DROP SEQUENCE IF EXISTS public.elements_id_seq;
DROP TABLE IF EXISTS public.elements;
DROP SEQUENCE IF EXISTS public.elementindexsettings_id_seq;
DROP TABLE IF EXISTS public.elementindexsettings;
DROP SEQUENCE IF EXISTS public.drafts_id_seq;
DROP TABLE IF EXISTS public.drafts;
DROP SEQUENCE IF EXISTS public.deprecationerrors_id_seq;
DROP TABLE IF EXISTS public.deprecationerrors;
DROP SEQUENCE IF EXISTS public.craftidtokens_id_seq;
DROP TABLE IF EXISTS public.craftidtokens;
DROP SEQUENCE IF EXISTS public.content_id_seq;
DROP TABLE IF EXISTS public.content;
DROP TABLE IF EXISTS public.commerce_variants;
DROP SEQUENCE IF EXISTS public.commerce_transactions_id_seq;
DROP TABLE IF EXISTS public.commerce_transactions;
DROP SEQUENCE IF EXISTS public.commerce_taxzones_id_seq;
DROP TABLE IF EXISTS public.commerce_taxzones;
DROP SEQUENCE IF EXISTS public.commerce_taxzone_states_id_seq;
DROP TABLE IF EXISTS public.commerce_taxzone_states;
DROP SEQUENCE IF EXISTS public.commerce_taxzone_countries_id_seq;
DROP TABLE IF EXISTS public.commerce_taxzone_countries;
DROP SEQUENCE IF EXISTS public.commerce_taxrates_id_seq;
DROP TABLE IF EXISTS public.commerce_taxrates;
DROP SEQUENCE IF EXISTS public.commerce_taxcategories_id_seq;
DROP TABLE IF EXISTS public.commerce_taxcategories;
DROP SEQUENCE IF EXISTS public.commerce_subscriptions_id_seq;
DROP TABLE IF EXISTS public.commerce_subscriptions;
DROP SEQUENCE IF EXISTS public.commerce_states_id_seq;
DROP TABLE IF EXISTS public.commerce_states;
DROP SEQUENCE IF EXISTS public.commerce_shippingzones_id_seq;
DROP TABLE IF EXISTS public.commerce_shippingzones;
DROP SEQUENCE IF EXISTS public.commerce_shippingzone_states_id_seq;
DROP TABLE IF EXISTS public.commerce_shippingzone_states;
DROP SEQUENCE IF EXISTS public.commerce_shippingzone_countries_id_seq;
DROP TABLE IF EXISTS public.commerce_shippingzone_countries;
DROP SEQUENCE IF EXISTS public.commerce_shippingrules_id_seq;
DROP TABLE IF EXISTS public.commerce_shippingrules;
DROP SEQUENCE IF EXISTS public.commerce_shippingrule_categories_id_seq;
DROP TABLE IF EXISTS public.commerce_shippingrule_categories;
DROP SEQUENCE IF EXISTS public.commerce_shippingmethods_id_seq;
DROP TABLE IF EXISTS public.commerce_shippingmethods;
DROP SEQUENCE IF EXISTS public.commerce_shippingcategories_id_seq;
DROP TABLE IF EXISTS public.commerce_shippingcategories;
DROP SEQUENCE IF EXISTS public.commerce_sales_id_seq;
DROP TABLE IF EXISTS public.commerce_sales;
DROP SEQUENCE IF EXISTS public.commerce_sale_usergroups_id_seq;
DROP TABLE IF EXISTS public.commerce_sale_usergroups;
DROP SEQUENCE IF EXISTS public.commerce_sale_purchasables_id_seq;
DROP TABLE IF EXISTS public.commerce_sale_purchasables;
DROP SEQUENCE IF EXISTS public.commerce_sale_categories_id_seq;
DROP TABLE IF EXISTS public.commerce_sale_categories;
DROP SEQUENCE IF EXISTS public.commerce_purchasables_id_seq;
DROP TABLE IF EXISTS public.commerce_purchasables;
DROP SEQUENCE IF EXISTS public.commerce_producttypes_taxcategories_id_seq;
DROP TABLE IF EXISTS public.commerce_producttypes_taxcategories;
DROP SEQUENCE IF EXISTS public.commerce_producttypes_sites_id_seq;
DROP TABLE IF EXISTS public.commerce_producttypes_sites;
DROP SEQUENCE IF EXISTS public.commerce_producttypes_shippingcategories_id_seq;
DROP TABLE IF EXISTS public.commerce_producttypes_shippingcategories;
DROP SEQUENCE IF EXISTS public.commerce_producttypes_id_seq;
DROP TABLE IF EXISTS public.commerce_producttypes;
DROP TABLE IF EXISTS public.commerce_products;
DROP SEQUENCE IF EXISTS public.commerce_plans_id_seq;
DROP TABLE IF EXISTS public.commerce_plans;
DROP SEQUENCE IF EXISTS public.commerce_pdfs_id_seq;
DROP TABLE IF EXISTS public.commerce_pdfs;
DROP SEQUENCE IF EXISTS public.commerce_paymentsources_id_seq;
DROP TABLE IF EXISTS public.commerce_paymentsources;
DROP SEQUENCE IF EXISTS public.commerce_paymentcurrencies_id_seq;
DROP TABLE IF EXISTS public.commerce_paymentcurrencies;
DROP SEQUENCE IF EXISTS public.commerce_orderstatuses_id_seq;
DROP TABLE IF EXISTS public.commerce_orderstatuses;
DROP SEQUENCE IF EXISTS public.commerce_orderstatus_emails_id_seq;
DROP TABLE IF EXISTS public.commerce_orderstatus_emails;
DROP TABLE IF EXISTS public.commerce_orders;
DROP SEQUENCE IF EXISTS public.commerce_orderhistories_id_seq;
DROP TABLE IF EXISTS public.commerce_orderhistories;
DROP SEQUENCE IF EXISTS public.commerce_orderadjustments_id_seq;
DROP TABLE IF EXISTS public.commerce_orderadjustments;
DROP SEQUENCE IF EXISTS public.commerce_lineitemstatuses_id_seq;
DROP TABLE IF EXISTS public.commerce_lineitemstatuses;
DROP SEQUENCE IF EXISTS public.commerce_lineitems_id_seq;
DROP TABLE IF EXISTS public.commerce_lineitems;
DROP SEQUENCE IF EXISTS public.commerce_gateways_id_seq;
DROP TABLE IF EXISTS public.commerce_gateways;
DROP SEQUENCE IF EXISTS public.commerce_emails_id_seq;
DROP TABLE IF EXISTS public.commerce_emails;
DROP SEQUENCE IF EXISTS public.commerce_email_discountuses_id_seq;
DROP TABLE IF EXISTS public.commerce_email_discountuses;
DROP SEQUENCE IF EXISTS public.commerce_donations_id_seq;
DROP TABLE IF EXISTS public.commerce_donations;
DROP SEQUENCE IF EXISTS public.commerce_discounts_id_seq;
DROP TABLE IF EXISTS public.commerce_discounts;
DROP SEQUENCE IF EXISTS public.commerce_discount_usergroups_id_seq;
DROP TABLE IF EXISTS public.commerce_discount_usergroups;
DROP SEQUENCE IF EXISTS public.commerce_discount_purchasables_id_seq;
DROP TABLE IF EXISTS public.commerce_discount_purchasables;
DROP SEQUENCE IF EXISTS public.commerce_discount_categories_id_seq;
DROP TABLE IF EXISTS public.commerce_discount_categories;
DROP SEQUENCE IF EXISTS public.commerce_customers_id_seq;
DROP SEQUENCE IF EXISTS public.commerce_customers_addresses_id_seq;
DROP TABLE IF EXISTS public.commerce_customers_addresses;
DROP TABLE IF EXISTS public.commerce_customers;
DROP SEQUENCE IF EXISTS public.commerce_customer_discountuses_id_seq;
DROP TABLE IF EXISTS public.commerce_customer_discountuses;
DROP SEQUENCE IF EXISTS public.commerce_countries_id_seq;
DROP TABLE IF EXISTS public.commerce_countries;
DROP SEQUENCE IF EXISTS public.commerce_addresses_id_seq;
DROP TABLE IF EXISTS public.commerce_addresses;
DROP TABLE IF EXISTS public.changedfields;
DROP TABLE IF EXISTS public.changedattributes;
DROP SEQUENCE IF EXISTS public.categorygroups_sites_id_seq;
DROP TABLE IF EXISTS public.categorygroups_sites;
DROP SEQUENCE IF EXISTS public.categorygroups_id_seq;
DROP TABLE IF EXISTS public.categorygroups;
DROP TABLE IF EXISTS public.categories;
DROP SEQUENCE IF EXISTS public.assettransforms_id_seq;
DROP TABLE IF EXISTS public.assettransforms;
DROP SEQUENCE IF EXISTS public.assettransformindex_id_seq;
DROP TABLE IF EXISTS public.assettransformindex;
DROP TABLE IF EXISTS public.assets;
DROP SEQUENCE IF EXISTS public.assetindexdata_id_seq;
DROP TABLE IF EXISTS public.assetindexdata;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assetindexdata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assetindexdata (
    id integer NOT NULL,
    "sessionId" character varying(36) DEFAULT ''::character varying NOT NULL,
    "volumeId" integer NOT NULL,
    uri text,
    size bigint,
    "timestamp" timestamp(0) without time zone,
    "recordId" integer,
    "inProgress" boolean DEFAULT false,
    completed boolean DEFAULT false,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: assetindexdata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assetindexdata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assetindexdata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assetindexdata_id_seq OWNED BY public.assetindexdata.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    "volumeId" integer,
    "folderId" integer NOT NULL,
    "uploaderId" integer,
    filename character varying(255) NOT NULL,
    kind character varying(50) DEFAULT 'unknown'::character varying NOT NULL,
    width integer,
    height integer,
    size bigint,
    "focalPoint" character varying(13) DEFAULT NULL::character varying,
    "deletedWithVolume" boolean,
    "keptFile" boolean,
    "dateModified" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: assettransformindex; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assettransformindex (
    id integer NOT NULL,
    "assetId" integer NOT NULL,
    filename character varying(255),
    format character varying(255),
    location character varying(255) NOT NULL,
    "volumeId" integer,
    "fileExists" boolean DEFAULT false NOT NULL,
    "inProgress" boolean DEFAULT false NOT NULL,
    error boolean DEFAULT false NOT NULL,
    "dateIndexed" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: assettransformindex_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assettransformindex_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assettransformindex_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assettransformindex_id_seq OWNED BY public.assettransformindex.id;


--
-- Name: assettransforms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assettransforms (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    mode character varying(255) DEFAULT 'crop'::character varying NOT NULL,
    "position" character varying(255) DEFAULT 'center-center'::character varying NOT NULL,
    width integer,
    height integer,
    format character varying(255),
    quality integer,
    interlace character varying(255) DEFAULT 'none'::character varying NOT NULL,
    "dimensionChangeTime" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT assettransforms_interlace_check CHECK (((interlace)::text = ANY ((ARRAY['none'::character varying, 'line'::character varying, 'plane'::character varying, 'partition'::character varying])::text[]))),
    CONSTRAINT assettransforms_mode_check CHECK (((mode)::text = ANY ((ARRAY['stretch'::character varying, 'fit'::character varying, 'crop'::character varying])::text[]))),
    CONSTRAINT assettransforms_position_check CHECK ((("position")::text = ANY ((ARRAY['top-left'::character varying, 'top-center'::character varying, 'top-right'::character varying, 'center-left'::character varying, 'center-center'::character varying, 'center-right'::character varying, 'bottom-left'::character varying, 'bottom-center'::character varying, 'bottom-right'::character varying])::text[])))
);


--
-- Name: assettransforms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assettransforms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assettransforms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assettransforms_id_seq OWNED BY public.assettransforms.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "parentId" integer,
    "deletedWithGroup" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: categorygroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorygroups (
    id integer NOT NULL,
    "structureId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: categorygroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categorygroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categorygroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categorygroups_id_seq OWNED BY public.categorygroups.id;


--
-- Name: categorygroups_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorygroups_sites (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    "uriFormat" text,
    template character varying(500),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categorygroups_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categorygroups_sites_id_seq OWNED BY public.categorygroups_sites.id;


--
-- Name: changedattributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changedattributes (
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    attribute character varying(255) NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    propagated boolean NOT NULL,
    "userId" integer
);


--
-- Name: changedfields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changedfields (
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    propagated boolean NOT NULL,
    "userId" integer
);


--
-- Name: commerce_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_addresses (
    id integer NOT NULL,
    "countryId" integer,
    "stateId" integer,
    "isStoreLocation" boolean DEFAULT false NOT NULL,
    attention character varying(255),
    title character varying(255),
    "firstName" character varying(255),
    "lastName" character varying(255),
    "fullName" character varying(255),
    address1 character varying(255),
    address2 character varying(255),
    address3 character varying(255),
    city character varying(255),
    "zipCode" character varying(255),
    phone character varying(255),
    "alternativePhone" character varying(255),
    label character varying(255),
    notes text,
    "businessName" character varying(255),
    "businessTaxId" character varying(255),
    "businessId" character varying(255),
    "stateName" character varying(255),
    custom1 character varying(255),
    custom2 character varying(255),
    custom3 character varying(255),
    custom4 character varying(255),
    "isEstimated" boolean DEFAULT false NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_addresses_id_seq OWNED BY public.commerce_addresses.id;


--
-- Name: commerce_countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_countries (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    iso character varying(2) NOT NULL,
    "isStateRequired" boolean,
    "sortOrder" integer,
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_countries_id_seq OWNED BY public.commerce_countries.id;


--
-- Name: commerce_customer_discountuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_customer_discountuses (
    id integer NOT NULL,
    "discountId" integer NOT NULL,
    "customerId" integer NOT NULL,
    uses integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_customer_discountuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_customer_discountuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_customer_discountuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_customer_discountuses_id_seq OWNED BY public.commerce_customer_discountuses.id;


--
-- Name: commerce_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_customers (
    id integer NOT NULL,
    "userId" integer,
    "primaryBillingAddressId" integer,
    "primaryShippingAddressId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_customers_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_customers_addresses (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    "addressId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_customers_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_customers_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_customers_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_customers_addresses_id_seq OWNED BY public.commerce_customers_addresses.id;


--
-- Name: commerce_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_customers_id_seq OWNED BY public.commerce_customers.id;


--
-- Name: commerce_discount_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_discount_categories (
    id integer NOT NULL,
    "discountId" integer NOT NULL,
    "categoryId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_discount_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_discount_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_discount_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_discount_categories_id_seq OWNED BY public.commerce_discount_categories.id;


--
-- Name: commerce_discount_purchasables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_discount_purchasables (
    id integer NOT NULL,
    "discountId" integer NOT NULL,
    "purchasableId" integer NOT NULL,
    "purchasableType" character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_discount_purchasables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_discount_purchasables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_discount_purchasables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_discount_purchasables_id_seq OWNED BY public.commerce_discount_purchasables.id;


--
-- Name: commerce_discount_usergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_discount_usergroups (
    id integer NOT NULL,
    "discountId" integer NOT NULL,
    "userGroupId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_discount_usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_discount_usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_discount_usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_discount_usergroups_id_seq OWNED BY public.commerce_discount_usergroups.id;


--
-- Name: commerce_discounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_discounts (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    code character varying(255),
    "perUserLimit" integer DEFAULT 0 NOT NULL,
    "perEmailLimit" integer DEFAULT 0 NOT NULL,
    "totalDiscountUses" integer DEFAULT 0 NOT NULL,
    "totalDiscountUseLimit" integer DEFAULT 0 NOT NULL,
    "dateFrom" timestamp(0) without time zone,
    "dateTo" timestamp(0) without time zone,
    "purchaseTotal" numeric(14,4) DEFAULT 0 NOT NULL,
    "purchaseQty" integer DEFAULT 0 NOT NULL,
    "maxPurchaseQty" integer DEFAULT 0 NOT NULL,
    "baseDiscount" numeric(14,4) DEFAULT 0 NOT NULL,
    "baseDiscountType" character varying(255) DEFAULT 'value'::character varying NOT NULL,
    "perItemDiscount" numeric(14,4) DEFAULT 0 NOT NULL,
    "percentDiscount" numeric(14,4) DEFAULT 0 NOT NULL,
    "percentageOffSubject" character varying(255) NOT NULL,
    "excludeOnSale" boolean,
    "hasFreeShippingForMatchingItems" boolean,
    "hasFreeShippingForOrder" boolean,
    "allGroups" boolean,
    "allPurchasables" boolean,
    "allCategories" boolean,
    "appliedTo" character varying(255) DEFAULT 'matchingLineItems'::character varying NOT NULL,
    "categoryRelationshipType" character varying(255) DEFAULT 'element'::character varying NOT NULL,
    "orderConditionFormula" text,
    enabled boolean,
    "stopProcessing" boolean,
    "ignoreSales" boolean DEFAULT false NOT NULL,
    "sortOrder" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "commerce_discounts_appliedTo_check" CHECK ((("appliedTo")::text = ANY ((ARRAY['matchingLineItems'::character varying, 'allLineItems'::character varying])::text[]))),
    CONSTRAINT "commerce_discounts_baseDiscountType_check" CHECK ((("baseDiscountType")::text = ANY ((ARRAY['value'::character varying, 'percentTotal'::character varying, 'percentTotalDiscounted'::character varying, 'percentItems'::character varying, 'percentItemsDiscounted'::character varying])::text[]))),
    CONSTRAINT "commerce_discounts_categoryRelationshipType_check" CHECK ((("categoryRelationshipType")::text = ANY ((ARRAY['element'::character varying, 'sourceElement'::character varying, 'targetElement'::character varying])::text[]))),
    CONSTRAINT "commerce_discounts_percentageOffSubject_check" CHECK ((("percentageOffSubject")::text = ANY ((ARRAY['original'::character varying, 'discounted'::character varying])::text[])))
);


--
-- Name: commerce_discounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_discounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_discounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_discounts_id_seq OWNED BY public.commerce_discounts.id;


--
-- Name: commerce_donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_donations (
    id integer NOT NULL,
    sku character varying(255) NOT NULL,
    "availableForPurchase" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_donations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_donations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_donations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_donations_id_seq OWNED BY public.commerce_donations.id;


--
-- Name: commerce_email_discountuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_email_discountuses (
    id integer NOT NULL,
    "discountId" integer NOT NULL,
    email character varying(255) NOT NULL,
    uses integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_email_discountuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_email_discountuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_email_discountuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_email_discountuses_id_seq OWNED BY public.commerce_email_discountuses.id;


--
-- Name: commerce_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_emails (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    "recipientType" character varying(255) DEFAULT 'custom'::character varying,
    "to" character varying(255),
    bcc character varying(255),
    cc character varying(255),
    "replyTo" character varying(255),
    enabled boolean,
    "templatePath" character varying(255) NOT NULL,
    "plainTextTemplatePath" character varying(255),
    "pdfId" integer,
    language character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "commerce_emails_recipientType_check" CHECK ((("recipientType")::text = ANY ((ARRAY['customer'::character varying, 'custom'::character varying])::text[])))
);


--
-- Name: commerce_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_emails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_emails_id_seq OWNED BY public.commerce_emails.id;


--
-- Name: commerce_gateways; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_gateways (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    settings text,
    "paymentType" character varying(255) DEFAULT 'purchase'::character varying NOT NULL,
    "isFrontendEnabled" boolean,
    "sendCartInfo" boolean,
    "isArchived" boolean,
    "dateArchived" timestamp(0) without time zone,
    "sortOrder" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "commerce_gateways_paymentType_check" CHECK ((("paymentType")::text = ANY ((ARRAY['authorize'::character varying, 'purchase'::character varying])::text[])))
);


--
-- Name: commerce_gateways_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_gateways_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_gateways_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_gateways_id_seq OWNED BY public.commerce_gateways.id;


--
-- Name: commerce_lineitems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_lineitems (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    "purchasableId" integer,
    "taxCategoryId" integer NOT NULL,
    "shippingCategoryId" integer NOT NULL,
    description text,
    options text,
    "optionsSignature" character varying(255) NOT NULL,
    price numeric(14,4) NOT NULL,
    "saleAmount" numeric(14,4) DEFAULT 0 NOT NULL,
    "salePrice" numeric(14,4) DEFAULT 0 NOT NULL,
    sku character varying(255),
    weight numeric(14,4) DEFAULT 0 NOT NULL,
    height numeric(14,4) DEFAULT 0 NOT NULL,
    length numeric(14,4) DEFAULT 0 NOT NULL,
    width numeric(14,4) DEFAULT 0 NOT NULL,
    subtotal numeric(14,4) DEFAULT 0 NOT NULL,
    total numeric(14,4) DEFAULT 0 NOT NULL,
    qty integer NOT NULL,
    note text,
    "privateNote" text,
    snapshot text,
    "lineItemStatusId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_lineitems_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_lineitems_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_lineitems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_lineitems_id_seq OWNED BY public.commerce_lineitems.id;


--
-- Name: commerce_lineitemstatuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_lineitemstatuses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    color character varying(255) DEFAULT 'green'::character varying NOT NULL,
    "isArchived" boolean DEFAULT false NOT NULL,
    "dateArchived" timestamp(0) without time zone,
    "sortOrder" integer,
    "default" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT commerce_lineitemstatuses_color_check CHECK (((color)::text = ANY ((ARRAY['green'::character varying, 'orange'::character varying, 'red'::character varying, 'blue'::character varying, 'yellow'::character varying, 'pink'::character varying, 'purple'::character varying, 'turquoise'::character varying, 'light'::character varying, 'grey'::character varying, 'black'::character varying])::text[])))
);


--
-- Name: commerce_lineitemstatuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_lineitemstatuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_lineitemstatuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_lineitemstatuses_id_seq OWNED BY public.commerce_lineitemstatuses.id;


--
-- Name: commerce_orderadjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_orderadjustments (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    "lineItemId" integer,
    type character varying(255) NOT NULL,
    name character varying(255),
    description character varying(255),
    amount numeric(14,4) NOT NULL,
    included boolean,
    "isEstimated" boolean DEFAULT false NOT NULL,
    "sourceSnapshot" text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_orderadjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_orderadjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_orderadjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_orderadjustments_id_seq OWNED BY public.commerce_orderadjustments.id;


--
-- Name: commerce_orderhistories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_orderhistories (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    "customerId" integer NOT NULL,
    "prevStatusId" integer,
    "newStatusId" integer,
    message text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_orderhistories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_orderhistories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_orderhistories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_orderhistories_id_seq OWNED BY public.commerce_orderhistories.id;


--
-- Name: commerce_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_orders (
    id integer NOT NULL,
    "billingAddressId" integer,
    "shippingAddressId" integer,
    "estimatedBillingAddressId" integer,
    "estimatedShippingAddressId" integer,
    "gatewayId" integer,
    "paymentSourceId" integer,
    "customerId" integer,
    "orderStatusId" integer,
    number character varying(32),
    reference character varying(255),
    "couponCode" character varying(255),
    "itemTotal" numeric(14,4) DEFAULT 0,
    "itemSubtotal" numeric(14,4) DEFAULT 0,
    total numeric(14,4) DEFAULT 0,
    "totalPrice" numeric(14,4) DEFAULT 0,
    "totalPaid" numeric(14,4) DEFAULT 0,
    "totalDiscount" numeric(14,4) DEFAULT 0,
    "totalTax" numeric(14,4) DEFAULT 0,
    "totalTaxIncluded" numeric(14,4) DEFAULT 0,
    "totalShippingCost" numeric(14,4) DEFAULT 0,
    "paidStatus" character varying(255),
    email character varying(255),
    "isCompleted" boolean,
    "dateOrdered" timestamp(0) without time zone,
    "datePaid" timestamp(0) without time zone,
    "dateAuthorized" timestamp(0) without time zone,
    currency character varying(255),
    "paymentCurrency" character varying(255),
    "lastIp" character varying(255),
    "orderLanguage" character varying(12) NOT NULL,
    origin character varying(255) DEFAULT 'web'::character varying NOT NULL,
    message text,
    "registerUserOnOrderComplete" boolean,
    "recalculationMode" character varying(255) DEFAULT 'all'::character varying NOT NULL,
    "returnUrl" character varying(255),
    "cancelUrl" character varying(255),
    "shippingMethodHandle" character varying(255),
    "shippingMethodName" character varying(255),
    "orderSiteId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT commerce_orders_origin_check CHECK (((origin)::text = ANY ((ARRAY['web'::character varying, 'cp'::character varying, 'remote'::character varying])::text[]))),
    CONSTRAINT "commerce_orders_paidStatus_check" CHECK ((("paidStatus")::text = ANY ((ARRAY['paid'::character varying, 'partial'::character varying, 'unpaid'::character varying, 'overPaid'::character varying])::text[]))),
    CONSTRAINT "commerce_orders_recalculationMode_check" CHECK ((("recalculationMode")::text = ANY ((ARRAY['all'::character varying, 'none'::character varying, 'adjustmentsOnly'::character varying])::text[])))
);


--
-- Name: commerce_orderstatus_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_orderstatus_emails (
    id integer NOT NULL,
    "orderStatusId" integer NOT NULL,
    "emailId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_orderstatus_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_orderstatus_emails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_orderstatus_emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_orderstatus_emails_id_seq OWNED BY public.commerce_orderstatus_emails.id;


--
-- Name: commerce_orderstatuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_orderstatuses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    color character varying(255) DEFAULT 'green'::character varying NOT NULL,
    description character varying(255),
    "dateDeleted" timestamp(0) without time zone,
    "sortOrder" integer,
    "default" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT commerce_orderstatuses_color_check CHECK (((color)::text = ANY ((ARRAY['green'::character varying, 'orange'::character varying, 'red'::character varying, 'blue'::character varying, 'yellow'::character varying, 'pink'::character varying, 'purple'::character varying, 'turquoise'::character varying, 'light'::character varying, 'grey'::character varying, 'black'::character varying])::text[])))
);


--
-- Name: commerce_orderstatuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_orderstatuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_orderstatuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_orderstatuses_id_seq OWNED BY public.commerce_orderstatuses.id;


--
-- Name: commerce_paymentcurrencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_paymentcurrencies (
    id integer NOT NULL,
    iso character varying(3) NOT NULL,
    "primary" boolean DEFAULT false NOT NULL,
    rate numeric(14,4) DEFAULT 0 NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_paymentcurrencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_paymentcurrencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_paymentcurrencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_paymentcurrencies_id_seq OWNED BY public.commerce_paymentcurrencies.id;


--
-- Name: commerce_paymentsources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_paymentsources (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "gatewayId" integer NOT NULL,
    token character varying(255) NOT NULL,
    description character varying(255),
    response text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_paymentsources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_paymentsources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_paymentsources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_paymentsources_id_seq OWNED BY public.commerce_paymentsources.id;


--
-- Name: commerce_pdfs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_pdfs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    description character varying(255),
    "templatePath" character varying(255) NOT NULL,
    "fileNameFormat" character varying(255),
    enabled boolean,
    "isDefault" boolean,
    "sortOrder" integer,
    language character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_pdfs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_pdfs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_pdfs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_pdfs_id_seq OWNED BY public.commerce_pdfs.id;


--
-- Name: commerce_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_plans (
    id integer NOT NULL,
    "gatewayId" integer,
    "planInformationId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    reference character varying(255) NOT NULL,
    enabled boolean NOT NULL,
    "planData" text,
    "isArchived" boolean NOT NULL,
    "dateArchived" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "sortOrder" integer,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_plans_id_seq OWNED BY public.commerce_plans.id;


--
-- Name: commerce_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_products (
    id integer NOT NULL,
    "typeId" integer,
    "taxCategoryId" integer NOT NULL,
    "shippingCategoryId" integer NOT NULL,
    "defaultVariantId" integer,
    "postDate" timestamp(0) without time zone,
    "expiryDate" timestamp(0) without time zone,
    promotable boolean,
    "availableForPurchase" boolean,
    "freeShipping" boolean,
    "defaultSku" character varying(255),
    "defaultPrice" numeric(14,4),
    "defaultHeight" numeric(14,4),
    "defaultLength" numeric(14,4),
    "defaultWidth" numeric(14,4),
    "defaultWeight" numeric(14,4),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_producttypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_producttypes (
    id integer NOT NULL,
    "fieldLayoutId" integer,
    "variantFieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "hasDimensions" boolean,
    "hasVariants" boolean,
    "hasVariantTitleField" boolean,
    "titleFormat" character varying(255) NOT NULL,
    "hasProductTitleField" boolean,
    "productTitleFormat" character varying(255),
    "skuFormat" character varying(255),
    "descriptionFormat" character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_producttypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_producttypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_producttypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_producttypes_id_seq OWNED BY public.commerce_producttypes.id;


--
-- Name: commerce_producttypes_shippingcategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_producttypes_shippingcategories (
    id integer NOT NULL,
    "productTypeId" integer NOT NULL,
    "shippingCategoryId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_producttypes_shippingcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_producttypes_shippingcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_producttypes_shippingcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_producttypes_shippingcategories_id_seq OWNED BY public.commerce_producttypes_shippingcategories.id;


--
-- Name: commerce_producttypes_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_producttypes_sites (
    id integer NOT NULL,
    "productTypeId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "uriFormat" text,
    template character varying(500),
    "hasUrls" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_producttypes_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_producttypes_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_producttypes_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_producttypes_sites_id_seq OWNED BY public.commerce_producttypes_sites.id;


--
-- Name: commerce_producttypes_taxcategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_producttypes_taxcategories (
    id integer NOT NULL,
    "productTypeId" integer NOT NULL,
    "taxCategoryId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_producttypes_taxcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_producttypes_taxcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_producttypes_taxcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_producttypes_taxcategories_id_seq OWNED BY public.commerce_producttypes_taxcategories.id;


--
-- Name: commerce_purchasables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_purchasables (
    id integer NOT NULL,
    sku character varying(255) NOT NULL,
    price numeric(14,4) NOT NULL,
    description text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_purchasables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_purchasables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_purchasables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_purchasables_id_seq OWNED BY public.commerce_purchasables.id;


--
-- Name: commerce_sale_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_sale_categories (
    id integer NOT NULL,
    "saleId" integer NOT NULL,
    "categoryId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_sale_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_sale_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_sale_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_sale_categories_id_seq OWNED BY public.commerce_sale_categories.id;


--
-- Name: commerce_sale_purchasables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_sale_purchasables (
    id integer NOT NULL,
    "saleId" integer NOT NULL,
    "purchasableId" integer NOT NULL,
    "purchasableType" character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_sale_purchasables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_sale_purchasables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_sale_purchasables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_sale_purchasables_id_seq OWNED BY public.commerce_sale_purchasables.id;


--
-- Name: commerce_sale_usergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_sale_usergroups (
    id integer NOT NULL,
    "saleId" integer NOT NULL,
    "userGroupId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_sale_usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_sale_usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_sale_usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_sale_usergroups_id_seq OWNED BY public.commerce_sale_usergroups.id;


--
-- Name: commerce_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_sales (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "dateFrom" timestamp(0) without time zone,
    "dateTo" timestamp(0) without time zone,
    apply character varying(255) NOT NULL,
    "applyAmount" numeric(14,4) NOT NULL,
    "allGroups" boolean,
    "allPurchasables" boolean,
    "allCategories" boolean,
    "categoryRelationshipType" character varying(255) DEFAULT 'element'::character varying NOT NULL,
    enabled boolean,
    "ignorePrevious" boolean,
    "stopProcessing" boolean,
    "sortOrder" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT commerce_sales_apply_check CHECK (((apply)::text = ANY ((ARRAY['toPercent'::character varying, 'toFlat'::character varying, 'byPercent'::character varying, 'byFlat'::character varying])::text[]))),
    CONSTRAINT "commerce_sales_categoryRelationshipType_check" CHECK ((("categoryRelationshipType")::text = ANY ((ARRAY['element'::character varying, 'sourceElement'::character varying, 'targetElement'::character varying])::text[])))
);


--
-- Name: commerce_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_sales_id_seq OWNED BY public.commerce_sales.id;


--
-- Name: commerce_shippingcategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_shippingcategories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    description character varying(255),
    "default" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_shippingcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_shippingcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_shippingcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_shippingcategories_id_seq OWNED BY public.commerce_shippingcategories.id;


--
-- Name: commerce_shippingmethods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_shippingmethods (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    enabled boolean,
    "isLite" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_shippingmethods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_shippingmethods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_shippingmethods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_shippingmethods_id_seq OWNED BY public.commerce_shippingmethods.id;


--
-- Name: commerce_shippingrule_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_shippingrule_categories (
    id integer NOT NULL,
    "shippingRuleId" integer,
    "shippingCategoryId" integer,
    condition character varying(255) NOT NULL,
    "perItemRate" numeric(14,4),
    "weightRate" numeric(14,4),
    "percentageRate" numeric(14,4),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT commerce_shippingrule_categories_condition_check CHECK (((condition)::text = ANY ((ARRAY['allow'::character varying, 'disallow'::character varying, 'require'::character varying])::text[])))
);


--
-- Name: commerce_shippingrule_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_shippingrule_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_shippingrule_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_shippingrule_categories_id_seq OWNED BY public.commerce_shippingrule_categories.id;


--
-- Name: commerce_shippingrules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_shippingrules (
    id integer NOT NULL,
    "shippingZoneId" integer,
    "methodId" integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    priority integer DEFAULT 0 NOT NULL,
    enabled boolean,
    "minQty" integer DEFAULT 0 NOT NULL,
    "maxQty" integer DEFAULT 0 NOT NULL,
    "minTotal" numeric(14,4) DEFAULT 0 NOT NULL,
    "maxTotal" numeric(14,4) DEFAULT 0 NOT NULL,
    "minWeight" numeric(14,4) DEFAULT 0 NOT NULL,
    "maxWeight" numeric(14,4) DEFAULT 0 NOT NULL,
    "baseRate" numeric(14,4) DEFAULT 0 NOT NULL,
    "perItemRate" numeric(14,4) DEFAULT 0 NOT NULL,
    "weightRate" numeric(14,4) DEFAULT 0 NOT NULL,
    "percentageRate" numeric(14,4) DEFAULT 0 NOT NULL,
    "minRate" numeric(14,4) DEFAULT 0 NOT NULL,
    "maxRate" numeric(14,4) DEFAULT 0 NOT NULL,
    "isLite" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_shippingrules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_shippingrules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_shippingrules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_shippingrules_id_seq OWNED BY public.commerce_shippingrules.id;


--
-- Name: commerce_shippingzone_countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_shippingzone_countries (
    id integer NOT NULL,
    "shippingZoneId" integer NOT NULL,
    "countryId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_shippingzone_countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_shippingzone_countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_shippingzone_countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_shippingzone_countries_id_seq OWNED BY public.commerce_shippingzone_countries.id;


--
-- Name: commerce_shippingzone_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_shippingzone_states (
    id integer NOT NULL,
    "shippingZoneId" integer NOT NULL,
    "stateId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_shippingzone_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_shippingzone_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_shippingzone_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_shippingzone_states_id_seq OWNED BY public.commerce_shippingzone_states.id;


--
-- Name: commerce_shippingzones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_shippingzones (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    "isCountryBased" boolean,
    "zipCodeConditionFormula" text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_shippingzones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_shippingzones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_shippingzones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_shippingzones_id_seq OWNED BY public.commerce_shippingzones.id;


--
-- Name: commerce_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_states (
    id integer NOT NULL,
    "countryId" integer NOT NULL,
    name character varying(255) NOT NULL,
    abbreviation character varying(255),
    "sortOrder" integer,
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_states_id_seq OWNED BY public.commerce_states.id;


--
-- Name: commerce_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_subscriptions (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "planId" integer,
    "gatewayId" integer,
    "orderId" integer,
    reference character varying(255) NOT NULL,
    "subscriptionData" text,
    "trialDays" integer NOT NULL,
    "nextPaymentDate" timestamp(0) without time zone,
    "hasStarted" boolean DEFAULT true NOT NULL,
    "isSuspended" boolean DEFAULT false NOT NULL,
    "dateSuspended" timestamp(0) without time zone,
    "isCanceled" boolean NOT NULL,
    "dateCanceled" timestamp(0) without time zone,
    "isExpired" boolean NOT NULL,
    "dateExpired" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_subscriptions_id_seq OWNED BY public.commerce_subscriptions.id;


--
-- Name: commerce_taxcategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_taxcategories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    description character varying(255),
    "default" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_taxcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_taxcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_taxcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_taxcategories_id_seq OWNED BY public.commerce_taxcategories.id;


--
-- Name: commerce_taxrates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_taxrates (
    id integer NOT NULL,
    "taxZoneId" integer,
    "isEverywhere" boolean,
    "taxCategoryId" integer,
    name character varying(255) NOT NULL,
    code character varying(255),
    rate numeric(14,10) NOT NULL,
    include boolean,
    "isVat" boolean,
    taxable character varying(255) NOT NULL,
    "isLite" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT commerce_taxrates_taxable_check CHECK (((taxable)::text = ANY ((ARRAY['price'::character varying, 'shipping'::character varying, 'price_shipping'::character varying, 'order_total_shipping'::character varying, 'order_total_price'::character varying])::text[])))
);


--
-- Name: commerce_taxrates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_taxrates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_taxrates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_taxrates_id_seq OWNED BY public.commerce_taxrates.id;


--
-- Name: commerce_taxzone_countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_taxzone_countries (
    id integer NOT NULL,
    "taxZoneId" integer NOT NULL,
    "countryId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_taxzone_countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_taxzone_countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_taxzone_countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_taxzone_countries_id_seq OWNED BY public.commerce_taxzone_countries.id;


--
-- Name: commerce_taxzone_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_taxzone_states (
    id integer NOT NULL,
    "taxZoneId" integer NOT NULL,
    "stateId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_taxzone_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_taxzone_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_taxzone_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_taxzone_states_id_seq OWNED BY public.commerce_taxzone_states.id;


--
-- Name: commerce_taxzones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_taxzones (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    "isCountryBased" boolean,
    "zipCodeConditionFormula" text,
    "default" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: commerce_taxzones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_taxzones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_taxzones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_taxzones_id_seq OWNED BY public.commerce_taxzones.id;


--
-- Name: commerce_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_transactions (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    "parentId" integer,
    "gatewayId" integer,
    "userId" integer,
    hash character varying(32),
    type character varying(255) NOT NULL,
    amount numeric(14,4),
    "paymentAmount" numeric(14,4),
    currency character varying(255),
    "paymentCurrency" character varying(255),
    "paymentRate" numeric(14,4),
    status character varying(255) NOT NULL,
    reference character varying(255),
    code character varying(255),
    message text,
    note text,
    response text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT commerce_transactions_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'redirect'::character varying, 'success'::character varying, 'failed'::character varying, 'processing'::character varying])::text[]))),
    CONSTRAINT commerce_transactions_type_check CHECK (((type)::text = ANY ((ARRAY['authorize'::character varying, 'capture'::character varying, 'purchase'::character varying, 'refund'::character varying])::text[])))
);


--
-- Name: commerce_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commerce_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commerce_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commerce_transactions_id_seq OWNED BY public.commerce_transactions.id;


--
-- Name: commerce_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commerce_variants (
    id integer NOT NULL,
    "productId" integer,
    sku character varying(255) NOT NULL,
    "isDefault" boolean,
    price numeric(14,4) NOT NULL,
    "sortOrder" integer,
    width numeric(14,4),
    height numeric(14,4),
    length numeric(14,4),
    weight numeric(14,4),
    stock integer DEFAULT 0 NOT NULL,
    "hasUnlimitedStock" boolean,
    "minQty" integer,
    "maxQty" integer,
    "deletedWithProduct" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content (
    id integer NOT NULL,
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    title character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    "field_errorHeadline" text,
    "field_errorText" text
);


--
-- Name: content_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_id_seq OWNED BY public.content.id;


--
-- Name: craftidtokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.craftidtokens (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "accessToken" text NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: craftidtokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.craftidtokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: craftidtokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.craftidtokens_id_seq OWNED BY public.craftidtokens.id;


--
-- Name: deprecationerrors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deprecationerrors (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    fingerprint character varying(255) NOT NULL,
    "lastOccurrence" timestamp(0) without time zone NOT NULL,
    file character varying(255) NOT NULL,
    line smallint,
    message text,
    traces text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deprecationerrors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deprecationerrors_id_seq OWNED BY public.deprecationerrors.id;


--
-- Name: drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drafts (
    id integer NOT NULL,
    "sourceId" integer,
    "creatorId" integer,
    name character varying(255) NOT NULL,
    notes text,
    "trackChanges" boolean DEFAULT false NOT NULL,
    "dateLastMerged" timestamp(0) without time zone,
    saved boolean DEFAULT true NOT NULL
);


--
-- Name: drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.drafts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.drafts_id_seq OWNED BY public.drafts.id;


--
-- Name: elementindexsettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elementindexsettings (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    settings text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: elementindexsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elementindexsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elementindexsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elementindexsettings_id_seq OWNED BY public.elementindexsettings.id;


--
-- Name: elements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elements (
    id integer NOT NULL,
    "draftId" integer,
    "revisionId" integer,
    "fieldLayoutId" integer,
    type character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: elements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elements_id_seq OWNED BY public.elements.id;


--
-- Name: elements_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elements_sites (
    id integer NOT NULL,
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    slug character varying(255),
    uri character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: elements_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elements_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elements_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elements_sites_id_seq OWNED BY public.elements_sites.id;


--
-- Name: entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entries (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "parentId" integer,
    "typeId" integer NOT NULL,
    "authorId" integer,
    "postDate" timestamp(0) without time zone,
    "expiryDate" timestamp(0) without time zone,
    "deletedWithEntryType" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: entrytypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entrytypes (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "hasTitleField" boolean DEFAULT true NOT NULL,
    "titleTranslationMethod" character varying(255) DEFAULT 'site'::character varying NOT NULL,
    "titleTranslationKeyFormat" text,
    "titleFormat" character varying(255),
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: entrytypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entrytypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entrytypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entrytypes_id_seq OWNED BY public.entrytypes.id;


--
-- Name: fieldgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldgroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldgroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldgroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldgroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldgroups_id_seq OWNED BY public.fieldgroups.id;


--
-- Name: fieldlayoutfields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldlayoutfields (
    id integer NOT NULL,
    "layoutId" integer NOT NULL,
    "tabId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    required boolean DEFAULT false NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldlayoutfields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldlayoutfields_id_seq OWNED BY public.fieldlayoutfields.id;


--
-- Name: fieldlayouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldlayouts (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldlayouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldlayouts_id_seq OWNED BY public.fieldlayouts.id;


--
-- Name: fieldlayouttabs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldlayouttabs (
    id integer NOT NULL,
    "layoutId" integer NOT NULL,
    name character varying(255) NOT NULL,
    elements text,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldlayouttabs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldlayouttabs_id_seq OWNED BY public.fieldlayouttabs.id;


--
-- Name: fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fields (
    id integer NOT NULL,
    "groupId" integer,
    name character varying(255) NOT NULL,
    handle character varying(64) NOT NULL,
    context character varying(255) DEFAULT 'global'::character varying NOT NULL,
    instructions text,
    searchable boolean DEFAULT true NOT NULL,
    "translationMethod" character varying(255) DEFAULT 'none'::character varying NOT NULL,
    "translationKeyFormat" text,
    type character varying(255) NOT NULL,
    settings text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fields_id_seq OWNED BY public.fields.id;


--
-- Name: globalsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.globalsets (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "fieldLayoutId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: globalsets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.globalsets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: globalsets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.globalsets_id_seq OWNED BY public.globalsets.id;


--
-- Name: gqlschemas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gqlschemas (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    scope text,
    "isPublic" boolean DEFAULT false NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: gqlschemas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gqlschemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gqlschemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gqlschemas_id_seq OWNED BY public.gqlschemas.id;


--
-- Name: gqltokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gqltokens (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "accessToken" character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "lastUsed" timestamp(0) without time zone,
    "schemaId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: gqltokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gqltokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gqltokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gqltokens_id_seq OWNED BY public.gqltokens.id;


--
-- Name: info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.info (
    id integer NOT NULL,
    version character varying(50) NOT NULL,
    "schemaVersion" character varying(15) NOT NULL,
    maintenance boolean DEFAULT false NOT NULL,
    "configVersion" character(12) DEFAULT '000000000000'::bpchar NOT NULL,
    "fieldVersion" character(12) DEFAULT '000000000000'::bpchar NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: info_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.info_id_seq OWNED BY public.info.id;


--
-- Name: matrixblocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matrixblocks (
    id integer NOT NULL,
    "ownerId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    "typeId" integer NOT NULL,
    "sortOrder" smallint,
    "deletedWithOwner" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: matrixblocktypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matrixblocktypes (
    id integer NOT NULL,
    "fieldId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matrixblocktypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matrixblocktypes_id_seq OWNED BY public.matrixblocktypes.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    track character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "applyTime" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: notifications_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications_notifications (
    id integer NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    type character varying(255) NOT NULL,
    notifiable integer NOT NULL,
    data text NOT NULL,
    read_at timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


--
-- Name: notifications_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_notifications_id_seq OWNED BY public.notifications_notifications.id;


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugins (
    id integer NOT NULL,
    handle character varying(255) NOT NULL,
    version character varying(255) NOT NULL,
    "schemaVersion" character varying(255) NOT NULL,
    "licenseKeyStatus" character varying(255) DEFAULT 'unknown'::character varying NOT NULL,
    "licensedEdition" character varying(255),
    "installDate" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "plugins_licenseKeyStatus_check" CHECK ((("licenseKeyStatus")::text = ANY ((ARRAY['valid'::character varying, 'trial'::character varying, 'invalid'::character varying, 'mismatched'::character varying, 'astray'::character varying, 'unknown'::character varying])::text[])))
);


--
-- Name: plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plugins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plugins_id_seq OWNED BY public.plugins.id;


--
-- Name: projectconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projectconfig (
    path character varying(255) NOT NULL,
    value text NOT NULL
);


--
-- Name: projectconfignames; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projectconfignames (
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    name character varying(255) NOT NULL
);


--
-- Name: queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queue (
    id integer NOT NULL,
    channel character varying(255) DEFAULT 'queue'::character varying NOT NULL,
    job bytea NOT NULL,
    description text,
    "timePushed" integer NOT NULL,
    ttr integer NOT NULL,
    delay integer DEFAULT 0 NOT NULL,
    priority integer DEFAULT 1024 NOT NULL,
    "dateReserved" timestamp(0) without time zone,
    "timeUpdated" integer,
    progress smallint DEFAULT 0 NOT NULL,
    "progressLabel" character varying(255),
    attempt integer,
    fail boolean DEFAULT false,
    "dateFailed" timestamp(0) without time zone,
    error text
);


--
-- Name: queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.queue_id_seq OWNED BY public.queue.id;


--
-- Name: relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relations (
    id integer NOT NULL,
    "fieldId" integer NOT NULL,
    "sourceId" integer NOT NULL,
    "sourceSiteId" integer,
    "targetId" integer NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: relations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.relations_id_seq OWNED BY public.relations.id;


--
-- Name: resourcepaths; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resourcepaths (
    hash character varying(255) NOT NULL,
    path character varying(255) NOT NULL
);


--
-- Name: revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.revisions (
    id integer NOT NULL,
    "sourceId" integer NOT NULL,
    "creatorId" integer,
    num integer NOT NULL,
    notes text
);


--
-- Name: revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.revisions_id_seq OWNED BY public.revisions.id;


--
-- Name: searchindex; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.searchindex (
    "elementId" integer NOT NULL,
    attribute character varying(25) NOT NULL,
    "fieldId" integer NOT NULL,
    "siteId" integer NOT NULL,
    keywords text NOT NULL,
    keywords_vector tsvector NOT NULL
);


--
-- Name: sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections (
    id integer NOT NULL,
    "structureId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    type character varying(255) DEFAULT 'channel'::character varying NOT NULL,
    "enableVersioning" boolean DEFAULT false NOT NULL,
    "propagationMethod" character varying(255) DEFAULT 'all'::character varying NOT NULL,
    "previewTargets" text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT sections_type_check CHECK (((type)::text = ANY ((ARRAY['single'::character varying, 'channel'::character varying, 'structure'::character varying])::text[])))
);


--
-- Name: sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sections_id_seq OWNED BY public.sections.id;


--
-- Name: sections_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections_sites (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    "uriFormat" text,
    template character varying(500),
    "enabledByDefault" boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sections_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sections_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sections_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sections_sites_id_seq OWNED BY public.sections_sites.id;


--
-- Name: sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequences (
    name character varying(255) NOT NULL,
    next integer DEFAULT 1 NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token character(100) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: shunnedmessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shunnedmessages (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    message character varying(255) NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shunnedmessages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shunnedmessages_id_seq OWNED BY public.shunnedmessages.id;


--
-- Name: sitegroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sitegroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sitegroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sitegroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sitegroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sitegroups_id_seq OWNED BY public.sitegroups.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "primary" boolean NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    language character varying(12) NOT NULL,
    "hasUrls" boolean DEFAULT false NOT NULL,
    "baseUrl" character varying(255),
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: structureelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structureelements (
    id integer NOT NULL,
    "structureId" integer NOT NULL,
    "elementId" integer,
    root integer,
    lft integer NOT NULL,
    rgt integer NOT NULL,
    level smallint NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: structureelements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.structureelements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: structureelements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.structureelements_id_seq OWNED BY public.structureelements.id;


--
-- Name: structures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structures (
    id integer NOT NULL,
    "maxLevels" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: structures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.structures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: structures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.structures_id_seq OWNED BY public.structures.id;


--
-- Name: systemmessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.systemmessages (
    id integer NOT NULL,
    language character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: systemmessages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.systemmessages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: systemmessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.systemmessages_id_seq OWNED BY public.systemmessages.id;


--
-- Name: taggroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "fieldLayoutId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: taggroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taggroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taggroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taggroups_id_seq OWNED BY public.taggroups.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "deletedWithGroup" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: templatecacheelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templatecacheelements (
    id integer NOT NULL,
    "cacheId" integer NOT NULL,
    "elementId" integer NOT NULL
);


--
-- Name: templatecacheelements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.templatecacheelements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templatecacheelements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.templatecacheelements_id_seq OWNED BY public.templatecacheelements.id;


--
-- Name: templatecachequeries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templatecachequeries (
    id integer NOT NULL,
    "cacheId" integer NOT NULL,
    type character varying(255) NOT NULL,
    query text NOT NULL
);


--
-- Name: templatecachequeries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.templatecachequeries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templatecachequeries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.templatecachequeries_id_seq OWNED BY public.templatecachequeries.id;


--
-- Name: templatecaches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templatecaches (
    id integer NOT NULL,
    "siteId" integer NOT NULL,
    "cacheKey" character varying(255) NOT NULL,
    path character varying(255),
    "expiryDate" timestamp(0) without time zone NOT NULL,
    body text NOT NULL
);


--
-- Name: templatecaches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.templatecaches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templatecaches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.templatecaches_id_seq OWNED BY public.templatecaches.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id integer NOT NULL,
    token character(32) NOT NULL,
    route text,
    "usageLimit" smallint,
    "usageCount" smallint,
    "expiryDate" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: usergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    description text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usergroups_id_seq OWNED BY public.usergroups.id;


--
-- Name: usergroups_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroups_users (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "userId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: usergroups_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usergroups_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usergroups_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usergroups_users_id_seq OWNED BY public.usergroups_users.id;


--
-- Name: userpermissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpermissions (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: userpermissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.userpermissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpermissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.userpermissions_id_seq OWNED BY public.userpermissions.id;


--
-- Name: userpermissions_usergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpermissions_usergroups (
    id integer NOT NULL,
    "permissionId" integer NOT NULL,
    "groupId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.userpermissions_usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.userpermissions_usergroups_id_seq OWNED BY public.userpermissions_usergroups.id;


--
-- Name: userpermissions_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpermissions_users (
    id integer NOT NULL,
    "permissionId" integer NOT NULL,
    "userId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.userpermissions_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.userpermissions_users_id_seq OWNED BY public.userpermissions_users.id;


--
-- Name: userpreferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpreferences (
    "userId" integer NOT NULL,
    preferences text
);


--
-- Name: userpreferences_userId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."userpreferences_userId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpreferences_userId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."userpreferences_userId_seq" OWNED BY public.userpreferences."userId";


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    "photoId" integer,
    "firstName" character varying(100),
    "lastName" character varying(100),
    email character varying(255) NOT NULL,
    password character varying(255),
    admin boolean DEFAULT false NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    suspended boolean DEFAULT false NOT NULL,
    pending boolean DEFAULT false NOT NULL,
    "lastLoginDate" timestamp(0) without time zone,
    "lastLoginAttemptIp" character varying(45),
    "invalidLoginWindowStart" timestamp(0) without time zone,
    "invalidLoginCount" smallint,
    "lastInvalidLoginDate" timestamp(0) without time zone,
    "lockoutDate" timestamp(0) without time zone,
    "hasDashboard" boolean DEFAULT false NOT NULL,
    "verificationCode" character varying(255),
    "verificationCodeIssuedDate" timestamp(0) without time zone,
    "unverifiedEmail" character varying(255),
    "passwordResetRequired" boolean DEFAULT false NOT NULL,
    "lastPasswordChangeDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: volumefolders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volumefolders (
    id integer NOT NULL,
    "parentId" integer,
    "volumeId" integer,
    name character varying(255) NOT NULL,
    path character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: volumefolders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.volumefolders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: volumefolders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.volumefolders_id_seq OWNED BY public.volumefolders.id;


--
-- Name: volumes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volumes (
    id integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    url character varying(255),
    "titleTranslationMethod" character varying(255) DEFAULT 'site'::character varying NOT NULL,
    "titleTranslationKeyFormat" text,
    settings text,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: volumes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.volumes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: volumes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.volumes_id_seq OWNED BY public.volumes.id;


--
-- Name: widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.widgets (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    type character varying(255) NOT NULL,
    "sortOrder" smallint,
    colspan smallint,
    settings text,
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: widgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.widgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.widgets_id_seq OWNED BY public.widgets.id;


--
-- Name: assetindexdata id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assetindexdata ALTER COLUMN id SET DEFAULT nextval('public.assetindexdata_id_seq'::regclass);


--
-- Name: assettransformindex id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransformindex ALTER COLUMN id SET DEFAULT nextval('public.assettransformindex_id_seq'::regclass);


--
-- Name: assettransforms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransforms ALTER COLUMN id SET DEFAULT nextval('public.assettransforms_id_seq'::regclass);


--
-- Name: categorygroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups ALTER COLUMN id SET DEFAULT nextval('public.categorygroups_id_seq'::regclass);


--
-- Name: categorygroups_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites ALTER COLUMN id SET DEFAULT nextval('public.categorygroups_sites_id_seq'::regclass);


--
-- Name: commerce_addresses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_addresses ALTER COLUMN id SET DEFAULT nextval('public.commerce_addresses_id_seq'::regclass);


--
-- Name: commerce_countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_countries ALTER COLUMN id SET DEFAULT nextval('public.commerce_countries_id_seq'::regclass);


--
-- Name: commerce_customer_discountuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customer_discountuses ALTER COLUMN id SET DEFAULT nextval('public.commerce_customer_discountuses_id_seq'::regclass);


--
-- Name: commerce_customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers ALTER COLUMN id SET DEFAULT nextval('public.commerce_customers_id_seq'::regclass);


--
-- Name: commerce_customers_addresses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers_addresses ALTER COLUMN id SET DEFAULT nextval('public.commerce_customers_addresses_id_seq'::regclass);


--
-- Name: commerce_discount_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_categories ALTER COLUMN id SET DEFAULT nextval('public.commerce_discount_categories_id_seq'::regclass);


--
-- Name: commerce_discount_purchasables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_purchasables ALTER COLUMN id SET DEFAULT nextval('public.commerce_discount_purchasables_id_seq'::regclass);


--
-- Name: commerce_discount_usergroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_usergroups ALTER COLUMN id SET DEFAULT nextval('public.commerce_discount_usergroups_id_seq'::regclass);


--
-- Name: commerce_discounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discounts ALTER COLUMN id SET DEFAULT nextval('public.commerce_discounts_id_seq'::regclass);


--
-- Name: commerce_donations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_donations ALTER COLUMN id SET DEFAULT nextval('public.commerce_donations_id_seq'::regclass);


--
-- Name: commerce_email_discountuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_email_discountuses ALTER COLUMN id SET DEFAULT nextval('public.commerce_email_discountuses_id_seq'::regclass);


--
-- Name: commerce_emails id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_emails ALTER COLUMN id SET DEFAULT nextval('public.commerce_emails_id_seq'::regclass);


--
-- Name: commerce_gateways id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_gateways ALTER COLUMN id SET DEFAULT nextval('public.commerce_gateways_id_seq'::regclass);


--
-- Name: commerce_lineitems id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitems ALTER COLUMN id SET DEFAULT nextval('public.commerce_lineitems_id_seq'::regclass);


--
-- Name: commerce_lineitemstatuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitemstatuses ALTER COLUMN id SET DEFAULT nextval('public.commerce_lineitemstatuses_id_seq'::regclass);


--
-- Name: commerce_orderadjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderadjustments ALTER COLUMN id SET DEFAULT nextval('public.commerce_orderadjustments_id_seq'::regclass);


--
-- Name: commerce_orderhistories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderhistories ALTER COLUMN id SET DEFAULT nextval('public.commerce_orderhistories_id_seq'::regclass);


--
-- Name: commerce_orderstatus_emails id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderstatus_emails ALTER COLUMN id SET DEFAULT nextval('public.commerce_orderstatus_emails_id_seq'::regclass);


--
-- Name: commerce_orderstatuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderstatuses ALTER COLUMN id SET DEFAULT nextval('public.commerce_orderstatuses_id_seq'::regclass);


--
-- Name: commerce_paymentcurrencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_paymentcurrencies ALTER COLUMN id SET DEFAULT nextval('public.commerce_paymentcurrencies_id_seq'::regclass);


--
-- Name: commerce_paymentsources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_paymentsources ALTER COLUMN id SET DEFAULT nextval('public.commerce_paymentsources_id_seq'::regclass);


--
-- Name: commerce_pdfs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_pdfs ALTER COLUMN id SET DEFAULT nextval('public.commerce_pdfs_id_seq'::regclass);


--
-- Name: commerce_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_plans ALTER COLUMN id SET DEFAULT nextval('public.commerce_plans_id_seq'::regclass);


--
-- Name: commerce_producttypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes ALTER COLUMN id SET DEFAULT nextval('public.commerce_producttypes_id_seq'::regclass);


--
-- Name: commerce_producttypes_shippingcategories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_shippingcategories ALTER COLUMN id SET DEFAULT nextval('public.commerce_producttypes_shippingcategories_id_seq'::regclass);


--
-- Name: commerce_producttypes_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_sites ALTER COLUMN id SET DEFAULT nextval('public.commerce_producttypes_sites_id_seq'::regclass);


--
-- Name: commerce_producttypes_taxcategories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_taxcategories ALTER COLUMN id SET DEFAULT nextval('public.commerce_producttypes_taxcategories_id_seq'::regclass);


--
-- Name: commerce_purchasables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_purchasables ALTER COLUMN id SET DEFAULT nextval('public.commerce_purchasables_id_seq'::regclass);


--
-- Name: commerce_sale_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_categories ALTER COLUMN id SET DEFAULT nextval('public.commerce_sale_categories_id_seq'::regclass);


--
-- Name: commerce_sale_purchasables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_purchasables ALTER COLUMN id SET DEFAULT nextval('public.commerce_sale_purchasables_id_seq'::regclass);


--
-- Name: commerce_sale_usergroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_usergroups ALTER COLUMN id SET DEFAULT nextval('public.commerce_sale_usergroups_id_seq'::regclass);


--
-- Name: commerce_sales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sales ALTER COLUMN id SET DEFAULT nextval('public.commerce_sales_id_seq'::regclass);


--
-- Name: commerce_shippingcategories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingcategories ALTER COLUMN id SET DEFAULT nextval('public.commerce_shippingcategories_id_seq'::regclass);


--
-- Name: commerce_shippingmethods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingmethods ALTER COLUMN id SET DEFAULT nextval('public.commerce_shippingmethods_id_seq'::regclass);


--
-- Name: commerce_shippingrule_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrule_categories ALTER COLUMN id SET DEFAULT nextval('public.commerce_shippingrule_categories_id_seq'::regclass);


--
-- Name: commerce_shippingrules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrules ALTER COLUMN id SET DEFAULT nextval('public.commerce_shippingrules_id_seq'::regclass);


--
-- Name: commerce_shippingzone_countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_countries ALTER COLUMN id SET DEFAULT nextval('public.commerce_shippingzone_countries_id_seq'::regclass);


--
-- Name: commerce_shippingzone_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_states ALTER COLUMN id SET DEFAULT nextval('public.commerce_shippingzone_states_id_seq'::regclass);


--
-- Name: commerce_shippingzones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzones ALTER COLUMN id SET DEFAULT nextval('public.commerce_shippingzones_id_seq'::regclass);


--
-- Name: commerce_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_states ALTER COLUMN id SET DEFAULT nextval('public.commerce_states_id_seq'::regclass);


--
-- Name: commerce_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.commerce_subscriptions_id_seq'::regclass);


--
-- Name: commerce_taxcategories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxcategories ALTER COLUMN id SET DEFAULT nextval('public.commerce_taxcategories_id_seq'::regclass);


--
-- Name: commerce_taxrates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxrates ALTER COLUMN id SET DEFAULT nextval('public.commerce_taxrates_id_seq'::regclass);


--
-- Name: commerce_taxzone_countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_countries ALTER COLUMN id SET DEFAULT nextval('public.commerce_taxzone_countries_id_seq'::regclass);


--
-- Name: commerce_taxzone_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_states ALTER COLUMN id SET DEFAULT nextval('public.commerce_taxzone_states_id_seq'::regclass);


--
-- Name: commerce_taxzones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzones ALTER COLUMN id SET DEFAULT nextval('public.commerce_taxzones_id_seq'::regclass);


--
-- Name: commerce_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_transactions ALTER COLUMN id SET DEFAULT nextval('public.commerce_transactions_id_seq'::regclass);


--
-- Name: content id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content ALTER COLUMN id SET DEFAULT nextval('public.content_id_seq'::regclass);


--
-- Name: craftidtokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.craftidtokens ALTER COLUMN id SET DEFAULT nextval('public.craftidtokens_id_seq'::regclass);


--
-- Name: deprecationerrors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deprecationerrors ALTER COLUMN id SET DEFAULT nextval('public.deprecationerrors_id_seq'::regclass);


--
-- Name: drafts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts ALTER COLUMN id SET DEFAULT nextval('public.drafts_id_seq'::regclass);


--
-- Name: elementindexsettings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elementindexsettings ALTER COLUMN id SET DEFAULT nextval('public.elementindexsettings_id_seq'::regclass);


--
-- Name: elements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements ALTER COLUMN id SET DEFAULT nextval('public.elements_id_seq'::regclass);


--
-- Name: elements_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites ALTER COLUMN id SET DEFAULT nextval('public.elements_sites_id_seq'::regclass);


--
-- Name: entrytypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes ALTER COLUMN id SET DEFAULT nextval('public.entrytypes_id_seq'::regclass);


--
-- Name: fieldgroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldgroups ALTER COLUMN id SET DEFAULT nextval('public.fieldgroups_id_seq'::regclass);


--
-- Name: fieldlayoutfields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields ALTER COLUMN id SET DEFAULT nextval('public.fieldlayoutfields_id_seq'::regclass);


--
-- Name: fieldlayouts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouts ALTER COLUMN id SET DEFAULT nextval('public.fieldlayouts_id_seq'::regclass);


--
-- Name: fieldlayouttabs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouttabs ALTER COLUMN id SET DEFAULT nextval('public.fieldlayouttabs_id_seq'::regclass);


--
-- Name: fields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fields ALTER COLUMN id SET DEFAULT nextval('public.fields_id_seq'::regclass);


--
-- Name: globalsets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets ALTER COLUMN id SET DEFAULT nextval('public.globalsets_id_seq'::regclass);


--
-- Name: gqlschemas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqlschemas ALTER COLUMN id SET DEFAULT nextval('public.gqlschemas_id_seq'::regclass);


--
-- Name: gqltokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqltokens ALTER COLUMN id SET DEFAULT nextval('public.gqltokens_id_seq'::regclass);


--
-- Name: info id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.info ALTER COLUMN id SET DEFAULT nextval('public.info_id_seq'::regclass);


--
-- Name: matrixblocktypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes ALTER COLUMN id SET DEFAULT nextval('public.matrixblocktypes_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: notifications_notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications_notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_notifications_id_seq'::regclass);


--
-- Name: plugins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins ALTER COLUMN id SET DEFAULT nextval('public.plugins_id_seq'::regclass);


--
-- Name: queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue ALTER COLUMN id SET DEFAULT nextval('public.queue_id_seq'::regclass);


--
-- Name: relations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations ALTER COLUMN id SET DEFAULT nextval('public.relations_id_seq'::regclass);


--
-- Name: revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions ALTER COLUMN id SET DEFAULT nextval('public.revisions_id_seq'::regclass);


--
-- Name: sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections ALTER COLUMN id SET DEFAULT nextval('public.sections_id_seq'::regclass);


--
-- Name: sections_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites ALTER COLUMN id SET DEFAULT nextval('public.sections_sites_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: shunnedmessages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shunnedmessages ALTER COLUMN id SET DEFAULT nextval('public.shunnedmessages_id_seq'::regclass);


--
-- Name: sitegroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sitegroups ALTER COLUMN id SET DEFAULT nextval('public.sitegroups_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: structureelements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements ALTER COLUMN id SET DEFAULT nextval('public.structureelements_id_seq'::regclass);


--
-- Name: structures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structures ALTER COLUMN id SET DEFAULT nextval('public.structures_id_seq'::regclass);


--
-- Name: systemmessages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemmessages ALTER COLUMN id SET DEFAULT nextval('public.systemmessages_id_seq'::regclass);


--
-- Name: taggroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggroups ALTER COLUMN id SET DEFAULT nextval('public.taggroups_id_seq'::regclass);


--
-- Name: templatecacheelements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements ALTER COLUMN id SET DEFAULT nextval('public.templatecacheelements_id_seq'::regclass);


--
-- Name: templatecachequeries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecachequeries ALTER COLUMN id SET DEFAULT nextval('public.templatecachequeries_id_seq'::regclass);


--
-- Name: templatecaches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecaches ALTER COLUMN id SET DEFAULT nextval('public.templatecaches_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: usergroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups ALTER COLUMN id SET DEFAULT nextval('public.usergroups_id_seq'::regclass);


--
-- Name: usergroups_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users ALTER COLUMN id SET DEFAULT nextval('public.usergroups_users_id_seq'::regclass);


--
-- Name: userpermissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_id_seq'::regclass);


--
-- Name: userpermissions_usergroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_usergroups_id_seq'::regclass);


--
-- Name: userpermissions_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_users_id_seq'::regclass);


--
-- Name: userpreferences userId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpreferences ALTER COLUMN "userId" SET DEFAULT nextval('public."userpreferences_userId_seq"'::regclass);


--
-- Name: volumefolders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders ALTER COLUMN id SET DEFAULT nextval('public.volumefolders_id_seq'::regclass);


--
-- Name: volumes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumes ALTER COLUMN id SET DEFAULT nextval('public.volumes_id_seq'::regclass);


--
-- Name: widgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.widgets ALTER COLUMN id SET DEFAULT nextval('public.widgets_id_seq'::regclass);


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assettransforms; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: categorygroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: categorygroups_sites; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: changedattributes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (3, 1, 'username', '2021-03-30 18:23:28', false, 3);
INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (3, 1, 'firstName', '2021-03-30 18:23:28', false, 3);
INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (3, 1, 'lastName', '2021-03-30 18:23:28', false, 3);
INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (3, 1, 'password', '2021-03-30 18:23:28', false, 3);
INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (3, 1, 'lastPasswordChangeDate', '2021-03-30 18:23:28', false, 3);


--
-- Data for Name: changedfields; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_addresses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_countries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (1, 'Afghanistan', 'AF', NULL, 1, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a89ae681-54a4-4537-89e7-d95cc3030889');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (2, 'Aland Islands', 'AX', NULL, 2, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5f2c9d36-a798-46c9-b79c-812fb3b7f51d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (3, 'Albania', 'AL', NULL, 3, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fed8379e-7628-4bc9-b559-909e98511923');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (4, 'Algeria', 'DZ', NULL, 4, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '268325e7-8eac-4c7a-a541-7fb564e6b4c1');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (5, 'American Samoa', 'AS', NULL, 5, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f921b7dd-29a6-45c3-9e07-daa4e2d90a4b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (6, 'Andorra', 'AD', NULL, 6, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4d089aa4-f703-4cb8-8e48-da876e239928');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (7, 'Angola', 'AO', NULL, 7, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd6e26755-d1c5-45ed-b6d0-be54d4afa5a7');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (8, 'Anguilla', 'AI', NULL, 8, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4a317ab3-a5ec-46a7-8da3-fd5e1f569fb6');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (9, 'Antarctica', 'AQ', NULL, 9, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '75020e51-080d-45a4-a256-086bf3784bf8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (10, 'Antigua and Barbuda', 'AG', NULL, 10, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0b352797-3828-45ee-8015-0200aaf4a9d7');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (11, 'Argentina', 'AR', NULL, 11, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0d00f535-d70a-4ac0-b12b-b00bb7035529');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (12, 'Armenia', 'AM', NULL, 12, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd26a4f61-be5d-4f47-bd8b-aae9921ffb2b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (13, 'Aruba', 'AW', NULL, 13, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3a88ceeb-35a6-4ecc-a49b-651dac365c94');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (14, 'Australia', 'AU', NULL, 14, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a278ad39-0b9e-44d9-aa7b-e6ab357d3cd9');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (15, 'Austria', 'AT', NULL, 15, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '7357ae2b-a919-4f36-b1a3-69d3e276fa9e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (16, 'Azerbaijan', 'AZ', NULL, 16, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'caf4d2eb-7329-46a6-ad7c-5d24191690d1');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (17, 'Bahamas', 'BS', NULL, 17, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e975877b-88b5-40c3-87ed-db6c1900cb9d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (18, 'Bahrain', 'BH', NULL, 18, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fdacafe1-6678-4bf3-80ed-2fe4913f2831');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (19, 'Bangladesh', 'BD', NULL, 19, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd3c58fec-5ba7-4eb6-a61c-09d8f6b6899e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (20, 'Barbados', 'BB', NULL, 20, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '97c75838-0875-48cc-8748-f89584944fb4');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (21, 'Belarus', 'BY', NULL, 21, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5ca062ca-c76b-4bc7-a45e-aef0b7d0122c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (22, 'Belgium', 'BE', NULL, 22, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a3eb94f0-1234-460b-92f5-8f6e39bb74d5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (23, 'Belize', 'BZ', NULL, 23, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f586d9d1-254b-47a3-914f-f9c200130067');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (24, 'Benin', 'BJ', NULL, 24, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '68bd0b8f-1491-406c-8e85-f12c5ab9c831');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (25, 'Bermuda', 'BM', NULL, 25, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0be15059-350e-4ee8-ab98-176ce17c6716');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (26, 'Bhutan', 'BT', NULL, 26, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '80c3ccc1-1160-41df-a150-b58d7bd8eb80');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (27, 'Bolivia', 'BO', NULL, 27, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '470d4041-e44d-4def-b934-1b67b32364b8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (28, 'Bonaire, Sint Eustatius and Saba', 'BQ', NULL, 28, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'bfa583cc-dccf-45af-8d34-c1e3a38f120e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (29, 'Bosnia and Herzegovina', 'BA', NULL, 29, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c0cd0a8a-5589-4b09-b54a-7410e66b914b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (30, 'Botswana', 'BW', NULL, 30, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'aeeaa5e1-9f17-43ad-a22d-a6c6c3cbb42a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (31, 'Bouvet Island', 'BV', NULL, 31, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '66e55ac6-3805-43cc-a094-0fdd739289c4');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (32, 'Brazil', 'BR', NULL, 32, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '49563727-9d36-489a-9ae4-891b98b9567d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (33, 'British Indian Ocean Territory', 'IO', NULL, 33, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '39eb2043-6ad4-4436-9987-92979af9bf47');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (34, 'Brunei Darussalam', 'BN', NULL, 34, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '64c0f5a5-8786-4a72-a448-226778f637c7');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (35, 'Bulgaria', 'BG', NULL, 35, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '9bc451e0-3ad0-4f17-9984-5e96ad49e765');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (36, 'Burkina Faso', 'BF', NULL, 36, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3f09a1a8-1251-443b-89f5-b50718a9d289');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (37, 'Burma (Myanmar)', 'MM', NULL, 37, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '609ddca6-a695-40f4-8ee6-b0b632e05e5e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (38, 'Burundi', 'BI', NULL, 38, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c5d1174d-4744-4edb-baf1-8db4359a5147');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (39, 'Cambodia', 'KH', NULL, 39, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '65bcfe92-bb2e-4c18-9902-6a6f5102afa1');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (40, 'Cameroon', 'CM', NULL, 40, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '7ae6c6eb-63d6-4923-b376-91fcba5b1dd5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (41, 'Canada', 'CA', NULL, 41, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e18a6af0-437d-4f4e-b470-90adc0f4c9c7');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (42, 'Cape Verde', 'CV', NULL, 42, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '61e031ea-6c0f-4330-a710-791a085c88db');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (43, 'Cayman Islands', 'KY', NULL, 43, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0169ff40-c05f-4037-9a10-888c1872cd27');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (44, 'Central African Republic', 'CF', NULL, 44, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c9ef3205-14e2-4825-b1df-a0c85b9e3cee');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (45, 'Chad', 'TD', NULL, 45, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '53da0118-89ef-4f09-bdc5-08eaf267ad50');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (46, 'Chile', 'CL', NULL, 46, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'afe14b7f-67c2-4fda-b4f9-e0b933d58741');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (47, 'China', 'CN', NULL, 47, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd34b6666-addf-41a4-97d1-faac39053570');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (48, 'Christmas Island', 'CX', NULL, 48, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '540ebe07-14d7-4182-abdc-aeba6bc6e883');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (49, 'Cocos (Keeling) Islands', 'CC', NULL, 49, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '667fc3bd-2d2a-4926-9f51-4f65e0b9baa2');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (50, 'Colombia', 'CO', NULL, 50, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e238cd73-8b6c-4316-ac7b-2654ed83a1c4');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (51, 'Comoros', 'KM', NULL, 51, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3dd0beea-295e-4cdd-a74d-15705f476a04');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (52, 'Congo', 'CG', NULL, 52, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1fd988b2-2490-4296-a2f8-dc7be0cde33b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (53, 'Cook Islands', 'CK', NULL, 53, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '807962d5-3058-4c93-9f72-bca7c6dfa299');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (54, 'Costa Rica', 'CR', NULL, 54, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '761111af-1f2e-4e4d-9538-477cefea2f6a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (55, 'Croatia (Hrvatska)', 'HR', NULL, 55, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'ed528368-bfe5-452e-ade6-4ed0cf12744c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (56, 'Cuba', 'CU', NULL, 56, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8aeac9d8-1363-4d32-9db6-0616c476df7d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (57, 'Curacao', 'CW', NULL, 57, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3aa92880-650f-4c7f-a3be-abe372fff76f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (58, 'Cyprus', 'CY', NULL, 58, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '62ad924f-dc92-4a6d-befb-24f6f4c55230');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (59, 'Czech Republic', 'CZ', NULL, 59, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f9b0823b-1efe-46da-950c-28b6753961bf');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (60, 'Democratic Republic of Congo', 'CD', NULL, 60, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a753d12a-adea-40e6-bc0a-83eb5ec5c99f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (61, 'Denmark', 'DK', NULL, 61, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '80697d3f-1fe2-429c-a625-3c94c7716db4');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (62, 'Djibouti', 'DJ', NULL, 62, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b37ca45f-40d5-4467-bc7c-c198e79962d3');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (63, 'Dominica', 'DM', NULL, 63, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '54d7c165-21d1-4f14-9992-c9d163f7abcc');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (64, 'Dominican Republic', 'DO', NULL, 64, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '91014561-d966-4d17-b411-265175a8aab8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (65, 'Ecuador', 'EC', NULL, 65, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '309794d1-a05c-4c5f-ad9a-e672ee1db4ec');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (66, 'Egypt', 'EG', NULL, 66, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '26f30282-456d-4535-8207-222dc37b8dc8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (67, 'El Salvador', 'SV', NULL, 67, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e56e35f5-4081-4620-82a4-1f0ffc123b4e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (68, 'Equatorial Guinea', 'GQ', NULL, 68, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '924e6028-60c9-410f-8cc4-262c579286a0');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (69, 'Eritrea', 'ER', NULL, 69, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '292a0217-fda5-408f-ad1c-65d9d2e558ad');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (70, 'Estonia', 'EE', NULL, 70, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f9b6009a-aee8-4798-8082-59a3d08c1583');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (71, 'Ethiopia', 'ET', NULL, 71, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd439acd4-6090-4f1b-b9b3-76a591eb721a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (72, 'Falkland Islands (Malvinas)', 'FK', NULL, 72, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e0544768-a2c3-4725-a05c-d884d779da64');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (73, 'Faroe Islands', 'FO', NULL, 73, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fb5a8448-1ce8-4997-8ebe-a250e8c611af');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (74, 'Fiji', 'FJ', NULL, 74, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a8734860-0842-4b57-9c87-3a31a795a790');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (75, 'Finland', 'FI', NULL, 75, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a29e29d3-e5c2-43d7-842b-6898ddba4cc8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (76, 'France', 'FR', NULL, 76, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'da10c5db-3e11-4163-bcbb-b632f498790f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (77, 'French Guiana', 'GF', NULL, 77, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'eb20b21f-c23c-4b16-ab84-e0a182a13785');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (78, 'French Polynesia', 'PF', NULL, 78, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8c9e1327-2f0b-435f-b3f9-ffb0f275aa81');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (79, 'French Southern Territories', 'TF', NULL, 79, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '785f2010-809f-499c-becb-e606d538a04e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (80, 'Gabon', 'GA', NULL, 80, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'ac1cabf8-e6d6-4afe-89c4-3a8d80f58e93');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (81, 'Gambia', 'GM', NULL, 81, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4afe2dfa-97e0-4bda-a426-9d1ea5b15258');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (82, 'Georgia', 'GE', NULL, 82, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a4c33892-9623-4477-b993-3a54760bcebc');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (83, 'Germany', 'DE', NULL, 83, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd91265d8-f3bd-4599-8f8a-88bd75166142');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (84, 'Ghana', 'GH', NULL, 84, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f1007745-e635-40cf-aebf-e9e0d0168da6');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (85, 'Gibraltar', 'GI', NULL, 85, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b9802a91-d84f-4f1d-959a-92080a6433b3');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (86, 'Greece', 'GR', NULL, 86, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f64cab28-c5db-4625-82cc-5af3987f7e9c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (87, 'Greenland', 'GL', NULL, 87, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '6321e811-eb93-4f3b-b454-3bb843888610');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (88, 'Grenada', 'GD', NULL, 88, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '82cd34fe-4585-4b4a-8756-7ac53aa788be');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (89, 'Guadeloupe', 'GP', NULL, 89, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8463dac2-5660-4e26-b7a0-0a8611ae2f64');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (90, 'Guam', 'GU', NULL, 90, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1abfdcda-94a4-4471-9978-f794e1d25a50');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (91, 'Guatemala', 'GT', NULL, 91, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'beb52ab2-d36a-4f07-bdac-03039f15ca3a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (92, 'Guernsey', 'GG', NULL, 92, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '9d2a35e3-e7d9-4adc-a0a3-f706c9b6f1a6');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (93, 'Guinea', 'GN', NULL, 93, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '27e5f871-d7f0-49b7-86b6-9ac62a9bc962');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (94, 'Guinea-Bissau', 'GW', NULL, 94, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2392d11c-94c0-4261-83c6-2d41dde42cda');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (95, 'Guyana', 'GY', NULL, 95, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '675b15ba-cfa2-4478-8bc2-9884fd6a3d65');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (96, 'Haiti', 'HT', NULL, 96, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3d041a8c-a344-4ade-905e-2a7da48c4bd0');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (97, 'Heard and McDonald Islands', 'HM', NULL, 97, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd6cbab37-17b0-4b99-9336-68af7f9a27be');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (98, 'Honduras', 'HN', NULL, 98, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2d1b2ae3-5902-494f-8227-d3c75878cb85');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (99, 'Hong Kong', 'HK', NULL, 99, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a5c09c37-9dd3-4ffe-af3d-28329161d916');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (100, 'Hungary', 'HU', NULL, 100, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fe19d60b-ba95-4cfb-bd87-15e405dfb987');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (101, 'Iceland', 'IS', NULL, 101, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '627731a6-545f-460d-a4fa-60d361093356');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (102, 'India', 'IN', NULL, 102, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd7ad7f53-16f5-4066-8f96-d267e57317c0');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (103, 'Indonesia', 'ID', NULL, 103, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '61e27fc6-7c1b-4896-b8d6-0232c13ccb66');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (104, 'Iran', 'IR', NULL, 104, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fecc9492-c3fd-49dc-b7ed-5e67115ce95a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (105, 'Iraq', 'IQ', NULL, 105, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4054d1ef-2927-4b2a-8f3b-2d7ff7e3a315');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (106, 'Ireland', 'IE', NULL, 106, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '41de092a-0a0b-4f4e-a9a2-df4268e6bef5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (107, 'Isle Of Man', 'IM', NULL, 107, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '308c950b-4804-4dca-998a-a20d3fe5f171');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (108, 'Israel', 'IL', NULL, 108, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a55b3a83-ad22-4f19-a9b3-3f60ba31a330');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (109, 'Italy', 'IT', NULL, 109, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '96af46eb-e89c-4d9f-abc1-e305d3cc6460');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (110, 'Ivory Coast', 'CI', NULL, 110, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'bd18fe75-4915-4683-8ef6-2b6c49c9eadc');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (111, 'Jamaica', 'JM', NULL, 111, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f682b688-d193-40c3-9f0e-84cdf1d2510d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (112, 'Japan', 'JP', NULL, 112, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'ef93bcff-de88-43ed-a8a1-0b1c62dd2cb4');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (113, 'Jersey', 'JE', NULL, 113, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b4a81cfc-775e-498d-9bbc-f5dbd70e3d03');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (114, 'Jordan', 'JO', NULL, 114, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '55acdeeb-713d-48cb-aaa4-2e793f5a8f29');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (115, 'Kazakhstan', 'KZ', NULL, 115, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a4ec0509-13f8-4502-b496-830a8b8ad844');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (116, 'Kenya', 'KE', NULL, 116, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '897063e5-d2bc-4a5e-b240-58da1f5db94c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (117, 'Kiribati', 'KI', NULL, 117, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2361ce11-8654-4b18-bfec-c023c657a515');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (118, 'Korea (North)', 'KP', NULL, 118, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'bb933143-96d6-4a56-861b-4e15200c7e3a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (119, 'Korea (South)', 'KR', NULL, 119, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '554cedfa-1c68-4076-8f5a-daaf260feddc');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (120, 'Kuwait', 'KW', NULL, 120, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '46c89519-10ed-47dd-bd64-a27e33fbb8f0');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (121, 'Kyrgyzstan', 'KG', NULL, 121, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f89c94ff-72f6-4726-b95c-7b4f0ebc17d9');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (122, 'Laos', 'LA', NULL, 122, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '784040cd-4dca-48b7-bf7d-8b8c8acc1e9a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (123, 'Latvia', 'LV', NULL, 123, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'eeddc268-a7c8-4aaa-ba6c-6167408ec265');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (124, 'Lebanon', 'LB', NULL, 124, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a391c634-d8bf-4102-85e2-cf32c16742c8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (125, 'Lesotho', 'LS', NULL, 125, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '76d5da2d-e1d3-4b62-8f72-8a69065bcf03');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (126, 'Liberia', 'LR', NULL, 126, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'cf6c2818-e6d5-4679-bc94-d9513d5a9905');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (127, 'Libya', 'LY', NULL, 127, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '51d49134-d99f-45b6-b1ce-aa6163b3d866');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (128, 'Liechtenstein', 'LI', NULL, 128, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '248aed13-cbd3-4f8a-8ebf-8a544f943017');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (129, 'Lithuania', 'LT', NULL, 129, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '6c580937-bb9d-4d31-866d-242756098817');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (130, 'Luxembourg', 'LU', NULL, 130, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '7d0eb109-2aa3-4745-8a77-d32df45edf3e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (131, 'Macau', 'MO', NULL, 131, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2deaadc5-523a-41d4-bdf9-d3618fc05b8e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (132, 'Macedonia', 'MK', NULL, 132, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c32a2fd2-7825-4eea-a1fe-d17d39703f88');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (133, 'Madagascar', 'MG', NULL, 133, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '75175ae4-8446-4ae5-9642-d0d76e9bef1f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (134, 'Malawi', 'MW', NULL, 134, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e7039fa2-ac64-4d8b-a9e8-2df96da054d9');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (135, 'Malaysia', 'MY', NULL, 135, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0168abbc-d6b0-4b15-b7e2-30c5c636ab34');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (136, 'Maldives', 'MV', NULL, 136, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3f094d7b-27b9-4848-b269-fc0883bcfbe5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (137, 'Mali', 'ML', NULL, 137, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '043cf3ad-189d-464a-a1e8-34f77afcfe74');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (138, 'Malta', 'MT', NULL, 138, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b326da40-48c9-4215-8b32-b469faadd750');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (139, 'Marshall Islands', 'MH', NULL, 139, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '433f403c-44d9-4679-999a-bce6299b2b95');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (140, 'Martinique', 'MQ', NULL, 140, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5e29d0ca-b487-4fb6-9855-9dfec8a34010');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (141, 'Mauritania', 'MR', NULL, 141, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f82485c0-5066-49d4-a8fc-5be3a5055f45');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (142, 'Mauritius', 'MU', NULL, 142, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2832a46f-2c51-4eb9-a7d2-c44f60c11046');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (143, 'Mayotte', 'YT', NULL, 143, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '187fc254-2619-41f4-a9e1-01c315c6efb5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (144, 'Mexico', 'MX', NULL, 144, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '75a0bb44-94a8-486e-b75d-ac66c2359c8e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (145, 'Micronesia', 'FM', NULL, 145, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0c0972c3-d0a8-430c-8fd2-7a1bd10c12df');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (146, 'Moldova', 'MD', NULL, 146, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e5529e08-dc77-4fa9-a8a1-45860056a01a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (147, 'Monaco', 'MC', NULL, 147, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '90d0a2f3-a87e-4894-a200-8cc9de406589');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (148, 'Mongolia', 'MN', NULL, 148, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd74e8993-a3bc-442e-9a53-45ae72d2e77f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (149, 'Montenegro', 'ME', NULL, 149, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c289c7c9-4712-4edb-85b5-ec347de9d4b5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (150, 'Montserrat', 'MS', NULL, 150, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '414872d8-1098-4344-9393-2d322be0e484');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (151, 'Morocco', 'MA', NULL, 151, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'caba8a45-59c4-4ee2-a3c4-ca38bf22135e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (152, 'Mozambique', 'MZ', NULL, 152, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'def97d74-9564-4513-903e-afaaf1fdd126');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (153, 'Namibia', 'NA', NULL, 153, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'bd7cfb83-0a6d-446b-9e8a-e022bdd8c707');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (154, 'Nauru', 'NR', NULL, 154, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '50ee522e-8786-47dd-b8f7-a373a0328dcd');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (155, 'Nepal', 'NP', NULL, 155, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1cb9a4e7-b661-4287-a0e5-eaeb7191c355');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (156, 'Netherlands', 'NL', NULL, 156, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a10c4e86-3198-4dc9-a194-176b5bbdf106');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (157, 'New Caledonia', 'NC', NULL, 157, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8398789f-8e91-4e4c-8852-87a8fd50d42c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (158, 'New Zealand', 'NZ', NULL, 158, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '99f915f0-07fd-45ec-93a2-ef80e9affd2c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (159, 'Nicaragua', 'NI', NULL, 159, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3ceeafc7-1ea0-4345-b058-85de08490048');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (160, 'Niger', 'NE', NULL, 160, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '7d3573db-bbee-4304-ae9c-abb8576f0075');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (161, 'Nigeria', 'NG', NULL, 161, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '59152e08-edd5-4eb0-97d3-a06e2cfe55a6');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (162, 'Niue', 'NU', NULL, 162, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd4e547cc-e755-406f-8c91-3d9443c08545');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (163, 'Norfolk Island', 'NF', NULL, 163, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '42abad9b-0b73-4327-97d7-86623d2f820e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (164, 'Northern Mariana Islands', 'MP', NULL, 164, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'dadb63f2-d49e-46dd-b82f-cddbf097e1d2');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (165, 'Norway', 'NO', NULL, 165, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b9372796-81a2-45a1-8f44-5edad2b79d9d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (166, 'Oman', 'OM', NULL, 166, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e4e184d0-1c6a-4bf1-8812-90fd86b2f7bb');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (167, 'Pakistan', 'PK', NULL, 167, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'af037fd2-30f0-4e6f-804b-0b495626f8a9');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (168, 'Palau', 'PW', NULL, 168, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4a9b23cc-9051-47af-8b46-fa1a2bd328f3');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (169, 'Palestinian Territory, Occupied', 'PS', NULL, 169, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0ce1eed2-f36e-458a-8d47-9d0d1d6564ad');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (170, 'Panama', 'PA', NULL, 170, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '88ca4b81-aa5d-4b9c-b219-5b8aa599150c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (171, 'Papua New Guinea', 'PG', NULL, 171, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c06b6ba6-d0e5-4e10-8f43-5514af996b8d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (172, 'Paraguay', 'PY', NULL, 172, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b0aefedf-ebdd-46da-a0da-bc9627c4e877');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (173, 'Peru', 'PE', NULL, 173, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '6ac80d5b-0a1c-416e-8c98-57acdd405d83');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (174, 'Philippines', 'PH', NULL, 174, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '9c33ac77-7d1d-4f0f-8905-4dcfddc7d4f8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (175, 'Pitcairn', 'PN', NULL, 175, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c944c6d1-3b09-43cb-bbe6-ee863009bad9');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (176, 'Poland', 'PL', NULL, 176, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '11939e2b-2610-4dd3-852f-9e1c4c3c487e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (177, 'Portugal', 'PT', NULL, 177, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e778fcb5-26ca-42cd-9a56-3cf0e8f6f8ba');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (178, 'Puerto Rico', 'PR', NULL, 178, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '16817bdf-d292-4b89-abf1-7fa9208dedc0');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (179, 'Qatar', 'QA', NULL, 179, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'dd09162b-58a8-4ed3-a1a8-bcc4c8d69c40');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (180, 'Republic of Serbia', 'RS', NULL, 180, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0b82e895-3dff-4bb4-aabe-33d4e05f4624');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (181, 'Reunion', 'RE', NULL, 181, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e4afc482-66df-4eef-ab4d-43824a1f7224');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (182, 'Romania', 'RO', NULL, 182, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5b697842-1a24-4e8b-a5cb-38f0b3ecfa10');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (183, 'Russia', 'RU', NULL, 183, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'ab166a11-f201-4d96-9567-4b1c2d3618bd');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (184, 'Rwanda', 'RW', NULL, 184, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e2889e57-df17-4d82-969e-8033817d7ce2');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (185, 'S. Georgia and S. Sandwich Isls.', 'GS', NULL, 185, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'baa6f4ce-f13c-4fdd-abe1-303a01ee44fd');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (186, 'Saint Barthelemy', 'BL', NULL, 186, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5427774b-9f18-4a8a-a61a-4aa99238ac3f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (187, 'Saint Kitts and Nevis', 'KN', NULL, 187, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd4707a38-2a12-4111-a777-387ee741088b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (188, 'Saint Lucia', 'LC', NULL, 188, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0150026f-73f7-4952-94ff-36d28402e404');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (189, 'Saint Martin (French part)', 'MF', NULL, 189, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '761ee800-efe6-4fc1-8f84-47026790b554');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (190, 'Saint Vincent and the Grenadines', 'VC', NULL, 190, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '40cf6212-e0bf-4000-a0d7-aa805265f525');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (191, 'Samoa', 'WS', NULL, 191, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '51f03ac1-5450-4515-9380-097db1b1e54c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (192, 'San Marino', 'SM', NULL, 192, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '521bacfc-2091-4a0d-879f-4dd8cebfac4b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (193, 'Sao Tome and Principe', 'ST', NULL, 193, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c1e97d00-d201-4b02-a957-5f6b24435a77');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (194, 'Saudi Arabia', 'SA', NULL, 194, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0863d77d-117a-4c81-8378-abbdaf21297b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (195, 'Senegal', 'SN', NULL, 195, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd8f3da90-4010-4b99-b072-2b0fc83f6b66');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (196, 'Seychelles', 'SC', NULL, 196, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0d09f136-59a8-45f0-b2b3-43c51be99255');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (197, 'Sierra Leone', 'SL', NULL, 197, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0fa54e63-00c0-4692-88f3-0799439f1ef9');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (198, 'Singapore', 'SG', NULL, 198, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e8c63c2b-ea26-4538-87cd-9ec1efce0151');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (199, 'Sint Maarten (Dutch part)', 'SX', NULL, 199, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'bf724aa8-b010-4c05-acb0-d1bb994089c5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (200, 'Slovak Republic', 'SK', NULL, 200, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1da2efe7-1777-4b02-8497-b3140840d5a7');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (201, 'Slovenia', 'SI', NULL, 201, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd4ef498b-5502-4b56-a26c-f5d3f00382e8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (202, 'Solomon Islands', 'SB', NULL, 202, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b5bcad7e-5111-4ac9-a6f1-bdffbd29990a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (203, 'Somalia', 'SO', NULL, 203, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '89694ceb-54bf-48f6-8418-500c14aac256');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (204, 'South Africa', 'ZA', NULL, 204, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '467ae0df-f3e2-49a8-988c-d8e3fd0924c8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (205, 'South Sudan', 'SS', NULL, 205, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '834747d5-f511-492a-8a3d-660bc79c32ee');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (206, 'Spain', 'ES', NULL, 206, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b0f03a9c-3cce-4d38-a079-15febf19b077');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (207, 'Sri Lanka', 'LK', NULL, 207, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '6e522451-6b79-4d58-8b8d-9f6c5c7ea76e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (208, 'St. Helena', 'SH', NULL, 208, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c4c472fb-6950-43ab-8516-1d8184b65d6f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (209, 'St. Pierre and Miquelon', 'PM', NULL, 209, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b3aa9c82-56e4-44c2-9cc5-70683b3d7e55');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (210, 'Sudan', 'SD', NULL, 210, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '339940ca-f5e9-4306-a5b0-f26947523721');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (211, 'Suriname', 'SR', NULL, 211, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1e50a1eb-d3d3-462c-812e-0c3c2d0c34a8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (212, 'Svalbard and Jan Mayen Islands', 'SJ', NULL, 212, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '27fb263a-22c8-403e-bf2c-a5615c398687');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (213, 'Swaziland', 'SZ', NULL, 213, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '640c7d9a-8e70-4082-a428-231e086e2823');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (214, 'Sweden', 'SE', NULL, 214, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '19dce4e7-1428-4507-9654-a2c6b204f0cc');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (215, 'Switzerland', 'CH', NULL, 215, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'de94dec2-363c-4a56-af28-a0bbe2517fd0');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (216, 'Syria', 'SY', NULL, 216, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '429b29f3-ee83-45db-9d64-1d84d129f567');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (217, 'Taiwan', 'TW', NULL, 217, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0483a5c2-8d23-42bf-bac6-9cc8a1dee914');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (218, 'Tajikistan', 'TJ', NULL, 218, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd5217ac8-54b3-494f-9fc0-bf9019f9a598');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (219, 'Tanzania', 'TZ', NULL, 219, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '02c65a0d-ee7e-4d37-a182-37e180d08a1a');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (220, 'Thailand', 'TH', NULL, 220, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '366e2c23-31f4-409a-8cce-87dc78ac63c7');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (221, 'Timor-Leste', 'TL', NULL, 221, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fcbb4853-dbc0-43bb-96a2-872a310c2b11');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (222, 'Togo', 'TG', NULL, 222, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd9c148db-204d-4312-8f11-d7e481f56f2d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (223, 'Tokelau', 'TK', NULL, 223, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '7a9b8aa2-f08d-492d-a047-56782a61e061');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (224, 'Tonga', 'TO', NULL, 224, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '67fc1888-86f8-4818-8884-a93bafe2fbec');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (225, 'Trinidad and Tobago', 'TT', NULL, 225, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fce588cc-76d1-434b-a916-09aa30bc1cdb');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (226, 'Tunisia', 'TN', NULL, 226, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '21e1d581-60d7-43d7-9bd7-aa634b300db5');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (227, 'Turkey', 'TR', NULL, 227, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'ab1c680d-9155-4f32-b13b-50f75ef88f2e');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (228, 'Turkmenistan', 'TM', NULL, 228, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '9ffb6669-1897-4c7e-bc9f-ebea8866caa1');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (229, 'Turks and Caicos Islands', 'TC', NULL, 229, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '490b8747-d9c4-4230-adec-47a742cd5320');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (230, 'Tuvalu', 'TV', NULL, 230, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1f84c892-0e86-47be-8a85-bc037ab9582f');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (231, 'Uganda', 'UG', NULL, 231, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '7893ea25-dbab-44eb-9b6c-03df1cbb842d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (232, 'Ukraine', 'UA', NULL, 232, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c8487538-2d9b-4221-a333-6ce408f45f7d');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (233, 'United Arab Emirates', 'AE', NULL, 233, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3482a096-ecce-4e9b-9276-dc95a697859c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (234, 'United Kingdom', 'GB', NULL, 234, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '04d8375d-7f36-4ce8-99c0-f217e5500d88');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (235, 'United States Minor Outlying Islands', 'UM', NULL, 235, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f3c0bcbc-5ecb-46f3-8700-30113610595b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (236, 'United States', 'US', NULL, 236, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1bb603cc-5d65-4667-b7ff-fec991ea837c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (237, 'Uruguay', 'UY', NULL, 237, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c4bc7ff5-753d-41fd-906e-a4eb1536f147');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (238, 'Uzbekistan', 'UZ', NULL, 238, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a9f8ae22-7a0d-4711-8f77-742f41da5677');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (239, 'Vanuatu', 'VU', NULL, 239, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0d01977e-4a01-454c-a784-ff1a5ea858f8');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (240, 'Vatican City State (Holy See)', 'VA', NULL, 240, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '831ade19-c42c-45e0-8088-0a330b7e908b');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (241, 'Venezuela', 'VE', NULL, 241, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b668414a-2194-4a76-ae79-cc0f38afcd97');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (242, 'Viet Nam', 'VN', NULL, 242, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '16634bec-68db-40f5-81eb-5a458fdaef42');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (243, 'Virgin Islands (British)', 'VG', NULL, 243, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c9d43867-d5f3-4224-aa79-6acccf63a4ab');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (244, 'Virgin Islands (U.S.)', 'VI', NULL, 244, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd4268e99-f0ab-4d25-a34f-20b3bc5d2657');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (245, 'Wallis and Futuna Islands', 'WF', NULL, 245, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '47d4c04b-b730-4608-a49a-cc4042a4c9c6');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (246, 'Western Sahara', 'EH', NULL, 246, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f8a0f93a-de30-4dc6-aba0-df9a0e21e92c');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (247, 'Yemen', 'YE', NULL, 247, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '6e52e379-b0bc-4de0-9534-522b9e61ac05');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (248, 'Zambia', 'ZM', NULL, 248, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b2f1f4db-ea39-4447-965a-075ee5f9b170');
INSERT INTO public.commerce_countries (id, name, iso, "isStateRequired", "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (249, 'Zimbabwe', 'ZW', NULL, 249, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '490922c6-8c82-4902-a4fd-82696ac8bad8');


--
-- Data for Name: commerce_customer_discountuses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_customers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_customers (id, "userId", "primaryBillingAddressId", "primaryShippingAddressId", "dateCreated", "dateUpdated", uid) VALUES (1, 3, NULL, NULL, '2021-03-30 18:09:53', '2021-03-30 18:09:53', '75003678-2d84-409c-b9aa-277f8280fa49');


--
-- Data for Name: commerce_customers_addresses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_discount_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_discount_purchasables; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_discount_usergroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_discounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_donations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_donations (id, sku, "availableForPurchase", "dateCreated", "dateUpdated", uid) VALUES (1, 'DONATION-CC3', false, '2021-03-30 18:09:49', '2021-03-30 18:09:49', '6fe642cb-4d9a-4cc4-8c41-fa5751cfaeb7');


--
-- Data for Name: commerce_email_discountuses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_emails; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_gateways; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_gateways (id, type, name, handle, settings, "paymentType", "isFrontendEnabled", "sendCartInfo", "isArchived", "dateArchived", "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (1, 'craft\commerce\gateways\Dummy', 'Dummy', 'dummy', NULL, 'purchase', true, NULL, false, NULL, 99, '2021-03-30 18:09:51', '2021-03-30 18:09:51', 'e6c2eb12-4cb1-4a71-8e5f-255e1b211a83');


--
-- Data for Name: commerce_lineitems; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_lineitemstatuses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_orderadjustments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_orderhistories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_orders; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_orderstatus_emails; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_orderstatuses; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_orderstatuses (id, name, handle, color, description, "dateDeleted", "sortOrder", "default", "dateCreated", "dateUpdated", uid) VALUES (1, 'New', 'new', 'green', NULL, NULL, 99, true, '2021-03-30 18:09:51', '2021-03-30 18:09:51', 'e1e9bc49-0f42-4f88-980c-26c6afcd1671');


--
-- Data for Name: commerce_paymentcurrencies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_paymentcurrencies (id, iso, "primary", rate, "dateCreated", "dateUpdated", uid) VALUES (1, 'USD', true, 1.0000, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '06e29263-b3ef-44fe-a98d-5f36291329a2');


--
-- Data for Name: commerce_paymentsources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_pdfs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_plans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_products; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_producttypes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_producttypes (id, "fieldLayoutId", "variantFieldLayoutId", name, handle, "hasDimensions", "hasVariants", "hasVariantTitleField", "titleFormat", "hasProductTitleField", "productTitleFormat", "skuFormat", "descriptionFormat", "dateCreated", "dateUpdated", uid) VALUES (1, NULL, NULL, 'Clothing', 'clothing', true, false, true, '{product.title}', true, '', '', '', '2021-03-30 18:09:51', '2021-03-30 18:09:51', 'f83257f1-bf0b-463f-a366-30cdcc88a10c');


--
-- Data for Name: commerce_producttypes_shippingcategories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_producttypes_sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_producttypes_sites (id, "productTypeId", "siteId", "uriFormat", template, "hasUrls", "dateCreated", "dateUpdated", uid) VALUES (1, 1, 1, 'shop/products/{slug}', 'shop/products/_product', true, '2021-03-30 18:09:51', '2021-03-30 18:09:51', '881d7882-ff65-4dfe-8f02-0778c7f38cf1');


--
-- Data for Name: commerce_producttypes_taxcategories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_purchasables; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_purchasables (id, sku, price, description, "dateCreated", "dateUpdated", uid) VALUES (1, 'DONATION-CC3', 0.0000, 'Donation', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '9cc75f32-fb91-42ce-bf0c-13d05da7b6c3');


--
-- Data for Name: commerce_sale_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_sale_purchasables; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_sale_usergroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_sales; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_shippingcategories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_shippingcategories (id, name, handle, description, "default", "dateCreated", "dateUpdated", uid) VALUES (1, 'General', 'general', NULL, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '16c132c0-2a3e-4ee9-87c8-a361f1d8298f');


--
-- Data for Name: commerce_shippingmethods; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_shippingmethods (id, name, handle, enabled, "isLite", "dateCreated", "dateUpdated", uid) VALUES (1, 'Free Shipping', 'freeShipping', true, NULL, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4c23797b-677c-4867-a914-417c3620e2c6');


--
-- Data for Name: commerce_shippingrule_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_shippingrules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_shippingrules (id, "shippingZoneId", "methodId", name, description, priority, enabled, "minQty", "maxQty", "minTotal", "maxTotal", "minWeight", "maxWeight", "baseRate", "perItemRate", "weightRate", "percentageRate", "minRate", "maxRate", "isLite", "dateCreated", "dateUpdated", uid) VALUES (1, NULL, 1, 'Free Everywhere', 'All Countries, free shipping.', 0, true, 0, 0, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, NULL, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '9fb152ef-727d-492b-935d-d73cdd4a40f4');


--
-- Data for Name: commerce_shippingzone_countries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_shippingzone_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_shippingzones; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_states; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (1, 14, 'Australian Capital Territory', 'ACT', 1, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '7add5fd2-b4a6-4e13-a30e-0e6979d2abf6');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (2, 14, 'New South Wales', 'NSW', 2, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '6496ca6d-3652-46c9-8d44-d0303cb0d33b');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (3, 14, 'Northern Territory', 'NT', 3, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0780255b-b46a-4dc4-b21c-4315c8f95e9a');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (4, 14, 'Queensland', 'QLD', 4, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'ec69163b-3722-4692-9d52-87d32c95ef3a');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (5, 14, 'South Australia', 'SA', 5, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8ac27915-68ea-4cef-865b-27ea2bcd1ce3');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (6, 14, 'Tasmania', 'TAS', 6, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'dc3025c6-10f3-4f57-b8c8-c8e73b876db5');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (7, 14, 'Victoria', 'VIC', 7, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '9cb10f29-01fd-4fdf-a6b1-1f468ad63310');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (8, 14, 'Western Australia', 'WA', 8, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '62e44cec-cfb4-4376-b14d-080691d4859c');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (9, 41, 'Alberta', 'AB', 1, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4f2cbbe6-7a20-4b03-a799-3131ffeb288c');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (10, 41, 'British Columbia', 'BC', 2, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4cfcb5d3-2835-421c-9877-87c3985da181');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (11, 41, 'Manitoba', 'MB', 3, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b6ba7fa7-69ab-4700-a3da-7cd3f29d2c32');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (12, 41, 'New Brunswick', 'NB', 4, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e007e2f1-47f4-4696-b4b0-d3623819abfd');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (13, 41, 'Newfoundland and Labrador', 'NL', 5, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '354f8681-731f-4cea-a46e-189caa6d2810');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (14, 41, 'Northwest Territories', 'NT', 6, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '45de3732-8530-4ad8-af2a-958c8fa93dee');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (15, 41, 'Nova Scotia', 'NS', 7, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '47b3f6f3-210b-4fde-b93d-1c26e6eb9260');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (16, 41, 'Nunavut', 'NU', 8, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '497e0bab-7433-4d1e-99ec-5fd9fbc5342e');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (17, 41, 'Ontario', 'ON', 9, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '443f237c-76fa-4155-96d7-65423dd53d57');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (18, 41, 'Prince Edward Island', 'PE', 10, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2ec3685b-027a-4397-9fdc-1cd55d57afba');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (19, 41, 'Quebec', 'QC', 11, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e60eda78-7332-455b-9bff-006bddaa242b');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (20, 41, 'Saskatchewan', 'SK', 12, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '65629d21-b874-48fa-91ff-5ad161e55d0a');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (21, 41, 'Yukon', 'YT', 13, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'be98e506-68e4-48fe-aea7-4b9edb779094');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (22, 236, 'Alabama', 'AL', 1, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '36d7abe2-7731-4586-ad5b-d477bf023ccd');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (23, 236, 'Alaska', 'AK', 2, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5e0fd919-8974-4bab-8045-a7d0de510253');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (24, 236, 'Arizona', 'AZ', 3, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd2d0ae70-bf8b-41cd-afba-9e7177719edc');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (25, 236, 'Arkansas', 'AR', 4, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'ac10fc6d-b078-400e-963f-9a361da23411');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (26, 236, 'California', 'CA', 5, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3eb5170f-5757-40ba-a320-3b8b5c5cddbb');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (27, 236, 'Colorado', 'CO', 6, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '459a467a-5bea-4e8d-9bc2-5d94197af107');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (28, 236, 'Connecticut', 'CT', 7, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '6922cecb-1fe1-41cb-961e-f6316352bb8a');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (29, 236, 'Delaware', 'DE', 8, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e2c08da0-8629-428f-8f56-15e25da8528f');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (30, 236, 'District of Columbia', 'DC', 9, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '74a83d63-22ee-4756-b6f1-e642e8cc010f');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (31, 236, 'Florida', 'FL', 10, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2ca31f90-bff7-4278-b275-2558ede1d900');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (32, 236, 'Georgia', 'GA', 11, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'deef0a3a-9783-4e8e-8524-0424e8c37d02');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (33, 236, 'Hawaii', 'HI', 12, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fe264f52-3b15-4fbb-af16-404a7debda66');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (34, 236, 'Idaho', 'ID', 13, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f3e9044e-15dd-4443-8c0b-554b7e70f4fd');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (35, 236, 'Illinois', 'IL', 14, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1ac3ff0e-dbc3-472a-993b-c2af1d0352bc');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (36, 236, 'Indiana', 'IN', 15, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0df8974e-86df-44eb-8ff5-0085e481d38e');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (37, 236, 'Iowa', 'IA', 16, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '89d6ed3b-17cb-405b-a81c-75f7b7570863');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (38, 236, 'Kansas', 'KS', 17, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '71fa7a15-0373-4ccb-a6c3-41229808654b');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (39, 236, 'Kentucky', 'KY', 18, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '101d1def-4881-425d-b72d-77ee93747a69');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (40, 236, 'Louisiana', 'LA', 19, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8f86f4dd-0d70-4590-bee3-3d6c2f00ecbc');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (41, 236, 'Maine', 'ME', 20, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'cfab6339-9ed9-4941-9733-db927fbbebb7');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (42, 236, 'Maryland', 'MD', 21, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '1d397671-ede2-4e4f-993f-b56ec12cd958');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (43, 236, 'Massachusetts', 'MA', 22, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'd9fbf597-bb07-42ef-8a98-a0d790a80bc0');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (44, 236, 'Michigan', 'MI', 23, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'f8e9deb7-01d2-43f8-80e1-568b933289be');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (45, 236, 'Minnesota', 'MN', 24, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '9c29c1b5-39e8-4cc1-aa2c-def4d00c159c');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (46, 236, 'Mississippi', 'MS', 25, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '03cfde6e-27a4-49de-9912-71a73a36eb3a');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (47, 236, 'Missouri', 'MO', 26, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2a57ad96-6878-4d89-98b9-28bab5161328');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (48, 236, 'Montana', 'MT', 27, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c772b5d3-1b20-4b3d-b20c-f979a8f7c49c');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (49, 236, 'Nebraska', 'NE', 28, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2e4bffd3-a122-454c-9735-e75dbf6f8bf3');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (50, 236, 'Nevada', 'NV', 29, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a7da7284-f4c3-486b-bcb5-9d0ff549617d');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (51, 236, 'New Hampshire', 'NH', 30, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5479ef7b-0f10-47d1-903c-caad91786b81');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (52, 236, 'New Jersey', 'NJ', 31, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'c328197d-c517-43ec-abc8-c71340b6463b');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (53, 236, 'New Mexico', 'NM', 32, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2445e524-e32d-4a66-8d70-16deb95475ee');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (54, 236, 'New York', 'NY', 33, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8d9ea603-0645-49b3-8182-70dc1f69b2ff');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (55, 236, 'North Carolina', 'NC', 34, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '37c3046e-3775-4648-9027-f8749cbd9d94');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (56, 236, 'North Dakota', 'ND', 35, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8f779363-57f5-4786-b4ed-1e3c7d201b2c');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (57, 236, 'Ohio', 'OH', 36, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '5e4510fe-e05a-4dc8-8e48-e55c53dcf126');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (58, 236, 'Oklahoma', 'OK', 37, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'aa19433c-20ce-4ab0-a398-7e9e344213f9');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (59, 236, 'Oregon', 'OR', 38, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'a503d139-ee13-4810-b8ae-bd374e6dac3e');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (60, 236, 'Pennsylvania', 'PA', 39, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3ba8b594-8a1f-4695-a807-e67d6fb1845d');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (61, 236, 'Rhode Island', 'RI', 40, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '15848825-3c2c-449e-b927-5300d3713f11');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (62, 236, 'South Carolina', 'SC', 41, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '3b94836b-6955-4ffd-bd80-42ceef8daf2b');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (63, 236, 'South Dakota', 'SD', 42, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '2a108acd-a8c9-42c9-904a-82121bc26534');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (64, 236, 'Tennessee', 'TN', 43, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '17e15896-f4c1-4629-a219-b01b3144055d');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (65, 236, 'Texas', 'TX', 44, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '77eea81b-7dcb-4896-98f9-825938752d1c');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (66, 236, 'Utah', 'UT', 45, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '04770354-7ebd-4ad7-997a-711a96cd6f3f');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (67, 236, 'Vermont', 'VT', 46, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'e932c5e3-8a13-49f4-ad30-b79285c8f02e');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (68, 236, 'Virginia', 'VA', 47, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '8b9cb0fd-c20c-4e81-8c8a-b76e37883df1');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (69, 236, 'Washington', 'WA', 48, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '15f4b494-10b6-4f51-b696-7462c1b06aad');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (70, 236, 'West Virginia', 'WV', 49, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'fe6ee535-54b4-4822-a41f-4f41645452dc');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (71, 236, 'Wisconsin', 'WI', 50, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', 'b9b40aae-6b95-4701-87e5-42ac896407b5');
INSERT INTO public.commerce_states (id, "countryId", name, abbreviation, "sortOrder", enabled, "dateCreated", "dateUpdated", uid) VALUES (72, 236, 'Wyoming', 'WY', 51, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '4f27c0b0-c0b3-490c-bd6d-315109106bac');


--
-- Data for Name: commerce_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_taxcategories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.commerce_taxcategories (id, name, handle, description, "default", "dateCreated", "dateUpdated", uid) VALUES (1, 'General', 'general', NULL, true, '2021-03-30 18:09:48', '2021-03-30 18:09:48', '0adb517a-240e-4642-a507-9a243b89046d');


--
-- Data for Name: commerce_taxrates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_taxzone_countries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_taxzone_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_taxzones; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_transactions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commerce_variants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: content; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_errorHeadline", "field_errorText") VALUES (1, 2, 1, 'Homepage', '2021-03-30 18:09:52', '2021-03-30 18:09:52', '2db16b11-82af-4c84-a8df-1e7833673816', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_errorHeadline", "field_errorText") VALUES (2, 3, 1, NULL, '2021-03-30 18:09:53', '2021-03-30 18:23:27', '4cf9a518-2d1c-4e5e-9630-8852125751de', NULL, NULL);


--
-- Data for Name: craftidtokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deprecationerrors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: drafts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: elementindexsettings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: elements; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.elements (id, "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, NULL, NULL, NULL, 'craft\commerce\elements\Donation', true, false, '2021-03-30 18:09:49', '2021-03-30 18:09:49', NULL, 'bc32c7c1-c89c-498d-a5ae-6025a10d8ae6');
INSERT INTO public.elements (id, "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, NULL, NULL, 3, 'craft\elements\Entry', true, false, '2021-03-30 18:09:52', '2021-03-30 18:09:52', NULL, '4b0d51b5-1c46-4aef-ac5a-e57bd915818f');
INSERT INTO public.elements (id, "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (3, NULL, NULL, NULL, 'craft\elements\User', true, false, '2021-03-30 18:09:53', '2021-03-30 18:23:27', NULL, '1d2ec1a6-9bdf-4e2a-bd69-0fd2bb4cf22d');


--
-- Data for Name: elements_sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (1, 1, 1, NULL, NULL, true, '2021-03-30 18:09:49', '2021-03-30 18:09:49', '223b4b57-e2cf-4977-b06c-3f583e9cadff');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (2, 2, 1, 'homepage', '__home__', true, '2021-03-30 18:09:52', '2021-03-30 18:09:52', 'fee78878-b246-4f6f-970c-b90955c3f2b2');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (3, 3, 1, NULL, NULL, true, '2021-03-30 18:09:53', '2021-03-30 18:09:53', '988c5cd9-72f5-4702-a274-02bc3a03bdfe');


--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (2, 2, NULL, 2, NULL, '2021-03-30 18:09:00', NULL, NULL, '2021-03-30 18:09:52', '2021-03-30 18:09:52', '2fc8e3e8-f026-4181-b61b-d5e7d571efc1');


--
-- Data for Name: entrytypes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, 2, 3, 'Homepage', 'homepage', false, '', NULL, '{section.name|raw}', 1, '2021-03-30 18:09:51', '2021-03-30 18:09:51', NULL, 'fb3a8f31-d1cc-4c13-903b-a501f7e51f54');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, 2, 'Errors', 'errors', true, '', NULL, NULL, 1, '2021-03-30 18:09:51', '2021-03-30 18:09:51', '2021-03-30 18:23:11', 'faceb3ed-6771-453c-9c2a-aa330847f6db');


--
-- Data for Name: fieldgroups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fieldgroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 'Common', '2021-03-30 18:09:50', '2021-03-30 18:09:50', NULL, '94b4d5ac-d7ea-4241-a6cb-92b39f482f99');
INSERT INTO public.fieldgroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, 'Errors', '2021-03-30 18:09:50', '2021-03-30 18:09:50', NULL, 'd08a0d16-0e00-49e6-9cd4-465fa2d65d7d');


--
-- Data for Name: fieldlayoutfields; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fieldlayouts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 'craft\elements\Asset', '2021-03-30 18:09:50', '2021-03-30 18:09:50', NULL, 'f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (3, 'craft\elements\Entry', '2021-03-30 18:09:51', '2021-03-30 18:09:51', NULL, 'd1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, 'craft\elements\Entry', '2021-03-30 18:09:51', '2021-03-30 18:09:51', '2021-03-30 18:23:11', '71344442-aa7e-4313-be36-12cd89956984');


--
-- Data for Name: fieldlayouttabs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (2, 2, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-03-30 18:09:51', '2021-03-30 18:09:51', 'd365ac62-9971-4e3c-b1b4-41c401f7853b');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (3, 3, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-03-30 18:09:51', '2021-03-30 18:09:51', 'f4d9c4d4-e20c-4837-a2ba-47c49d1231cb');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (4, 1, 'Content', '[{"type":"craft\\fieldlayoutelements\\AssetTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-03-30 18:09:52', '2021-03-30 18:09:52', 'f24df044-deeb-4e2e-a54e-bfd9d3016350');


--
-- Data for Name: fields; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fields (id, "groupId", name, handle, context, instructions, searchable, "translationMethod", "translationKeyFormat", type, settings, "dateCreated", "dateUpdated", uid) VALUES (1, 2, 'Error Headline', 'errorHeadline', 'global', '', true, 'none', NULL, 'craft\fields\PlainText', '{"byteLimit":null,"charLimit":null,"code":"","columnType":"text","initialRows":"4","multiline":"","placeholder":"","uiMode":"normal"}', '2021-03-30 18:09:50', '2021-03-30 18:09:50', 'b8ba7115-3804-4c06-8a96-501963d1fc5c');
INSERT INTO public.fields (id, "groupId", name, handle, context, instructions, searchable, "translationMethod", "translationKeyFormat", type, settings, "dateCreated", "dateUpdated", uid) VALUES (2, 2, 'Error Image', 'errorImage', 'global', '', true, 'site', NULL, 'craft\fields\Assets', '{"allowSelfRelations":false,"allowUploads":true,"allowedKinds":["image"],"defaultUploadLocationSource":"volume:5c642d7e-b16b-4836-9575-668d75d242e5","defaultUploadLocationSubpath":"","limit":"1","localizeRelations":false,"previewMode":"full","restrictFiles":"1","selectionLabel":"","showSiteMenu":true,"showUnpermittedFiles":false,"showUnpermittedVolumes":true,"singleUploadLocationSource":"volume:5c642d7e-b16b-4836-9575-668d75d242e5","singleUploadLocationSubpath":"","source":null,"sources":["volume:5c642d7e-b16b-4836-9575-668d75d242e5"],"targetSiteId":null,"useSingleFolder":false,"validateRelatedElements":false,"viewMode":"large"}', '2021-03-30 18:09:50', '2021-03-30 18:09:50', 'a5cb77be-c4d9-4d3e-88fb-d5384ca13941');
INSERT INTO public.fields (id, "groupId", name, handle, context, instructions, searchable, "translationMethod", "translationKeyFormat", type, settings, "dateCreated", "dateUpdated", uid) VALUES (3, 2, 'Error Text', 'errorText', 'global', '', true, 'none', NULL, 'craft\fields\PlainText', '{"byteLimit":null,"charLimit":null,"code":"","columnType":"text","initialRows":"4","multiline":"1","placeholder":"","uiMode":"normal"}', '2021-03-30 18:09:50', '2021-03-30 18:09:50', 'e6d658aa-c335-4f15-bbcd-59fe05d9e913');


--
-- Data for Name: globalsets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: gqlschemas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.gqlschemas (id, name, scope, "isPublic", "dateCreated", "dateUpdated", uid) VALUES (1, 'Public Schema', '[]', true, '2021-03-30 18:09:51', '2021-03-30 18:09:51', '6005c2f9-5d85-4442-b712-22e070096ac8');


--
-- Data for Name: gqltokens; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.gqltokens (id, name, "accessToken", enabled, "expiryDate", "lastUsed", "schemaId", "dateCreated", "dateUpdated", uid) VALUES (1, 'Public Token', '__PUBLIC__', false, NULL, NULL, 1, '2021-03-30 18:09:52', '2021-03-30 18:09:52', '568de1a9-dabe-4c27-bf3c-114570a328dd');


--
-- Data for Name: info; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.info (id, version, "schemaVersion", maintenance, "configVersion", "fieldVersion", "dateCreated", "dateUpdated", uid) VALUES (1, '3.6.11.2', '3.6.7', false, 'ddpkgjgjofac', 'csscxweidxmd', '2021-03-30 18:09:46', '2021-03-30 18:58:01', '4d3ddb78-70e6-49c9-8e3f-8535f379ea34');


--
-- Data for Name: matrixblocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: matrixblocktypes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (1, 'plugin:commerce', 'Install', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b69fd406-ec83-44aa-bb9e-ac97919f6caa');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (2, 'plugin:commerce', 'm160531_154500_craft3_upgrade', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'dafb9898-0416-4a5b-b8f7-462d8dff26b4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (3, 'plugin:commerce', 'm170616_154500_productTypeSites_upgrade', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'e72b8f32-27e2-4f3b-b92d-666ebf2a12bc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (4, 'plugin:commerce', 'm170705_154500_i18n_to_sites', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '0877eb9b-8eb6-4ee9-a0c4-4ab562093b44');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (5, 'plugin:commerce', 'm170705_155000_order_shippingmethod_to_shippingmethodhandle', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '8ff9bd2a-4c95-4cf0-9513-a0fabe010a5d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (6, 'plugin:commerce', 'm170718_150000_paymentmethod_class_to_type', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '4a09d598-316a-428c-b7b7-c2c8bd24b83b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (7, 'plugin:commerce', 'm170725_130000_paymentmethods_are_now_gateways', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'd101c5a6-5b9a-4bb6-a9c0-055d681396fa');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (8, 'plugin:commerce', 'm170810_130000_sendCartInfo_per_gateway', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1367a935-f003-4516-bb5b-5e50d2376420');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (9, 'plugin:commerce', 'm170828_130000_transaction_gatewayProcessing_flag', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '93937ca7-56f3-4916-a3f1-33f7e2f25ae8');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (10, 'plugin:commerce', 'm170830_130000_order_refactor', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'da0391bc-13ee-46ab-84dd-3bbc39474b8c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (11, 'plugin:commerce', 'm170831_130000_paymentCurreny_primary_not_null', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1ba0279b-4cce-4da8-a899-85f041312fbd');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (12, 'plugin:commerce', 'm170904_130000_processing_transactions', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '0566d73b-b66e-4cd0-946c-4c732e2be2c4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (13, 'plugin:commerce', 'm171010_170000_stock_location', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'c42f2eff-11ad-451c-8174-b7acae1245e7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (14, 'plugin:commerce', 'm171202_180000_promotions_for_all_purchasables', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'c430aae6-6518-4357-8554-3bf762812764');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (15, 'plugin:commerce', 'm171204_213000_payment_sources', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'ec621606-979c-440e-babf-907b98a58bfa');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (16, 'plugin:commerce', 'm171207_160000_order_can_store_payment_sources', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '85c0a2fc-56be-4eef-a75b-623be8f46a4f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (17, 'plugin:commerce', 'm171221_120000_subscriptions', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'e7190d31-3746-4e81-89a2-1867393ece1b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (18, 'plugin:commerce', 'm171221_120500_missing_indexes', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b220d1bb-08c0-4772-986c-362580c8f9a2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (19, 'plugin:commerce', 'm180205_150646_create_state_abbreviation_index', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b1e6d610-c78e-4a3c-955d-c181dd470810');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (20, 'plugin:commerce', 'm180209_115000_plan_description', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '28145f09-483c-4842-af6c-0a9548d829ae');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (21, 'plugin:commerce', 'm180216_130000_rename_store_location', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '5085f0c6-aabb-48b4-a55b-80c9beb3bcef');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (22, 'plugin:commerce', 'm180217_130000_sale_migration', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '988b5bb4-a036-4a86-b3e5-ff23f358beb9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (23, 'plugin:commerce', 'm180218_130000_sale_order', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '8d21548f-54a7-43fd-9500-c71c820e86b0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (24, 'plugin:commerce', 'm180219_130000_sale_can_stop_processing', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'f3f1e312-515b-4a51-9f90-ded0488a12ac');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (25, 'plugin:commerce', 'm180220_130000_sale_can_ignore_previous', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '803005f7-b673-410f-bf8d-07a0be7f318e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (26, 'plugin:commerce', 'm180221_130000_sale_fixSort', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '3380e4ab-f5e5-44ae-bb98-176ff8ac03ca');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (27, 'plugin:commerce', 'm180222_130000_lineitemsubtotal', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'ceff5595-a69f-4221-936e-033b14fc6d4b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (28, 'plugin:commerce', 'm180306_130000_renamed', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'cfb1570e-3eaf-443b-a17d-28b3ae7f4556');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (29, 'plugin:commerce', 'm180307_130000_order_paid_status', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '02efce6d-16e8-4e1b-a4f0-6e35fe7c9d79');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (30, 'plugin:commerce', 'm180308_130000_update_order_paid_status', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '08370a1a-09ec-4845-850f-efcf171078ad');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (31, 'plugin:commerce', 'm180308_130001_has_and_is', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '558e75e4-5039-4dc7-ad2f-ac865aa1f73e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (32, 'plugin:commerce', 'm180312_130001_countryBased', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b905353c-c379-4e54-9dde-9672dfe8d63d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (33, 'plugin:commerce', 'm180319_130001_fieldSettings', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '63ab3687-77a5-44b6-9287-a6b395af66fe');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (34, 'plugin:commerce', 'm180326_130001_cascadeDeleteVariants', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '3435be8d-aeca-4696-9f38-80c3ccda14ee');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (35, 'plugin:commerce', 'm180329_161901_gateway_send_cart_info', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'f9f182ff-7a15-4910-8b37-92d89ddf2a1c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (36, 'plugin:commerce', 'm180401_150701_primary_addresses', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '40f5bd35-e3d9-46fd-815d-715f70d87cac');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (37, 'plugin:commerce', 'm180401_161901_first_last_name_optional', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '003af359-3982-4ac6-a65c-a4c06cbee44e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (38, 'plugin:commerce', 'm180402_161901_increase_size_of_snapshot', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '62403419-edfb-40a8-ae2f-cc468d91c495');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (39, 'plugin:commerce', 'm180402_161902_email_discount_usage', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1e5d48c5-a07b-4368-9bfc-1b2d0df34eaf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (40, 'plugin:commerce', 'm180402_161903_primary_customer_addresses_relations', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '954a38c5-e7ef-4621-9375-2a28d4cb8624');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (41, 'plugin:commerce', 'm180402_161904_order_addresses_relations', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '205a5188-c633-478a-b403-c2c88b8adec8');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (42, 'plugin:commerce', 'm180417_161904_fix_purchasables', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'd94f1355-1771-4c38-b4c7-beff11e6bfcf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (43, 'plugin:commerce', 'm180421_161904_transaction_note', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'ed41a432-cb2e-4ccf-882f-be50b94be7f4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (44, 'plugin:commerce', 'm180525_161904_available_for_purchase', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'ccd6577b-8d35-4c37-922c-7da74590ab76');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (45, 'plugin:commerce', 'm180601_161904_fix_orderLanguage', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '39af2024-0de4-4c72-aa04-bd060941a220');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (46, 'plugin:commerce', 'm180620_161904_fix_primaryAddressCascade', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '514624ff-a830-40b0-8236-9b71374e3f32');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (47, 'plugin:commerce', 'm180718_161906_add_orderPdfAttachment', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'a5123e27-5636-4ba6-a23f-dee9521b2cea');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (48, 'plugin:commerce', 'm180818_161906_fix_discountPurchasableType', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b51ab688-d235-4242-b286-5e56b59c4970');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (49, 'plugin:commerce', 'm180818_161907_fix_orderPaidWithAddresses', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '79eab8d3-1afb-48b2-a297-a3c8ae2bec97');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (50, 'plugin:commerce', 'm180918_161907_fix_uniqueEmailDiscountsUses', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '53cb66f6-7ed0-46c9-aed8-4447df8fa0fc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (51, 'plugin:commerce', 'm180918_161908_fix_messageLengthOnOrder', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '7cdcf9c7-6197-4c47-bfbb-4e2495f9723e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (52, 'plugin:commerce', 'm181024_100600_gateway_project_config_support', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '87071b0f-4dd6-4bb9-821c-5eb6476a067d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (53, 'plugin:commerce', 'm181113_161908_addReferenceToOrder', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '39c21b0b-0331-4a86-ac98-60502b7b54b1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (54, 'plugin:commerce', 'm181119_100600_lite_shipping_and_tax', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '32fc0540-aa52-46f6-ade1-1787321b5387');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (55, 'plugin:commerce', 'm181203_130000_order_status_archivable', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '4dde1bb2-324c-4b68-ac38-0fb9a14db42f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (56, 'plugin:commerce', 'm181203_162000_gateway_unique_index_drop', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '046de340-b98c-4260-80ce-93c1323d4dca');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (57, 'plugin:commerce', 'm181206_120000_remaining_project_config_support', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '52ec9b02-da70-44aa-a01a-9764b9bf2407');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (58, 'plugin:commerce', 'm181221_120000_sort_order_for_plans', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'a80d9ef5-ee88-4566-900b-0a65ef01710c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (59, 'plugin:commerce', 'm190109_223402_set_edition', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '56409b03-e06e-4ff8-ba97-777df33a60ee');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (60, 'plugin:commerce', 'm190111_161909_lineItemTotalCanBeNegative', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '8ff974cd-3eca-4b4c-8520-6e9f2fe3355a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (61, 'plugin:commerce', 'm190117_161909_replace_product_ref_tags', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '656bb1b7-87fb-46b0-b49d-3f2d3ac76849');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (62, 'plugin:commerce', 'm190126_000856_restore_variants_with_products', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'eabf52b4-9dcb-4b41-a579-4f5b7577f50e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (63, 'plugin:commerce', 'm190129_000857_insert_cached_data', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '10864ddb-f812-48a6-b443-b917457e259f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (64, 'plugin:commerce', 'm190131_000858_add_donation_purchasable', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'f20de80a-c38b-43dc-8529-a86d7fbc2b6f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (65, 'plugin:commerce', 'm190213_000858_discount_free_shipping_changes', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '03b499e4-eae5-42e0-8856-a028a1c89555');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (66, 'plugin:commerce', 'm190222_161405_permissions_to_uid', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '313a64e9-92ce-4f64-9993-394d8757c056');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (67, 'plugin:commerce', 'm190301_161406_unique_sku_constraint_in_app', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'faee63ad-6f83-4923-982f-cbf370e9bb6d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (68, 'plugin:commerce', 'm190311_161910_order_total', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '35496d6a-aac2-4155-8f94-884f80ea6d42');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (69, 'plugin:commerce', 'm190322_161911_register_on_checkout', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '12f50bac-ceca-4056-a2fe-a72722f73468');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (70, 'plugin:commerce', 'm190523_150000_fix_lineItems_dateCreated', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'd3689406-4c4b-4f28-bf34-4ff0c9990860');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (71, 'plugin:commerce', 'm190523_161912_line_item_statuses', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '286f8659-fa10-411a-85eb-bbe4ff0aa9ae');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (72, 'plugin:commerce', 'm190527_161913_order_recalc_mode', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '46f99ee0-678c-4c0b-b030-e0f09c1eba6c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (73, 'plugin:commerce', 'm190527_161914_admin_note_on_lineitem', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '3353f10b-53f0-463b-a386-a9a334485dbb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (74, 'plugin:commerce', 'm190528_161915_description_on_purchasable', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '22d50d51-d603-4166-9fc7-0082251abb99');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (75, 'plugin:commerce', 'm190622_161916_origin_on_order', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'acc677c6-cb80-4bc0-89b7-65d7cf673214');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (76, 'plugin:commerce', 'm190725_141100_subscription_suspension_fields', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'd6bc2035-6876-4bce-a7fd-2d820f532d60');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (77, 'plugin:commerce', 'm190821_150226_discount_purchaseTotal_update', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '59375981-f998-4ef3-9941-c84f04570878');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (78, 'plugin:commerce', 'm190823_071838_taxCategoryId_allow_null', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1bf1b75f-6244-409c-beaa-ce19785cef74');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (79, 'plugin:commerce', 'm190923_131716_update_overpaid_status', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '3e85bcb1-24c6-4810-94f2-572a78af31c3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (80, 'plugin:commerce', 'm190923_132226_update_paidStatuses', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '0aad835b-ca70-40c5-ac96-c4496e795f90');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (81, 'plugin:commerce', 'm190924_184909_taxCategory_allow_null_postgres', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'e9b46cbe-79ad-41d6-a28d-77e79aa7c264');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (82, 'plugin:commerce', 'm191004_184910_orderPaidDate', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '80a9fb99-fa0e-43d2-94cf-e5360d7b3a10');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (83, 'plugin:commerce', 'm191007_184911_orderStatus_from_archived_to_deleted', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1b92b003-de93-4f6f-b0b7-f1a915aa7504');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (84, 'plugin:commerce', 'm191008_153947_add_relationship_type_to_discounts', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'e8901d78-4b32-4bbc-a18c-36dff8129818');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (85, 'plugin:commerce', 'm191008_155732_add_relationship_type_to_sales', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '01bd96ce-af14-421a-bd38-f4096d24fd8f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (86, 'plugin:commerce', 'm191009_002748_add_ignoreSales_to_discounts', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '35c37515-4546-475c-844d-ad27d6c00202');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (87, 'plugin:commerce', 'm191009_184912_zipCode_match_added_to_shipping_and_tax_address_zones', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'f51f1811-e9d1-4cd1-9b36-007571733008');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (88, 'plugin:commerce', 'm191015_194704_add_description_to_orderStatus', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b76efdaa-b2d5-4718-a0f1-6c613cc066cd');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (89, 'plugin:commerce', 'm191015_201444_add_code_to_taxRates', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '19309bb6-ebdf-4b73-a1f2-0ceeb06dc42c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (90, 'plugin:commerce', 'm191016_231143_add_sortOrder_to_countries', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '5262db31-44c0-4d8a-837e-74ec03feb61d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (91, 'plugin:commerce', 'm191017_183550_add_extra_address_fields', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'a129350b-22a8-4f2d-88b4-edac9d7ca87e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (92, 'plugin:commerce', 'm191018_183551_cc_replyTo_emails', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'e76a8b06-4c77-4d7c-ae03-73616ba592f7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (93, 'plugin:commerce', 'm191021_184436_add_estimated_fields_to_order', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'e2a7f96e-a3a3-47ab-b461-62b0751fe567');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (94, 'plugin:commerce', 'm191021_190018_add_estimated_flag_to_addresses', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '414d6b03-45ae-4e82-af1c-10dfba9b81b5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (95, 'plugin:commerce', 'm191022_162628_add_estimated_toadjustments', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '73ec077b-228a-43c4-8963-3aaa214037ff');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (96, 'plugin:commerce', 'm191113_111954_add_plain_text_template_path', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '25aceb8f-f749-4f5a-a4ea-c5a1cca830c4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (97, 'plugin:commerce', 'm191114_115600_remove_customer_info_field', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'd9fa0b07-5de6-419d-ba63-f2b8ac47d54c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (98, 'plugin:commerce', 'm191114_133817_add_base_discount_type_attribute', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'f346a780-25d0-4e89-abe2-8d558fcc5363');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (99, 'plugin:commerce', 'm191115_103105_add_totalDiscountUses_column', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '9341f304-4bff-484e-a407-004c33059ca4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (100, 'plugin:commerce', 'm191115_103501_update_totalDiscountUses_with_current_uses', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'a2cc86d7-0f25-4533-9bd2-c05e036979fc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (101, 'plugin:commerce', 'm191115_105329_add_totalDiscountUseLimit', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'ea009d07-30de-4379-865b-123b600bb5ad');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (102, 'plugin:commerce', 'm191125_150308_add_enabled_countries', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'a92a034e-de98-42f0-8888-46bb69e3a34f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (103, 'plugin:commerce', 'm191125_150315_add_enabled_states', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1d624388-f1a7-44bd-8121-be9c0fd13e36');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (104, 'plugin:commerce', 'm191202_220748_updated_zipCodeConditional_column_type', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '91be4910-1c79-40bf-a705-61c7ff2a8784');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (105, 'plugin:commerce', 'm191203_163242_add_titleLabel_to_product_type', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '8f6a998d-dd54-4934-af5a-5f7f11452705');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (106, 'plugin:commerce', 'm200101_114320_remove_orphan_customers', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b20dade7-af05-49ad-9333-fbe8323c74d8');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (107, 'plugin:commerce', 'm200102_141910_add_variantTitleLabel_attribute', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'f886b628-c1c9-4eb0-bea0-e249bfc9e78a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (108, 'plugin:commerce', 'm200102_185704_update_totalDiscountUseLimit_with_current_totalUseLimit', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '96472bcb-78a1-4978-a026-be7c4034a189');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (109, 'plugin:commerce', 'm200102_185839_remove_totalUses_and_totalUseLimit', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '9ab99045-f869-4022-b71c-f54034bb0023');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (110, 'plugin:commerce', 'm200108_114623_consolidate_customer_records', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '4cdc91a1-f6cc-4a0f-b175-559700f92e74');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (111, 'plugin:commerce', 'm200112_220749_cache_totalDiscount_totalTax_totalShipping', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '04b1a6cb-2855-4c84-9aec-6adbeb4141f2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (112, 'plugin:commerce', 'm200127_235254_replace_old_revenue_widget', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '43cbf108-e8e3-40c9-b3ea-51782eef1a7a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (113, 'plugin:commerce', 'm200129_161705_create_missing_customer_records_for_users', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b31ac240-e56c-4beb-b737-6d7243f350f6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (114, 'plugin:commerce', 'm200206_161706_date_authorized', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '96aaab1e-e33a-460a-b0f2-56f2c91bc8fd');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (115, 'plugin:commerce', 'm200207_161707_sku_description_on_lineitem', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '45ea77bf-4e3f-48ab-a578-6b3c3674307d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (116, 'plugin:commerce', 'm200218_231144_add_sortOrder_to_states', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'db394829-397a-49a3-b48b-150ea6b63550');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (117, 'plugin:commerce', 'm200218_231199_add_appliesTo_to_discounts', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '0530de0a-5d85-4a73-95e6-e2966d86f7e5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (118, 'plugin:commerce', 'm200320_161708_add_index_order_email', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '775d3f14-aaa9-43a6-a33e-9f6bef647cb2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (119, 'plugin:commerce', 'm200402_172412_add_order_condition_formula', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1a715ef5-20f2-4ed1-92b5-023dbfdfff96');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (120, 'plugin:commerce', 'm200602_172413_fix_orders_without_customerId', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'b0256c73-70ca-4ee1-9fe8-2168c16fc770');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (121, 'plugin:commerce', 'm200617_172414_fix_country_state_sort_orders', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'e7ba8c05-9367-4049-909a-ce0a70170b65');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (122, 'plugin:commerce', 'm200722_172699_product_title_format', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '1b728fb4-5a5b-4eb3-97b2-ab0ab476c9d4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (123, 'plugin:commerce', 'm200723_072632_add_shippingMethodName_to_order', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '61c6b6d9-aa4b-473a-bb0c-06d8b59efa58');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (124, 'plugin:commerce', 'm200730_233644_field_layout_changes', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '40e250a0-7694-43e6-a948-b2348f5b52d6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (125, 'plugin:commerce', 'm200801_233755_pdfs', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '573d1361-b342-4a79-88a4-eeca5e11faef');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (126, 'plugin:commerce', 'm200804_185727_fix_productTitleFormat', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '032935b9-0276-4f1a-b475-147239d09d37');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (127, 'plugin:commerce', 'm200901_094328_add_lineItem_description_column_type', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'f44b595c-595e-42ef-bc5c-9370bd19f601');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (128, 'plugin:commerce', 'm200902_071515_add_itemSubtotal_order_column', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'cf9368cc-cad4-4c5a-bc14-ef70caac729b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (129, 'plugin:commerce', 'm200907_132553_fix_donation_siteIds', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '0cfe74be-bbd1-41a0-9cce-d913915b96ab');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (130, 'plugin:commerce', 'm200910_134928_fix_productType_title_format_columns', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '77acf42b-2571-41e7-a0f8-2353905d2818');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (131, 'plugin:commerce', 'm201005_169999_add_orderSiteId', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '6a2a2788-221e-4b37-bf9a-bcc8127e4f68');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (132, 'plugin:commerce', 'm201013_064230_add_subscription_id_fk', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '28495d89-fe45-4ac1-b165-61fa9a81867d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (133, 'plugin:commerce', 'm201102_064231_fix_deletedWithProduct_bool', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'dc28a20e-b8f6-442e-8424-f1345370d09e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (134, 'plugin:commerce', 'm201120_093135_add_locale_setting_to_email_and_pdf', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'dfafa9ad-7be4-404d-a222-c4d59837f445');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (135, 'plugin:commerce', 'm210302_050822_change_adjust_type_to_lowercase', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '6b6da102-d426-44ca-b7ad-400384b434e7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (136, 'plugin:commerce', 'm210317_050824_taxIncluded_update', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', 'a7749b5b-7a40-40c1-bfb2-acc66f41565b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (137, 'plugin:commerce', 'm210317_093136_includedTax_fix', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:09:49', '161c4df1-0c0c-47ab-8038-0f02258c05f1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (138, 'plugin:notifications', 'Install', '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:09:50', 'c62f0cc2-634a-463f-a3c5-689cbbd4599b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (139, 'plugin:redactor', 'm180430_204710_remove_old_plugins', '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:09:50', 'e4f7374d-3073-4813-9142-2eb21548414f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (140, 'plugin:redactor', 'Install', '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:09:50', '3596d0a7-7056-4f7b-9a38-aed1e1b65e60');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (141, 'plugin:redactor', 'm190225_003922_split_cleanup_html_settings', '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:09:50', '26a66c4e-759f-4166-9ce8-a715ec2fea7f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (142, 'craft', 'Install', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '8149be55-d3e8-4f74-ae62-847bcd96287f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (143, 'craft', 'm150403_183908_migrations_table_changes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'aa5e777e-dca0-47f8-ab14-454e53d8e41c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (144, 'craft', 'm150403_184247_plugins_table_changes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '5edbd2da-82b0-4da9-b40d-d003926a482e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (145, 'craft', 'm150403_184533_field_version', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '072db339-baf4-4998-be75-7e4fcec2720b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (146, 'craft', 'm150403_184729_type_columns', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '1efc08a6-b9c4-4a99-acd7-4c6b417dada5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (147, 'craft', 'm150403_185142_volumes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '53104df5-16b3-42ff-9355-e9b54cfe82f8');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (148, 'craft', 'm150428_231346_userpreferences', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '4b6087be-e201-4678-8da3-8d2490b171bc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (149, 'craft', 'm150519_150900_fieldversion_conversion', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '417ab704-a8ff-4ea3-8399-1bca784ae234');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (150, 'craft', 'm150617_213829_update_email_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '66e1e172-949f-4338-94bb-228fb2f762f0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (151, 'craft', 'm150721_124739_templatecachequeries', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'adaa6f94-4e78-4cd8-b2ef-976093afe694');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (152, 'craft', 'm150724_140822_adjust_quality_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'f095f48b-69f2-425f-84bc-e0cf0d341fd0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (153, 'craft', 'm150815_133521_last_login_attempt_ip', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9e1716d9-f4a0-4917-8f75-7980511b0f29');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (154, 'craft', 'm151002_095935_volume_cache_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '3de8344a-c69a-4084-9a84-129b2ec87912');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (155, 'craft', 'm151005_142750_volume_s3_storage_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '623e3bf5-1e6f-4273-b2c8-870d1a78b294');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (156, 'craft', 'm151016_133600_delete_asset_thumbnails', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ce2901d3-1ebc-4aa3-92c7-7c96ccd4cd11');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (157, 'craft', 'm151209_000000_move_logo', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '3346da48-6f0e-4cf4-8339-748282ce8ea5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (158, 'craft', 'm151211_000000_rename_fileId_to_assetId', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '97151fea-c5e5-4cff-89f9-df8a4d31bb8b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (159, 'craft', 'm151215_000000_rename_asset_permissions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '1f87fd5e-c107-4e6e-942d-67c5924cf99a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (160, 'craft', 'm160707_000001_rename_richtext_assetsource_setting', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'b5d513e1-5948-4615-b5f6-2fc62bd00504');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (161, 'craft', 'm160708_185142_volume_hasUrls_setting', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ba3507c0-9b7b-4908-b5ac-32917ecb30de');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (162, 'craft', 'm160714_000000_increase_max_asset_filesize', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '40b78c40-2c3d-4eac-ad86-dfbb51be9aeb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (163, 'craft', 'm160727_194637_column_cleanup', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'aece66e9-97d0-4480-972e-878397976e94');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (164, 'craft', 'm160804_110002_userphotos_to_assets', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '703d8cdb-802d-4c27-ba6d-de81100833d1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (165, 'craft', 'm160807_144858_sites', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '70ad008d-68de-497a-ab72-8b7eff3cb27d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (166, 'craft', 'm160829_000000_pending_user_content_cleanup', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'b29d471e-9176-4aed-adf1-b0f7d191ad46');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (167, 'craft', 'm160830_000000_asset_index_uri_increase', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '1bdc258d-a2cb-4d60-8984-860ff9237a97');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (168, 'craft', 'm160912_230520_require_entry_type_id', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a62fcbf4-864e-4038-ac9a-42eb6351c09e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (169, 'craft', 'm160913_134730_require_matrix_block_type_id', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a086c2d9-3913-40bf-a750-fad4c3949db1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (170, 'craft', 'm160920_174553_matrixblocks_owner_site_id_nullable', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c99a5590-46ee-4748-8d6a-ec01b420fcc3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (171, 'craft', 'm160920_231045_usergroup_handle_title_unique', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '8c013d78-3388-4c40-a672-a12739a467b2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (172, 'craft', 'm160925_113941_route_uri_parts', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'f36c1aaf-2a1f-4794-ac9c-1afe75d83d06');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (173, 'craft', 'm161006_205918_schemaVersion_not_null', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9a7574bd-08fe-43c3-bbe5-8e41379f8bc7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (174, 'craft', 'm161007_130653_update_email_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'efccb8ad-df81-41d9-84a5-04655946888d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (175, 'craft', 'm161013_175052_newParentId', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9a181052-e9a4-4a62-9b19-0cbd4e2a9da1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (176, 'craft', 'm161021_102916_fix_recent_entries_widgets', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '34c1676f-5564-4651-b4d6-1f5b0a451558');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (177, 'craft', 'm161021_182140_rename_get_help_widget', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '7aa9bd7e-8f15-4771-a25d-20b6157e2f11');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (178, 'craft', 'm161025_000000_fix_char_columns', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '219d5c5b-269f-4c2f-acba-5cbf5d0ff5b9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (179, 'craft', 'm161029_124145_email_message_languages', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9780c259-cb44-4d3a-a1a4-052f3eab3a1f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (180, 'craft', 'm161108_000000_new_version_format', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '461754ff-a0d6-41b0-ae77-5625e8db7b82');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (181, 'craft', 'm161109_000000_index_shuffle', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '45594798-7c35-49a9-ad9b-a1ede39e6cbc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (182, 'craft', 'm161122_185500_no_craft_app', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '157a8f85-7d9e-4906-944f-287b580c7313');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (183, 'craft', 'm161125_150752_clear_urlmanager_cache', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '0f0d2f10-a75b-4a8d-8734-ec2bd3712a48');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (184, 'craft', 'm161220_000000_volumes_hasurl_notnull', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a33a9573-00a9-40af-ac6e-9655f9e931e7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (185, 'craft', 'm170114_161144_udates_permission', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'd97a1c1b-b4da-4d23-a193-2cc55baeb115');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (186, 'craft', 'm170120_000000_schema_cleanup', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '1c811202-eed7-4784-a5c0-98d3eae6c444');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (187, 'craft', 'm170126_000000_assets_focal_point', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a9360f8d-a595-426d-8398-83409463c005');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (188, 'craft', 'm170206_142126_system_name', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '3cae6e66-656f-42c5-8669-edd443315c6a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (189, 'craft', 'm170217_044740_category_branch_limits', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '14706c3d-fca8-4052-ba81-e7b4552c0000');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (190, 'craft', 'm170217_120224_asset_indexing_columns', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'cb257094-e6a2-43e9-8fb3-dfe59340e59a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (191, 'craft', 'm170223_224012_plain_text_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'e9914556-a715-4e19-9e5c-ae1e881fae5d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (192, 'craft', 'm170227_120814_focal_point_percentage', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '0c2e0066-e14e-4f8f-b109-f6f1d7f72ea0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (193, 'craft', 'm170228_171113_system_messages', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '20a3eb72-b199-481b-9c5c-7ad7d38a752a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (194, 'craft', 'm170303_140500_asset_field_source_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '5e0264aa-cb6c-4286-848f-61557517d4c4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (195, 'craft', 'm170306_150500_asset_temporary_uploads', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '204f3aaa-ad14-4f09-a155-22b447692ccf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (196, 'craft', 'm170523_190652_element_field_layout_ids', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'd54190be-bede-47c3-b1fc-1a6ae88e59ff');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (197, 'craft', 'm170621_195237_format_plugin_handles', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'b4e37752-26c0-41cf-9046-ea6900b855d1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (198, 'craft', 'm170630_161027_deprecation_line_nullable', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a922cb6a-4cc8-45c4-8954-55b6ca574d70');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (199, 'craft', 'm170630_161028_deprecation_changes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '771b36a1-b6ed-4a03-b9f4-baeb3d3452c4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (200, 'craft', 'm170703_181539_plugins_table_tweaks', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'dccb4737-4ae9-431d-beb2-3f284ed3646f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (201, 'craft', 'm170704_134916_sites_tables', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '046bc6a7-958e-4ad7-b94c-95e9653189bb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (202, 'craft', 'm170706_183216_rename_sequences', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9650bc16-ffdb-4718-b34f-1519c8baf8b0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (203, 'craft', 'm170707_094758_delete_compiled_traits', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2bb39acd-9f45-464a-9797-091ee4dc6f68');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (204, 'craft', 'm170731_190138_drop_asset_packagist', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '6d83e9af-a8b1-4722-8e6a-6ac3f66024e6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (205, 'craft', 'm170810_201318_create_queue_table', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '32750ae4-c10d-4661-893c-f59746122148');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (206, 'craft', 'm170903_192801_longblob_for_queue_jobs', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'b147e9cd-d682-4558-8e3b-55329e547cd7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (207, 'craft', 'm170914_204621_asset_cache_shuffle', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2e9608b0-8587-4be6-9ff4-2b02267b778d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (208, 'craft', 'm171011_214115_site_groups', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c7cd4451-e6b4-48f1-a938-8af3c9c14ee0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (209, 'craft', 'm171012_151440_primary_site', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '747f5672-b9f6-4355-b98b-17a51336f849');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (210, 'craft', 'm171013_142500_transform_interlace', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ccaf9d01-76e8-4966-a7df-281375db0971');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (211, 'craft', 'm171016_092553_drop_position_select', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '57d5dc55-3156-4db2-91c3-d201fa8110ce');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (212, 'craft', 'm171016_221244_less_strict_translation_method', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '8e82562c-5439-4846-9c97-4f075c53b56f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (213, 'craft', 'm171107_000000_assign_group_permissions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '62a7989d-2c84-4870-a4a6-d5be12ec6014');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (214, 'craft', 'm171117_000001_templatecache_index_tune', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'dd2c6d90-1044-4247-b149-4eea98817ac4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (215, 'craft', 'm171126_105927_disabled_plugins', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9a08ccb0-4852-418c-97bf-ef0c3d83960e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (216, 'craft', 'm171130_214407_craftidtokens_table', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a6bfacd3-3ffd-4f61-bcd8-0409bb5bd05b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (217, 'craft', 'm171202_004225_update_email_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '85946f21-c587-4e02-a608-316e040ee964');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (218, 'craft', 'm171204_000001_templatecache_index_tune_deux', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '59e6607c-47e9-4562-a8c7-51fbeab9e5dc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (219, 'craft', 'm171205_130908_remove_craftidtokens_refreshtoken_column', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '424e06df-db31-40e7-85e8-f388bd4229d1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (220, 'craft', 'm171218_143135_longtext_query_column', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'b4fa1345-3e57-4322-912b-e6cf3cef7b49');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (221, 'craft', 'm171231_055546_environment_variables_to_aliases', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ef6c1fec-7ace-4d9c-9c0f-6e554e36205a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (222, 'craft', 'm180113_153740_drop_users_archived_column', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'cd3cec23-f1dd-424c-be19-22dcb145dc00');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (223, 'craft', 'm180122_213433_propagate_entries_setting', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '27bc9223-33ff-4d80-b46c-8cd003683263');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (224, 'craft', 'm180124_230459_fix_propagate_entries_values', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '90ca7e4c-f859-4988-8ebe-95817e6646bf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (225, 'craft', 'm180128_235202_set_tag_slugs', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '89cffa36-287e-4bab-90d3-f693b0b19eeb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (226, 'craft', 'm180202_185551_fix_focal_points', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'df5e9bbe-62a2-4936-a49c-ace69e45edc7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (227, 'craft', 'm180217_172123_tiny_ints', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '98d9447e-9803-4feb-b0ae-c45c26ca85cc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (228, 'craft', 'm180321_233505_small_ints', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2679a6c2-3c30-4944-831c-a892592adb35');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (229, 'craft', 'm180404_182320_edition_changes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c730d193-f212-4f42-b03e-4ff1abc48c89');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (230, 'craft', 'm180411_102218_fix_db_routes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '08cbe19e-391f-4854-8693-21a366b2af6c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (231, 'craft', 'm180416_205628_resourcepaths_table', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '8e17e61f-c4c8-4528-ba2d-9ef688af1c83');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (232, 'craft', 'm180418_205713_widget_cleanup', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c03d501a-1879-4504-b28a-0adc803c09d5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (233, 'craft', 'm180425_203349_searchable_fields', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '18e6b905-e5ff-445c-b345-d4e8d5fa30ad');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (234, 'craft', 'm180516_153000_uids_in_field_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'cf9de5c3-04c0-483b-9545-7d419c61255a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (235, 'craft', 'm180517_173000_user_photo_volume_to_uid', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c8baa436-865b-41c2-bad7-ff4dc71e31ef');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (236, 'craft', 'm180518_173000_permissions_to_uid', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '062e4c4a-3de4-445c-9672-8c1c4bee6d46');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (237, 'craft', 'm180520_173000_matrix_context_to_uids', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'fadf2d5b-d027-4c78-a550-1b9e69312b12');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (238, 'craft', 'm180521_172900_project_config_table', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '011919d6-d601-4c12-8369-bfb054d9fc5d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (239, 'craft', 'm180521_173000_initial_yml_and_snapshot', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'b02527a2-620a-40ce-b537-94da0d62b530');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (240, 'craft', 'm180731_162030_soft_delete_sites', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c9d86048-57c2-4b02-b4ee-56cc61844c53');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (241, 'craft', 'm180810_214427_soft_delete_field_layouts', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '60104cb3-89fd-4dae-991b-e28c7462de29');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (242, 'craft', 'm180810_214439_soft_delete_elements', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'dcac89e6-9cb0-4210-8ea1-c45ad51f2d2e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (243, 'craft', 'm180824_193422_case_sensitivity_fixes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '13a481b4-265d-4dfd-8678-1335bb354c44');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (244, 'craft', 'm180901_151639_fix_matrixcontent_tables', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ae5d0315-2a43-444e-b80e-b26945577db2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (245, 'craft', 'm180904_112109_permission_changes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '67a03408-0a93-4b9d-9092-bc71863c25b1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (246, 'craft', 'm180910_142030_soft_delete_sitegroups', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'b1f24813-e929-4eb1-9f41-45e2562e7c5c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (247, 'craft', 'm181011_160000_soft_delete_asset_support', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ebc37357-d947-49ed-950a-991feb3dc468');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (248, 'craft', 'm181016_183648_set_default_user_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ebb59339-76bb-4672-a387-a5b37b49e095');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (249, 'craft', 'm181017_225222_system_config_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '38d3d746-e33d-46b5-8353-1d4e67307ea9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (250, 'craft', 'm181018_222343_drop_userpermissions_from_config', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ad84095e-133f-482a-8620-d595a2ce7c3c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (251, 'craft', 'm181029_130000_add_transforms_routes_to_config', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '1d45b5a8-5a3f-4af1-9091-7480ae7cab0d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (252, 'craft', 'm181112_203955_sequences_table', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c1152710-1fc4-42d3-81f9-f8bbc918ec02');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (253, 'craft', 'm181121_001712_cleanup_field_configs', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '6c0f4752-6ee2-4556-8954-e435ed27bb8b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (254, 'craft', 'm181128_193942_fix_project_config', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2970a268-ab56-440c-9b9c-d9542d23bc75');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (255, 'craft', 'm181130_143040_fix_schema_version', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'bc748607-daad-4327-8143-aeb9ae73a4c2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (256, 'craft', 'm181211_143040_fix_entry_type_uids', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '6ce66c01-2cb6-4201-ac78-80433bd26473');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (257, 'craft', 'm181217_153000_fix_structure_uids', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '63258255-e006-4e3d-92b7-deac6e7da5a8');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (258, 'craft', 'm190104_152725_store_licensed_plugin_editions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '82623987-6c88-4460-bffd-8a6ddf5a77cb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (259, 'craft', 'm190108_110000_cleanup_project_config', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c480106b-b0e4-42c1-ade4-c5dbdf94b9f3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (260, 'craft', 'm190108_113000_asset_field_setting_change', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '93b4fdc0-76e5-4bd0-b25f-e1b4863155e3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (261, 'craft', 'm190109_172845_fix_colspan', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '32e2c337-014e-4280-837d-8a6d565c226c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (262, 'craft', 'm190110_150000_prune_nonexisting_sites', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'dcd95a77-5bb9-4814-a4fb-4946ff29ba2e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (263, 'craft', 'm190110_214819_soft_delete_volumes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '70b10105-bcb1-47d6-8cdb-9046c5eeb450');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (264, 'craft', 'm190112_124737_fix_user_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '557bae4e-1fc1-4c9b-b88c-b32d101ed51b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (265, 'craft', 'm190112_131225_fix_field_layouts', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'aaaf0af7-9e75-4b38-b8ef-427b9ce5c9c3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (266, 'craft', 'm190112_201010_more_soft_deletes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '8fdb9297-ef4a-4ab6-9d31-847d65cb8c85');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (267, 'craft', 'm190114_143000_more_asset_field_setting_changes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '39818eb2-f8d9-44aa-ab90-f4b64679ba41');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (268, 'craft', 'm190121_120000_rich_text_config_setting', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '0b878939-7ade-4a7b-a66f-1aa23d64ffcd');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (269, 'craft', 'm190125_191628_fix_email_transport_password', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '7b57c699-6a4b-4a0b-8257-f7b501e266f4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (270, 'craft', 'm190128_181422_cleanup_volume_folders', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '34f9fe7e-2c42-4c49-a069-45d2769c7cc0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (271, 'craft', 'm190205_140000_fix_asset_soft_delete_index', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '13f50084-e27a-4cdc-a1f4-5160596bf84a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (272, 'craft', 'm190218_143000_element_index_settings_uid', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2d745a1f-ba52-4187-b247-5c0ae1e9fb68');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (273, 'craft', 'm190312_152740_element_revisions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c3308815-e994-4779-b041-ea6bbbffb208');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (274, 'craft', 'm190327_235137_propagation_method', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '0cd86071-0b5e-44df-975b-3be7a57318b7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (275, 'craft', 'm190401_223843_drop_old_indexes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '0dd09db7-f847-47e3-9f5f-879484188c59');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (276, 'craft', 'm190416_014525_drop_unique_global_indexes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a0b3bb44-1a20-42fc-a3f3-b7e2a7bbaa87');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (277, 'craft', 'm190417_085010_add_image_editor_permissions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'e32b2754-be20-40f8-a39b-859b43b886b4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (278, 'craft', 'm190502_122019_store_default_user_group_uid', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2bcdf924-17e9-4e01-932d-63a41f219b08');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (279, 'craft', 'm190504_150349_preview_targets', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a7a85d23-5789-44fa-8a67-6c2cdd2523de');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (280, 'craft', 'm190516_184711_job_progress_label', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9124799e-809f-4c5a-9b9e-02e2b8d9ed85');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (281, 'craft', 'm190523_190303_optional_revision_creators', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'dfe4a1da-068f-414d-a220-755b1b311d8c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (282, 'craft', 'm190529_204501_fix_duplicate_uids', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '139da3b3-1120-4c87-b5b9-9995ce4acb3b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (283, 'craft', 'm190605_223807_unsaved_drafts', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '4a0c21ae-b39c-4ccc-996a-945a5d7b45ef');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (284, 'craft', 'm190607_230042_entry_revision_error_tables', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'acf5a199-e43c-4e50-ac68-7c2a0010d4c4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (285, 'craft', 'm190608_033429_drop_elements_uid_idx', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'd966e3e2-80ff-4ed2-8be3-e4cc06c31bb2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (286, 'craft', 'm190617_164400_add_gqlschemas_table', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '1051a403-b07e-434f-866e-09e7350bf3df');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (287, 'craft', 'm190624_234204_matrix_propagation_method', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '72e7e17f-71e6-4edb-ac72-048362c4357c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (288, 'craft', 'm190711_153020_drop_snapshots', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '44b55717-2d24-40cb-b808-03a04ea92053');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (289, 'craft', 'm190712_195914_no_draft_revisions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '80432595-1a7a-492f-8160-9565910c1cd7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (290, 'craft', 'm190723_140314_fix_preview_targets_column', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c4a33eea-8d5e-4f29-ab8f-2d54c8514576');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (291, 'craft', 'm190820_003519_flush_compiled_templates', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'f37fbf1c-2068-400b-95fd-40b476ca7dcb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (292, 'craft', 'm190823_020339_optional_draft_creators', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '6bcbe459-814e-41b3-b339-438239a5f174');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (293, 'craft', 'm190913_152146_update_preview_targets', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'ba222baa-2577-4d4e-914f-83ce0d2180f7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (294, 'craft', 'm191107_122000_add_gql_project_config_support', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'dfebe49f-1701-4f31-9df3-3914f664b7bf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (295, 'craft', 'm191204_085100_pack_savable_component_settings', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'd69ba665-482d-4c90-9b54-2ff94b6f22f1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (296, 'craft', 'm191206_001148_change_tracking', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '93e718ea-2ea8-4c2d-8690-894f52ec5942');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (297, 'craft', 'm191216_191635_asset_upload_tracking', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '30698239-0ec2-44e0-bcec-af2ca1934e50');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (298, 'craft', 'm191222_002848_peer_asset_permissions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '86c8fb3e-cb8b-4347-9e3b-25bb13ba7ee6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (299, 'craft', 'm200127_172522_queue_channels', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'f655f5b7-2329-4590-9976-dff2862431b1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (300, 'craft', 'm200211_175048_truncate_element_query_cache', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'bb8682f7-6e4c-48d4-88fd-09efc1862d70');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (301, 'craft', 'm200213_172522_new_elements_index', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '8e818fde-7a28-4924-937f-12c6dd7205e4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (302, 'craft', 'm200228_195211_long_deprecation_messages', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c428cd1f-aae0-43d6-abb6-ad087c594b8f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (303, 'craft', 'm200306_054652_disabled_sites', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '7f51c2df-609b-47ff-8135-6f36e5f0890b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (304, 'craft', 'm200522_191453_clear_template_caches', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '80112aa4-fa9c-48b0-a412-55e7c06cac64');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (305, 'craft', 'm200606_231117_migration_tracks', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '170e59a4-9978-4e91-b671-9bd6334d5335');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (306, 'craft', 'm200619_215137_title_translation_method', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a37d354f-1952-4e76-a484-6a2af6f143fd');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (307, 'craft', 'm200620_005028_user_group_descriptions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'd4a92806-9205-49b4-a99d-2f90b9e51a76');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (308, 'craft', 'm200620_230205_field_layout_changes', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '5d342c9d-2080-42dc-a813-fa070bf35469');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (309, 'craft', 'm200625_131100_move_entrytypes_to_top_project_config', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '56957c96-b32c-400f-8834-9a8131e4ab53');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (310, 'craft', 'm200629_112700_remove_project_config_legacy_files', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c5af1591-d80f-47a2-a338-9652239f3f20');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (311, 'craft', 'm200630_183000_drop_configmap', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '7cebb164-d2dd-426d-b4ad-ae766174cc75');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (312, 'craft', 'm200715_113400_transform_index_error_flag', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c67445b7-30bc-4ed8-9785-5c0889198490');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (313, 'craft', 'm200716_110900_replace_file_asset_permissions', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2d276900-ef8d-4291-aa53-3dfe2fbcc896');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (314, 'craft', 'm200716_153800_public_token_settings_in_project_config', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'c525860d-4dfb-44e8-9ff9-75452329a651');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (315, 'craft', 'm200720_175543_drop_unique_constraints', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'e0be40ac-4c19-4296-8a60-5bf03cb31b9b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (316, 'craft', 'm200825_051217_project_config_version', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '9924925d-61c8-4bd7-baab-71f26e4984e6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (317, 'craft', 'm201116_190500_asset_title_translation_method', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '5a5a9ef4-5f2a-4b7a-8e1b-4daa8ef65a2f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (318, 'craft', 'm201124_003555_plugin_trials', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '78ea571c-9025-4002-a1f1-42ae16b8598a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (319, 'craft', 'm210209_135503_soft_delete_field_groups', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'a3060bf4-714d-4d3c-88bf-58ba3a7b8fdf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (320, 'craft', 'm210212_223539_delete_invalid_drafts', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '4c63cf3b-5b52-4f61-b9be-f69fa7036062');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (321, 'craft', 'm210214_202731_track_saved_drafts', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'fd673a65-95f4-4731-80a6-7f7929e4ee7b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (322, 'craft', 'm210223_150900_add_new_element_gql_schema_components', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '23ed8231-677a-423e-93ef-624949d97ad3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (323, 'craft', 'm210224_162000_add_projectconfignames_table', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '696fc2d0-959d-485c-8999-6e324856e9f5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (324, 'craft', 'm210326_132000_invalidate_projectconfig_cache', '2021-03-30 18:09:54', '2021-03-30 18:09:54', '2021-03-30 18:09:54', 'aad0d312-14de-4c98-abb2-00befea6abc0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (325, 'plugin:colour-swatches', 'm200911_142127_update_namespace', '2021-03-30 18:12:50', '2021-03-30 18:12:50', '2021-03-30 18:12:50', 'ddc0a6a5-4014-4a19-b100-c6baf11916c7');


--
-- Data for Name: notifications_notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (3, 'minify', '1.2.10', '1.0.0', 'unknown', NULL, '2021-03-30 18:09:49', '2021-03-30 18:09:49', '2021-03-30 18:49:18', '429e260b-1087-46bd-ac6f-6f0a744f4a1c');
INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (4, 'notifications', '1.1.4', '1.0.0', 'unknown', NULL, '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:49:18', 'd4d23fcc-e59a-41a1-8ffc-be8ae0651565');
INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (5, 'password-policy', '1.0.6', '1.0.0', 'unknown', NULL, '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:49:18', '2c73d04f-bfbb-4d94-aa37-d437be751129');
INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (6, 'redactor', '2.8.5', '2.3.0', 'unknown', NULL, '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:49:18', '07991e15-64cb-457f-841f-acdc83d02689');
INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (7, 'twigpack', '1.2.11', '1.0.0', 'unknown', NULL, '2021-03-30 18:09:50', '2021-03-30 18:09:50', '2021-03-30 18:49:18', 'e8746593-ee21-4289-80d6-863357ef43ad');
INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (1, 'colour-swatches', '1.4.1.1', '1.4.1.1', 'unknown', NULL, '2021-03-30 18:09:46', '2021-03-30 18:09:46', '2021-03-30 18:49:18', '92574c6c-2a13-415d-8c57-8c0bda618e18');
INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (8, 'cp-style-guide', '1.0.2', '1.0.0', 'unknown', NULL, '2021-03-30 18:47:37', '2021-03-30 18:47:37', '2021-03-30 18:49:18', '41e6fe92-5d23-441c-b67c-25c811ece053');
INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (2, 'commerce', '3.2.17.3', '3.2.18', 'trial', NULL, '2021-03-30 18:09:46', '2021-03-30 18:09:46', '2021-03-30 18:49:18', '20125a16-2193-4d97-bf13-287a24c658a9');


--
-- Data for Name: projectconfig; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.projectconfig (path, value) VALUES ('siteGroups.f89601e9-4ba9-4a48-9e99-350aa9914912.name', '"$SITE_NAME"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.viewMode', '"large"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.translationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.translationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.type', '"craft\\fields\\Assets"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.contentColumnType', '"text"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.fieldGroup', '"d08a0d16-0e00-49e6-9cd4-465fa2d65d7d"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.handle', '"errorText"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.instructions', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.name', '"Error Text"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.searchable', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.byteLimit', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.charLimit', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.code', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.columnType', '"text"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.initialRows', '"4"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.multiline', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.placeholder', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.settings.uiMode', '"normal"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.translationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.translationMethod', '"none"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.e6d658aa-c335-4f15-bbcd-59fe05d9e913.type', '"craft\\fields\\PlainText"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.publicToken.enabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.publicToken.expiryDate', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.colour-swatches.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.colour-swatches.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.minify.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.minify.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.minify.schemaVersion', '"1.0.0"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.notifications.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.notifications.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.notifications.schemaVersion', '"1.0.0"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.password-policy.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.password-policy.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.password-policy.schemaVersion', '"1.0.0"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.redactor.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.redactor.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.redactor.schemaVersion', '"2.3.0"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.twigpack.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.twigpack.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.twigpack.schemaVersion', '"1.0.0"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.enableVersioning', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.handle', '"homepage"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.name', '"Homepage"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.siteSettings.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.siteSettings.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.siteSettings.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.template', '"index"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.siteSettings.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.uriFormat', '"__home__"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.54e60257-f31a-44aa-960e-bbd364197e28.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.commerce.edition', '"pro"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.commerce.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.commerce.licenseKey', '"0GEHO8SO861PDA3MA1SFZEGF"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.commerce.schemaVersion', '"3.2.18"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.colour-swatches.schemaVersion', '"1.4.1.1"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.cp-style-guide.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.cp-style-guide.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.cp-style-guide.schemaVersion', '"1.0.0"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.gateways.e6c2eb12-4cb1-4a71-8e5f-255e1b211a83.handle', '"dummy"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.gateways.e6c2eb12-4cb1-4a71-8e5f-255e1b211a83.isFrontendEnabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.gateways.e6c2eb12-4cb1-4a71-8e5f-255e1b211a83.name', '"Dummy"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.gateways.e6c2eb12-4cb1-4a71-8e5f-255e1b211a83.paymentType', '"purchase"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.gateways.e6c2eb12-4cb1-4a71-8e5f-255e1b211a83.sortOrder', '99');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.gateways.e6c2eb12-4cb1-4a71-8e5f-255e1b211a83.type', '"craft\\commerce\\gateways\\Dummy"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.orderStatuses.e1e9bc49-0f42-4f88-980c-26c6afcd1671.color', '"green"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.orderStatuses.e1e9bc49-0f42-4f88-980c-26c6afcd1671.default', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.orderStatuses.e1e9bc49-0f42-4f88-980c-26c6afcd1671.description', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.orderStatuses.e1e9bc49-0f42-4f88-980c-26c6afcd1671.handle', '"new"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.orderStatuses.e1e9bc49-0f42-4f88-980c-26c6afcd1671.name', '"New"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.orderStatuses.e1e9bc49-0f42-4f88-980c-26c6afcd1671.sortOrder', '99');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.descriptionFormat', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.handle', '"clothing"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.hasDimensions', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.hasProductTitleField', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.hasVariantTitleField', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.hasVariants', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.name', '"Clothing"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.productTitleFormat', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.siteSettings.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.siteSettings.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.template', '"shop/products/_product"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.siteSettings.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.uriFormat', '"shop/products/{slug}"');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.skuFormat', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('commerce.productTypes.f83257f1-bf0b-463f-a366-30cdcc88a10c.titleFormat', '"{product.title}"');
INSERT INTO public.projectconfig (path, value) VALUES ('dateModified', '1617130681');
INSERT INTO public.projectconfig (path, value) VALUES ('system.edition', '"pro"');
INSERT INTO public.projectconfig (path, value) VALUES ('system.live', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('system.name', '"$SITE_NAME"');
INSERT INTO public.projectconfig (path, value) VALUES ('system.retryDuration', '60');
INSERT INTO public.projectconfig (path, value) VALUES ('system.schemaVersion', '"3.6.7"');
INSERT INTO public.projectconfig (path, value) VALUES ('system.timeZone', '"Europe/London"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.6005c2f9-5d85-4442-b712-22e070096ac8.isPublic', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.6005c2f9-5d85-4442-b712-22e070096ac8.name', '"Public Schema"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.fieldLayouts.d1d0d5c5-a0b8-4cd8-ba0f-43ec2da1b788.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.handle', '"homepage"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.name', '"Homepage"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.section', '"54e60257-f31a-44aa-960e-bbd364197e28"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.fb3a8f31-d1cc-4c13-903b-a501f7e51f54.titleTranslationMethod', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fieldGroups.94b4d5ac-d7ea-4241-a6cb-92b39f482f99.name', '"Common"');
INSERT INTO public.projectconfig (path, value) VALUES ('fieldGroups.d08a0d16-0e00-49e6-9cd4-465fa2d65d7d.name', '"Errors"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.contentColumnType', '"text"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.fieldGroup', '"d08a0d16-0e00-49e6-9cd4-465fa2d65d7d"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.handle', '"errorHeadline"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.instructions', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.name', '"Error Headline"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.searchable', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.byteLimit', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.charLimit', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.code', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.columnType', '"text"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.initialRows', '"4"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.multiline', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.placeholder', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.settings.uiMode', '"normal"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.translationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.translationMethod', '"none"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.b8ba7115-3804-4c06-8a96-501963d1fc5c.type', '"craft\\fields\\PlainText"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.contentColumnType', '"string"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.fieldGroup', '"d08a0d16-0e00-49e6-9cd4-465fa2d65d7d"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.handle', '"errorImage"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.instructions', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.name', '"Error Image"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.searchable', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.allowSelfRelations', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.allowUploads', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.allowedKinds.0', '"image"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.defaultUploadLocationSource', '"volume:5c642d7e-b16b-4836-9575-668d75d242e5"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.defaultUploadLocationSubpath', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.limit', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.localizeRelations', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.previewMode', '"full"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.restrictFiles', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.selectionLabel', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.showSiteMenu', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.showUnpermittedFiles', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.showUnpermittedVolumes', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.singleUploadLocationSource', '"volume:5c642d7e-b16b-4836-9575-668d75d242e5"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.singleUploadLocationSubpath', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.source', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.sources.0', '"volume:5c642d7e-b16b-4836-9575-668d75d242e5"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.targetSiteId', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.useSingleFolder', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.a5cb77be-c4d9-4d3e-88fb-d5384ca13941.settings.validateRelatedElements', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\AssetTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.fieldLayouts.f6f8c6f0-1d9e-4eb4-9b12-a5e217e7b89a.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.handle', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.name', '"Site"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.settings.path', '"@webroot/assets/site"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.type', '"craft\\volumes\\Local"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.5c642d7e-b16b-4836-9575-668d75d242e5.url', '"@assetsUrl/assets/site"');
INSERT INTO public.projectconfig (path, value) VALUES ('email.fromEmail', '"development@percipio.london"');
INSERT INTO public.projectconfig (path, value) VALUES ('email.fromName', '"Craft"');
INSERT INTO public.projectconfig (path, value) VALUES ('email.transportType', '"craft\\mail\\transportadapters\\Sendmail"');
INSERT INTO public.projectconfig (path, value) VALUES ('users.allowPublicRegistration', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('users.defaultGroup', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('users.photoSubpath', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('users.photoVolumeUid', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('users.requireEmailVerification', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.baseUrl', '"$SITE_URL"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.handle', '"default"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.language', '"en-GB"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.name', '"$SITE_NAME"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.primary', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.siteGroup', '"f89601e9-4ba9-4a48-9e99-350aa9914912"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.5da841b1-ca0d-46ff-8bb1-04d6c889ac54.sortOrder', '1');


--
-- Data for Name: projectconfignames; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.projectconfignames (uid, name) VALUES ('f89601e9-4ba9-4a48-9e99-350aa9914912', '$SITE_NAME');
INSERT INTO public.projectconfignames (uid, name) VALUES ('94b4d5ac-d7ea-4241-a6cb-92b39f482f99', 'Common');
INSERT INTO public.projectconfignames (uid, name) VALUES ('d08a0d16-0e00-49e6-9cd4-465fa2d65d7d', 'Errors');
INSERT INTO public.projectconfignames (uid, name) VALUES ('b8ba7115-3804-4c06-8a96-501963d1fc5c', 'Error Headline');
INSERT INTO public.projectconfignames (uid, name) VALUES ('a5cb77be-c4d9-4d3e-88fb-d5384ca13941', 'Error Image');
INSERT INTO public.projectconfignames (uid, name) VALUES ('e6d658aa-c335-4f15-bbcd-59fe05d9e913', 'Error Text');
INSERT INTO public.projectconfignames (uid, name) VALUES ('fb3a8f31-d1cc-4c13-903b-a501f7e51f54', 'Homepage');
INSERT INTO public.projectconfignames (uid, name) VALUES ('5c642d7e-b16b-4836-9575-668d75d242e5', 'Site');
INSERT INTO public.projectconfignames (uid, name) VALUES ('f83257f1-bf0b-463f-a366-30cdcc88a10c', 'Clothing');
INSERT INTO public.projectconfignames (uid, name) VALUES ('54e60257-f31a-44aa-960e-bbd364197e28', 'Homepage');
INSERT INTO public.projectconfignames (uid, name) VALUES ('e6c2eb12-4cb1-4a71-8e5f-255e1b211a83', 'Dummy');
INSERT INTO public.projectconfignames (uid, name) VALUES ('e1e9bc49-0f42-4f88-980c-26c6afcd1671', 'New');
INSERT INTO public.projectconfignames (uid, name) VALUES ('6005c2f9-5d85-4442-b712-22e070096ac8', 'Public Schema');


--
-- Data for Name: queue; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: resourcepaths; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.resourcepaths (hash, path) VALUES ('13e52610', '@lib/jquery-touch-events');
INSERT INTO public.resourcepaths (hash, path) VALUES ('8964d128', '@lib/velocity');
INSERT INTO public.resourcepaths (hash, path) VALUES ('c7cd4a8d', '@lib/jquery-ui');
INSERT INTO public.resourcepaths (hash, path) VALUES ('95437ec0', '@lib/jquery.payment');
INSERT INTO public.resourcepaths (hash, path) VALUES ('599c904a', '@lib/datepicker-i18n');
INSERT INTO public.resourcepaths (hash, path) VALUES ('14411ad2', '@lib/picturefill');
INSERT INTO public.resourcepaths (hash, path) VALUES ('a693257b', '@craft/web/assets/edituser/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('403f3756', '@lib/selectize');
INSERT INTO public.resourcepaths (hash, path) VALUES ('1e8dfc9f', '@craft/web/assets/userpermissions/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('aaedba5e', '@craft/commerce/web/assets/commercecp/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('ca91b2c', '@lib/fileupload');
INSERT INTO public.resourcepaths (hash, path) VALUES ('d973fb3c', '@craft/web/assets/plugins/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('4a5373dc', '@lib/xregexp');
INSERT INTO public.resourcepaths (hash, path) VALUES ('c4d700c3', '@craft/web/assets/feed/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('3c1ff93b', '@lib/fabric');
INSERT INTO public.resourcepaths (hash, path) VALUES ('a243b', '@lib/iframe-resizer');
INSERT INTO public.resourcepaths (hash, path) VALUES ('bbef0a0b', '@craft/commerce/web/assets/orderswidget/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('e398805c', '@craft/commerce/web/assets/statwidgets/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('6535071f', '@commerceLib/deepmerge');
INSERT INTO public.resourcepaths (hash, path) VALUES ('39998b3c', '@commerceLib');
INSERT INTO public.resourcepaths (hash, path) VALUES ('4f6b2262', '@craft/web/assets/pluginstore/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('35f4c803', '@craft/web/assets/admintable/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('62d489e0', '@craft/web/assets/recententries/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('fbc23d87', '@craft/web/assets/craftsupport/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('5c6ecb8e', '@craft/web/assets/updateswidget/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('bd942608', '@craft/web/assets/dashboard/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('8445795e', '@craft/web/assets/updates/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('f3c48a4a', '@craft/web/assets/login/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('55419fd5', '@craft/web/assets/generalsettings/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('e0f1a9b1', '@lib/vue');
INSERT INTO public.resourcepaths (hash, path) VALUES ('1ce22ad5', '@craft/web/assets/utilities/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('f1551a8b', '@craft/web/assets/dbbackup/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('f80c374f', '@modules/sitemodule/assetbundles/sitemodule/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('68e4803f', '/Users/michtio/dev/craft-plugins/craft-password-policy/src/assetbundles/PasswordPolicy/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('4610121f', '@craft/web/assets/cp/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('cd1a0ac4', '@lib/axios');
INSERT INTO public.resourcepaths (hash, path) VALUES ('11632c99', '@lib/prismjs');
INSERT INTO public.resourcepaths (hash, path) VALUES ('1ae43a83', '@lib/d3');
INSERT INTO public.resourcepaths (hash, path) VALUES ('b77b8da0', '@lib/element-resize-detector');
INSERT INTO public.resourcepaths (hash, path) VALUES ('29592d05', '@lib/garnishjs');
INSERT INTO public.resourcepaths (hash, path) VALUES ('98eb2655', '@bower/jquery/dist');


--
-- Data for Name: revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: searchindex; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (1, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (2, 'slug', 0, 1, ' homepage ', '''homepage''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (2, 'title', 0, 1, ' homepage ', '''homepage''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'username', 0, 1, ' development ', '''development''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'firstname', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'lastname', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'fullname', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'email', 0, 1, ' development percipio london ', '''development'' ''london'' ''percipio''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'slug', 0, 1, '', '');


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, NULL, 'Homepage', 'homepage', 'single', false, 'all', NULL, '2021-03-30 18:09:51', '2021-03-30 18:09:51', NULL, '54e60257-f31a-44aa-960e-bbd364197e28');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, NULL, 'Errors', 'errors', 'channel', false, 'all', NULL, '2021-03-30 18:09:51', '2021-03-30 18:09:51', '2021-03-30 18:23:11', 'a72bfe0c-3389-4f9f-8ec1-ab318ec10b29');


--
-- Data for Name: sections_sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (1, 1, 1, false, NULL, NULL, true, '2021-03-30 18:09:51', '2021-03-30 18:09:51', 'd6308a05-f186-4034-849b-feb4765224db');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (2, 2, 1, true, '__home__', 'index', true, '2021-03-30 18:09:51', '2021-03-30 18:09:51', 'f60ddbeb-b37c-4192-8425-c418f1e90786');


--
-- Data for Name: sequences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shunnedmessages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sitegroups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sitegroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, '$SITE_NAME', '2021-03-30 18:09:46', '2021-03-30 18:09:46', NULL, 'f89601e9-4ba9-4a48-9e99-350aa9914912');


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sites (id, "groupId", "primary", enabled, name, handle, language, "hasUrls", "baseUrl", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, true, true, '$SITE_NAME', 'default', 'en-GB', true, '$SITE_URL', 1, '2021-03-30 18:09:46', '2021-03-30 18:09:52', NULL, '5da841b1-ca0d-46ff-8bb1-04d6c889ac54');


--
-- Data for Name: structureelements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: structures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: systemmessages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: taggroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: usergroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: usergroups_users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpermissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpermissions_usergroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpermissions_users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpreferences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.userpreferences ("userId", preferences) VALUES (3, '{"language":"en-GB","locale":null,"weekStartDay":"1","useShapes":false,"underlineLinks":false,"showFieldHandles":false,"enableDebugToolbarForSite":false,"enableDebugToolbarForCp":false,"showExceptionView":false,"profileTemplates":false}');


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, username, "photoId", "firstName", "lastName", email, password, admin, locked, suspended, pending, "lastLoginDate", "lastLoginAttemptIp", "invalidLoginWindowStart", "invalidLoginCount", "lastInvalidLoginDate", "lockoutDate", "hasDashboard", "verificationCode", "verificationCodeIssuedDate", "unverifiedEmail", "passwordResetRequired", "lastPasswordChangeDate", "dateCreated", "dateUpdated", uid) VALUES (3, 'development', NULL, '', '', 'development@percipio.london', '$2y$13$Mzhw4kjISY8EFPegs90EuOYjn6rf1eYPrtUEBTnGZouS2GAI0yTwq', true, false, false, false, '2021-03-30 18:59:12', NULL, NULL, NULL, NULL, NULL, true, NULL, NULL, NULL, false, '2021-03-30 18:23:28', '2021-03-30 18:09:53', '2021-03-30 18:59:12', 'a6cdd8f8-5331-45df-8565-7e53eae8426f');


--
-- Data for Name: volumefolders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (1, NULL, 1, 'Site', '', '2021-03-30 18:09:51', '2021-03-30 18:09:51', '9b6b521a-6e63-41c3-9d8b-77e46252a935');
INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (2, NULL, NULL, 'Temporary source', NULL, '2021-03-30 18:26:56', '2021-03-30 18:26:56', '2a6085b0-0c01-42dc-8294-f52837817738');
INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (3, 2, NULL, 'user_3', 'user_3/', '2021-03-30 18:26:56', '2021-03-30 18:26:56', '1640d476-9b43-4348-8afc-53c4deb41aec');


--
-- Data for Name: volumes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.volumes (id, "fieldLayoutId", name, handle, type, "hasUrls", url, "titleTranslationMethod", "titleTranslationKeyFormat", settings, "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, 'Site', 'site', 'craft\volumes\Local', true, '@assetsUrl/assets/site', 'site', NULL, '{"path":"@webroot/assets/site"}', 1, '2021-03-30 18:09:51', '2021-03-30 18:09:51', NULL, '5c642d7e-b16b-4836-9575-668d75d242e5');


--
-- Data for Name: widgets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (1, 3, 'craft\widgets\RecentEntries', 1, NULL, '{"siteId":1,"section":"*","limit":10}', true, '2021-03-30 18:10:00', '2021-03-30 18:10:00', '54d5eb5e-8a21-48b2-9ad9-e845c48cf048');
INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (2, 3, 'craft\widgets\CraftSupport', 2, NULL, '[]', true, '2021-03-30 18:10:00', '2021-03-30 18:10:00', '69e2c589-5f2a-4c11-a880-e37704653381');
INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (3, 3, 'craft\widgets\Updates', 3, NULL, '[]', true, '2021-03-30 18:10:00', '2021-03-30 18:10:00', '91761430-746e-4e9c-b102-de23077918e6');
INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (4, 3, 'craft\widgets\Feed', 4, NULL, '{"url":"https://craftcms.com/news.rss","title":"Craft News","limit":5}', true, '2021-03-30 18:10:00', '2021-03-30 18:10:00', '255d9ad6-5ba3-4625-a964-ede2b9704f08');


--
-- Name: assetindexdata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assetindexdata_id_seq', 1, false);


--
-- Name: assettransformindex_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assettransformindex_id_seq', 1, false);


--
-- Name: assettransforms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assettransforms_id_seq', 1, false);


--
-- Name: categorygroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categorygroups_id_seq', 1, false);


--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categorygroups_sites_id_seq', 1, false);


--
-- Name: commerce_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_addresses_id_seq', 1, false);


--
-- Name: commerce_countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_countries_id_seq', 249, true);


--
-- Name: commerce_customer_discountuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_customer_discountuses_id_seq', 1, false);


--
-- Name: commerce_customers_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_customers_addresses_id_seq', 1, false);


--
-- Name: commerce_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_customers_id_seq', 1, true);


--
-- Name: commerce_discount_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_discount_categories_id_seq', 1, false);


--
-- Name: commerce_discount_purchasables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_discount_purchasables_id_seq', 1, false);


--
-- Name: commerce_discount_usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_discount_usergroups_id_seq', 1, false);


--
-- Name: commerce_discounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_discounts_id_seq', 1, false);


--
-- Name: commerce_donations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_donations_id_seq', 1, false);


--
-- Name: commerce_email_discountuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_email_discountuses_id_seq', 1, false);


--
-- Name: commerce_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_emails_id_seq', 1, false);


--
-- Name: commerce_gateways_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_gateways_id_seq', 1, true);


--
-- Name: commerce_lineitems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_lineitems_id_seq', 1, false);


--
-- Name: commerce_lineitemstatuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_lineitemstatuses_id_seq', 1, false);


--
-- Name: commerce_orderadjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_orderadjustments_id_seq', 1, false);


--
-- Name: commerce_orderhistories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_orderhistories_id_seq', 1, false);


--
-- Name: commerce_orderstatus_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_orderstatus_emails_id_seq', 1, false);


--
-- Name: commerce_orderstatuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_orderstatuses_id_seq', 1, true);


--
-- Name: commerce_paymentcurrencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_paymentcurrencies_id_seq', 1, true);


--
-- Name: commerce_paymentsources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_paymentsources_id_seq', 1, false);


--
-- Name: commerce_pdfs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_pdfs_id_seq', 1, false);


--
-- Name: commerce_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_plans_id_seq', 1, false);


--
-- Name: commerce_producttypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_producttypes_id_seq', 1, true);


--
-- Name: commerce_producttypes_shippingcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_producttypes_shippingcategories_id_seq', 1, false);


--
-- Name: commerce_producttypes_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_producttypes_sites_id_seq', 1, true);


--
-- Name: commerce_producttypes_taxcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_producttypes_taxcategories_id_seq', 1, false);


--
-- Name: commerce_purchasables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_purchasables_id_seq', 1, false);


--
-- Name: commerce_sale_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_sale_categories_id_seq', 1, false);


--
-- Name: commerce_sale_purchasables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_sale_purchasables_id_seq', 1, false);


--
-- Name: commerce_sale_usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_sale_usergroups_id_seq', 1, false);


--
-- Name: commerce_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_sales_id_seq', 1, false);


--
-- Name: commerce_shippingcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_shippingcategories_id_seq', 1, true);


--
-- Name: commerce_shippingmethods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_shippingmethods_id_seq', 1, true);


--
-- Name: commerce_shippingrule_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_shippingrule_categories_id_seq', 1, false);


--
-- Name: commerce_shippingrules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_shippingrules_id_seq', 1, true);


--
-- Name: commerce_shippingzone_countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_shippingzone_countries_id_seq', 1, false);


--
-- Name: commerce_shippingzone_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_shippingzone_states_id_seq', 1, false);


--
-- Name: commerce_shippingzones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_shippingzones_id_seq', 1, false);


--
-- Name: commerce_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_states_id_seq', 72, true);


--
-- Name: commerce_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_subscriptions_id_seq', 1, false);


--
-- Name: commerce_taxcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_taxcategories_id_seq', 1, true);


--
-- Name: commerce_taxrates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_taxrates_id_seq', 1, false);


--
-- Name: commerce_taxzone_countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_taxzone_countries_id_seq', 1, false);


--
-- Name: commerce_taxzone_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_taxzone_states_id_seq', 1, false);


--
-- Name: commerce_taxzones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_taxzones_id_seq', 1, false);


--
-- Name: commerce_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commerce_transactions_id_seq', 1, false);


--
-- Name: content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_id_seq', 2, true);


--
-- Name: craftidtokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.craftidtokens_id_seq', 1, false);


--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deprecationerrors_id_seq', 1, false);


--
-- Name: drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.drafts_id_seq', 1, false);


--
-- Name: elementindexsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.elementindexsettings_id_seq', 1, false);


--
-- Name: elements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.elements_id_seq', 3, true);


--
-- Name: elements_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.elements_sites_id_seq', 3, true);


--
-- Name: entrytypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.entrytypes_id_seq', 2, true);


--
-- Name: fieldgroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldgroups_id_seq', 2, true);


--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldlayoutfields_id_seq', 1, false);


--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldlayouts_id_seq', 3, true);


--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldlayouttabs_id_seq', 4, true);


--
-- Name: fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fields_id_seq', 3, true);


--
-- Name: globalsets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.globalsets_id_seq', 1, false);


--
-- Name: gqlschemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gqlschemas_id_seq', 1, true);


--
-- Name: gqltokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gqltokens_id_seq', 1, true);


--
-- Name: info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.info_id_seq', 1, false);


--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matrixblocktypes_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 325, true);


--
-- Name: notifications_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_notifications_id_seq', 1, false);


--
-- Name: plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plugins_id_seq', 8, true);


--
-- Name: queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.queue_id_seq', 7, true);


--
-- Name: relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.relations_id_seq', 1, false);


--
-- Name: revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.revisions_id_seq', 1, false);


--
-- Name: sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sections_id_seq', 2, true);


--
-- Name: sections_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sections_sites_id_seq', 2, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 5, true);


--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shunnedmessages_id_seq', 1, false);


--
-- Name: sitegroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sitegroups_id_seq', 1, true);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 1, true);


--
-- Name: structureelements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.structureelements_id_seq', 1, false);


--
-- Name: structures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.structures_id_seq', 1, false);


--
-- Name: systemmessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.systemmessages_id_seq', 1, false);


--
-- Name: taggroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggroups_id_seq', 1, false);


--
-- Name: templatecacheelements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templatecacheelements_id_seq', 1, false);


--
-- Name: templatecachequeries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templatecachequeries_id_seq', 1, false);


--
-- Name: templatecaches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templatecaches_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tokens_id_seq', 1, false);


--
-- Name: usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usergroups_id_seq', 1, false);


--
-- Name: usergroups_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usergroups_users_id_seq', 1, false);


--
-- Name: userpermissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.userpermissions_id_seq', 1, false);


--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.userpermissions_usergroups_id_seq', 1, false);


--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.userpermissions_users_id_seq', 1, false);


--
-- Name: userpreferences_userId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."userpreferences_userId_seq"', 1, false);


--
-- Name: volumefolders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.volumefolders_id_seq', 3, true);


--
-- Name: volumes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.volumes_id_seq', 1, true);


--
-- Name: widgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.widgets_id_seq', 4, true);


--
-- Name: assetindexdata assetindexdata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assetindexdata
    ADD CONSTRAINT assetindexdata_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: assettransformindex assettransformindex_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransformindex
    ADD CONSTRAINT assettransformindex_pkey PRIMARY KEY (id);


--
-- Name: assettransforms assettransforms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransforms
    ADD CONSTRAINT assettransforms_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categorygroups categorygroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT categorygroups_pkey PRIMARY KEY (id);


--
-- Name: categorygroups_sites categorygroups_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT categorygroups_sites_pkey PRIMARY KEY (id);


--
-- Name: changedattributes changedattributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT changedattributes_pkey PRIMARY KEY ("elementId", "siteId", attribute);


--
-- Name: changedfields changedfields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT changedfields_pkey PRIMARY KEY ("elementId", "siteId", "fieldId");


--
-- Name: commerce_addresses commerce_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_addresses
    ADD CONSTRAINT commerce_addresses_pkey PRIMARY KEY (id);


--
-- Name: commerce_countries commerce_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_countries
    ADD CONSTRAINT commerce_countries_pkey PRIMARY KEY (id);


--
-- Name: commerce_customer_discountuses commerce_customer_discountuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customer_discountuses
    ADD CONSTRAINT commerce_customer_discountuses_pkey PRIMARY KEY (id);


--
-- Name: commerce_customers_addresses commerce_customers_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers_addresses
    ADD CONSTRAINT commerce_customers_addresses_pkey PRIMARY KEY (id);


--
-- Name: commerce_customers commerce_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers
    ADD CONSTRAINT commerce_customers_pkey PRIMARY KEY (id);


--
-- Name: commerce_discount_categories commerce_discount_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_categories
    ADD CONSTRAINT commerce_discount_categories_pkey PRIMARY KEY (id);


--
-- Name: commerce_discount_purchasables commerce_discount_purchasables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_purchasables
    ADD CONSTRAINT commerce_discount_purchasables_pkey PRIMARY KEY (id);


--
-- Name: commerce_discount_usergroups commerce_discount_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_usergroups
    ADD CONSTRAINT commerce_discount_usergroups_pkey PRIMARY KEY (id);


--
-- Name: commerce_discounts commerce_discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discounts
    ADD CONSTRAINT commerce_discounts_pkey PRIMARY KEY (id);


--
-- Name: commerce_donations commerce_donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_donations
    ADD CONSTRAINT commerce_donations_pkey PRIMARY KEY (id);


--
-- Name: commerce_email_discountuses commerce_email_discountuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_email_discountuses
    ADD CONSTRAINT commerce_email_discountuses_pkey PRIMARY KEY (id);


--
-- Name: commerce_emails commerce_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_emails
    ADD CONSTRAINT commerce_emails_pkey PRIMARY KEY (id);


--
-- Name: commerce_gateways commerce_gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_gateways
    ADD CONSTRAINT commerce_gateways_pkey PRIMARY KEY (id);


--
-- Name: commerce_lineitems commerce_lineitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitems
    ADD CONSTRAINT commerce_lineitems_pkey PRIMARY KEY (id);


--
-- Name: commerce_lineitemstatuses commerce_lineitemstatuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitemstatuses
    ADD CONSTRAINT commerce_lineitemstatuses_pkey PRIMARY KEY (id);


--
-- Name: commerce_orderadjustments commerce_orderadjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderadjustments
    ADD CONSTRAINT commerce_orderadjustments_pkey PRIMARY KEY (id);


--
-- Name: commerce_orderhistories commerce_orderhistories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderhistories
    ADD CONSTRAINT commerce_orderhistories_pkey PRIMARY KEY (id);


--
-- Name: commerce_orders commerce_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT commerce_orders_pkey PRIMARY KEY (id);


--
-- Name: commerce_orderstatus_emails commerce_orderstatus_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderstatus_emails
    ADD CONSTRAINT commerce_orderstatus_emails_pkey PRIMARY KEY (id);


--
-- Name: commerce_orderstatuses commerce_orderstatuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderstatuses
    ADD CONSTRAINT commerce_orderstatuses_pkey PRIMARY KEY (id);


--
-- Name: commerce_paymentcurrencies commerce_paymentcurrencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_paymentcurrencies
    ADD CONSTRAINT commerce_paymentcurrencies_pkey PRIMARY KEY (id);


--
-- Name: commerce_paymentsources commerce_paymentsources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_paymentsources
    ADD CONSTRAINT commerce_paymentsources_pkey PRIMARY KEY (id);


--
-- Name: commerce_pdfs commerce_pdfs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_pdfs
    ADD CONSTRAINT commerce_pdfs_pkey PRIMARY KEY (id);


--
-- Name: commerce_plans commerce_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_plans
    ADD CONSTRAINT commerce_plans_pkey PRIMARY KEY (id);


--
-- Name: commerce_products commerce_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_products
    ADD CONSTRAINT commerce_products_pkey PRIMARY KEY (id);


--
-- Name: commerce_producttypes commerce_producttypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes
    ADD CONSTRAINT commerce_producttypes_pkey PRIMARY KEY (id);


--
-- Name: commerce_producttypes_shippingcategories commerce_producttypes_shippingcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_shippingcategories
    ADD CONSTRAINT commerce_producttypes_shippingcategories_pkey PRIMARY KEY (id);


--
-- Name: commerce_producttypes_sites commerce_producttypes_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_sites
    ADD CONSTRAINT commerce_producttypes_sites_pkey PRIMARY KEY (id);


--
-- Name: commerce_producttypes_taxcategories commerce_producttypes_taxcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_taxcategories
    ADD CONSTRAINT commerce_producttypes_taxcategories_pkey PRIMARY KEY (id);


--
-- Name: commerce_purchasables commerce_purchasables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_purchasables
    ADD CONSTRAINT commerce_purchasables_pkey PRIMARY KEY (id);


--
-- Name: commerce_sale_categories commerce_sale_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_categories
    ADD CONSTRAINT commerce_sale_categories_pkey PRIMARY KEY (id);


--
-- Name: commerce_sale_purchasables commerce_sale_purchasables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_purchasables
    ADD CONSTRAINT commerce_sale_purchasables_pkey PRIMARY KEY (id);


--
-- Name: commerce_sale_usergroups commerce_sale_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_usergroups
    ADD CONSTRAINT commerce_sale_usergroups_pkey PRIMARY KEY (id);


--
-- Name: commerce_sales commerce_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sales
    ADD CONSTRAINT commerce_sales_pkey PRIMARY KEY (id);


--
-- Name: commerce_shippingcategories commerce_shippingcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingcategories
    ADD CONSTRAINT commerce_shippingcategories_pkey PRIMARY KEY (id);


--
-- Name: commerce_shippingmethods commerce_shippingmethods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingmethods
    ADD CONSTRAINT commerce_shippingmethods_pkey PRIMARY KEY (id);


--
-- Name: commerce_shippingrule_categories commerce_shippingrule_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrule_categories
    ADD CONSTRAINT commerce_shippingrule_categories_pkey PRIMARY KEY (id);


--
-- Name: commerce_shippingrules commerce_shippingrules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrules
    ADD CONSTRAINT commerce_shippingrules_pkey PRIMARY KEY (id);


--
-- Name: commerce_shippingzone_countries commerce_shippingzone_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_countries
    ADD CONSTRAINT commerce_shippingzone_countries_pkey PRIMARY KEY (id);


--
-- Name: commerce_shippingzone_states commerce_shippingzone_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_states
    ADD CONSTRAINT commerce_shippingzone_states_pkey PRIMARY KEY (id);


--
-- Name: commerce_shippingzones commerce_shippingzones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzones
    ADD CONSTRAINT commerce_shippingzones_pkey PRIMARY KEY (id);


--
-- Name: commerce_states commerce_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_states
    ADD CONSTRAINT commerce_states_pkey PRIMARY KEY (id);


--
-- Name: commerce_subscriptions commerce_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_subscriptions
    ADD CONSTRAINT commerce_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: commerce_taxcategories commerce_taxcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxcategories
    ADD CONSTRAINT commerce_taxcategories_pkey PRIMARY KEY (id);


--
-- Name: commerce_taxrates commerce_taxrates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxrates
    ADD CONSTRAINT commerce_taxrates_pkey PRIMARY KEY (id);


--
-- Name: commerce_taxzone_countries commerce_taxzone_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_countries
    ADD CONSTRAINT commerce_taxzone_countries_pkey PRIMARY KEY (id);


--
-- Name: commerce_taxzone_states commerce_taxzone_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_states
    ADD CONSTRAINT commerce_taxzone_states_pkey PRIMARY KEY (id);


--
-- Name: commerce_taxzones commerce_taxzones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzones
    ADD CONSTRAINT commerce_taxzones_pkey PRIMARY KEY (id);


--
-- Name: commerce_transactions commerce_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_transactions
    ADD CONSTRAINT commerce_transactions_pkey PRIMARY KEY (id);


--
-- Name: commerce_variants commerce_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_variants
    ADD CONSTRAINT commerce_variants_pkey PRIMARY KEY (id);


--
-- Name: content content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT content_pkey PRIMARY KEY (id);


--
-- Name: craftidtokens craftidtokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.craftidtokens
    ADD CONSTRAINT craftidtokens_pkey PRIMARY KEY (id);


--
-- Name: deprecationerrors deprecationerrors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deprecationerrors
    ADD CONSTRAINT deprecationerrors_pkey PRIMARY KEY (id);


--
-- Name: drafts drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT drafts_pkey PRIMARY KEY (id);


--
-- Name: elementindexsettings elementindexsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elementindexsettings
    ADD CONSTRAINT elementindexsettings_pkey PRIMARY KEY (id);


--
-- Name: elements elements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_pkey PRIMARY KEY (id);


--
-- Name: elements_sites elements_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT elements_sites_pkey PRIMARY KEY (id);


--
-- Name: entries entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (id);


--
-- Name: entrytypes entrytypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT entrytypes_pkey PRIMARY KEY (id);


--
-- Name: fieldgroups fieldgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldgroups
    ADD CONSTRAINT fieldgroups_pkey PRIMARY KEY (id);


--
-- Name: fieldlayoutfields fieldlayoutfields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fieldlayoutfields_pkey PRIMARY KEY (id);


--
-- Name: fieldlayouts fieldlayouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouts
    ADD CONSTRAINT fieldlayouts_pkey PRIMARY KEY (id);


--
-- Name: fieldlayouttabs fieldlayouttabs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouttabs
    ADD CONSTRAINT fieldlayouttabs_pkey PRIMARY KEY (id);


--
-- Name: fields fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fields_pkey PRIMARY KEY (id);


--
-- Name: globalsets globalsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT globalsets_pkey PRIMARY KEY (id);


--
-- Name: gqlschemas gqlschemas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqlschemas
    ADD CONSTRAINT gqlschemas_pkey PRIMARY KEY (id);


--
-- Name: gqltokens gqltokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqltokens
    ADD CONSTRAINT gqltokens_pkey PRIMARY KEY (id);


--
-- Name: info info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.info
    ADD CONSTRAINT info_pkey PRIMARY KEY (id);


--
-- Name: matrixblocks matrixblocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT matrixblocks_pkey PRIMARY KEY (id);


--
-- Name: matrixblocktypes matrixblocktypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT matrixblocktypes_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: notifications_notifications notifications_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications_notifications
    ADD CONSTRAINT notifications_notifications_pkey PRIMARY KEY (id);


--
-- Name: searchindex pk_nxjbljpgwgkvuinqitxqcynjgdqjpihktzkd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.searchindex
    ADD CONSTRAINT pk_nxjbljpgwgkvuinqitxqcynjgdqjpihktzkd PRIMARY KEY ("elementId", attribute, "fieldId", "siteId");


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: projectconfig projectconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projectconfig
    ADD CONSTRAINT projectconfig_pkey PRIMARY KEY (path);


--
-- Name: projectconfignames projectconfignames_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projectconfignames
    ADD CONSTRAINT projectconfignames_pkey PRIMARY KEY (uid);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (id);


--
-- Name: relations relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT relations_pkey PRIMARY KEY (id);


--
-- Name: resourcepaths resourcepaths_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resourcepaths
    ADD CONSTRAINT resourcepaths_pkey PRIMARY KEY (hash);


--
-- Name: revisions revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT revisions_pkey PRIMARY KEY (id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: sections_sites sections_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT sections_sites_pkey PRIMARY KEY (id);


--
-- Name: sequences sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_pkey PRIMARY KEY (name);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shunnedmessages shunnedmessages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shunnedmessages
    ADD CONSTRAINT shunnedmessages_pkey PRIMARY KEY (id);


--
-- Name: sitegroups sitegroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sitegroups
    ADD CONSTRAINT sitegroups_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: structureelements structureelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT structureelements_pkey PRIMARY KEY (id);


--
-- Name: structures structures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structures
    ADD CONSTRAINT structures_pkey PRIMARY KEY (id);


--
-- Name: systemmessages systemmessages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemmessages
    ADD CONSTRAINT systemmessages_pkey PRIMARY KEY (id);


--
-- Name: taggroups taggroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggroups
    ADD CONSTRAINT taggroups_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: templatecacheelements templatecacheelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements
    ADD CONSTRAINT templatecacheelements_pkey PRIMARY KEY (id);


--
-- Name: templatecachequeries templatecachequeries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecachequeries
    ADD CONSTRAINT templatecachequeries_pkey PRIMARY KEY (id);


--
-- Name: templatecaches templatecaches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecaches
    ADD CONSTRAINT templatecaches_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: usergroups usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups
    ADD CONSTRAINT usergroups_pkey PRIMARY KEY (id);


--
-- Name: usergroups_users usergroups_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT usergroups_users_pkey PRIMARY KEY (id);


--
-- Name: userpermissions userpermissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions
    ADD CONSTRAINT userpermissions_pkey PRIMARY KEY (id);


--
-- Name: userpermissions_usergroups userpermissions_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT userpermissions_usergroups_pkey PRIMARY KEY (id);


--
-- Name: userpermissions_users userpermissions_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT userpermissions_users_pkey PRIMARY KEY (id);


--
-- Name: userpreferences userpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpreferences
    ADD CONSTRAINT userpreferences_pkey PRIMARY KEY ("userId");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: volumefolders volumefolders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT volumefolders_pkey PRIMARY KEY (id);


--
-- Name: volumes volumes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumes
    ADD CONSTRAINT volumes_pkey PRIMARY KEY (id);


--
-- Name: widgets widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT widgets_pkey PRIMARY KEY (id);


--
-- Name: idx_aabsxshiywozgoavvraythyvxdselmxpecyz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aabsxshiywozgoavvraythyvxdselmxpecyz ON public.commerce_orders USING btree ("orderStatusId");


--
-- Name: idx_acqhkfbibulwakypskmpwanmediqepskxlkk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_acqhkfbibulwakypskmpwanmediqepskxlkk ON public.commerce_orders USING btree (number);


--
-- Name: idx_adsyevclxnyewfrqevrntxljwmuxyslhlcmd; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_adsyevclxnyewfrqevrntxljwmuxyslhlcmd ON public.plugins USING btree (handle);


--
-- Name: idx_afongotwoenepoggkeojrvvhihjuspdwiaja; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_afongotwoenepoggkeojrvvhihjuspdwiaja ON public.commerce_sale_usergroups USING btree ("saleId", "userGroupId");


--
-- Name: idx_aggskbgctifsiylwjgkctoaoiowshawetwtj; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_aggskbgctifsiylwjgkctoaoiowshawetwtj ON public.commerce_taxzones USING btree (name);


--
-- Name: idx_aludtlfzbgxmnwyfffemehjnzxjcvdwryzvh; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_aludtlfzbgxmnwyfffemehjnzxjcvdwryzvh ON public.shunnedmessages USING btree ("userId", message);


--
-- Name: idx_amjtnbpohdxvmcqozqejeivgrrniypmfbjlr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_amjtnbpohdxvmcqozqejeivgrrniypmfbjlr ON public.commerce_discounts USING btree ("dateTo");


--
-- Name: idx_aoclkzaieatbucfoqdhnzwhmirmavhwuctno; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aoclkzaieatbucfoqdhnzwhmirmavhwuctno ON public.assettransforms USING btree (handle);


--
-- Name: idx_aoooznzrxigjjspaxajuqvbbccrhmtbkyhfv; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_aoooznzrxigjjspaxajuqvbbccrhmtbkyhfv ON public.gqltokens USING btree ("accessToken");


--
-- Name: idx_apbdcesmcamgqkapdizvjtxkwddimmkcvxrv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_apbdcesmcamgqkapdizvjtxkwddimmkcvxrv ON public.fieldlayouttabs USING btree ("layoutId");


--
-- Name: idx_aqabkfbbvcwnbjyujmlrfjpfwogemdppvqem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aqabkfbbvcwnbjyujmlrfjpfwogemdppvqem ON public.sites USING btree (handle);


--
-- Name: idx_auwpxixtkbdsxgkbvhrggorivycioncuwtma; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auwpxixtkbdsxgkbvhrggorivycioncuwtma ON public.commerce_variants USING btree ("productId");


--
-- Name: idx_avxbfrpkcxjafbxrppggvjwdkcrkulqungez; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_avxbfrpkcxjafbxrppggvjwdkcrkulqungez ON public.commerce_sale_usergroups USING btree ("userGroupId");


--
-- Name: idx_awuqaezdjmyivyfyjziywfrbjljoizhhqvun; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_awuqaezdjmyivyfyjziywfrbjljoizhhqvun ON public.commerce_orders USING btree (reference);


--
-- Name: idx_azvvrqrsyeuhwioovzwrliiffxqysragxgtm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_azvvrqrsyeuhwioovzwrliiffxqysragxgtm ON public.relations USING btree ("targetId");


--
-- Name: idx_bcdcqozykeyarwvsjzwoekfxujofpnxanlge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bcdcqozykeyarwvsjzwoekfxujofpnxanlge ON public.commerce_subscriptions USING btree ("dateCreated");


--
-- Name: idx_bcfctmvdawlqsiiqjimdxbvdecppuoiiqzou; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_bcfctmvdawlqsiiqjimdxbvdecppuoiiqzou ON public.commerce_sale_purchasables USING btree ("saleId", "purchasableId");


--
-- Name: idx_bdpfnkkucqunuohfadtvtdupvrwilmmeisyi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bdpfnkkucqunuohfadtvtdupvrwilmmeisyi ON public.sections USING btree (name);


--
-- Name: idx_bdqiqnmyrlyhrixgvgtnkmazbtmttfaluohf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bdqiqnmyrlyhrixgvgtnkmazbtmttfaluohf ON public.commerce_sale_categories USING btree ("categoryId");


--
-- Name: idx_bkgtovdafkhcjgegpfzrhsrqpmbksorfmgiw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bkgtovdafkhcjgegpfzrhsrqpmbksorfmgiw ON public.elements USING btree ("dateDeleted");


--
-- Name: idx_bkzyylmcwunyonorbikalxxkblatstdjfcmf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bkzyylmcwunyonorbikalxxkblatstdjfcmf ON public.globalsets USING btree (handle);


--
-- Name: idx_blmioumkoagclgtsxyjjcqeyavclclczvuwh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_blmioumkoagclgtsxyjjcqeyavclclczvuwh ON public.commerce_orderstatus_emails USING btree ("emailId");


--
-- Name: idx_bntiwezkugulxobukfdqelxgxlgikvpauruz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bntiwezkugulxobukfdqelxgxlgikvpauruz ON public.users USING btree (lower((email)::text));


--
-- Name: idx_bodxekujufzztqjkzlmbnkajzizeoraihaob; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bodxekujufzztqjkzlmbnkajzizeoraihaob ON public.commerce_products USING btree ("expiryDate");


--
-- Name: idx_buplrzgemhtnnrkjpqpsizfadnyypgkydboi; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_buplrzgemhtnnrkjpqpsizfadnyypgkydboi ON public.commerce_subscriptions USING btree (reference);


--
-- Name: idx_bwrkvswpwwjzjlknczplosnserfkfwiekzcu; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_bwrkvswpwwjzjlknczplosnserfkfwiekzcu ON public.commerce_discount_purchasables USING btree ("discountId", "purchasableId");


--
-- Name: idx_bxpwflgksyljzgrmtooinedycufusxcgtuho; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bxpwflgksyljzgrmtooinedycufusxcgtuho ON public.users USING btree (uid);


--
-- Name: idx_cazhhwuzsvhvzrwjxihccdyonjqqzhnbjbpv; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cazhhwuzsvhvzrwjxihccdyonjqqzhnbjbpv ON public.commerce_discount_categories USING btree ("discountId", "categoryId");


--
-- Name: idx_cbccyolqrulukoulrwudkirhnocfytifkzre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cbccyolqrulukoulrwudkirhnocfytifkzre ON public.assets USING btree ("folderId");


--
-- Name: idx_cgpaoxnyrpxlkctdpzxbhxkgozdmibybgwtr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cgpaoxnyrpxlkctdpzxbhxkgozdmibybgwtr ON public.queue USING btree (channel, fail, "timeUpdated", delay);


--
-- Name: idx_cjedtyuwhamicbaczsdgcvobrzjpuatmeyxp; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cjedtyuwhamicbaczsdgcvobrzjpuatmeyxp ON public.revisions USING btree ("sourceId", num);


--
-- Name: idx_cjmafclqklslphsvetcqyydijamnmizlrnwl; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cjmafclqklslphsvetcqyydijamnmizlrnwl ON public.commerce_customer_discountuses USING btree ("customerId", "discountId");


--
-- Name: idx_clpvdyxflkqdiaahkcwglfrentgyqlkincys; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clpvdyxflkqdiaahkcwglfrentgyqlkincys ON public.assettransforms USING btree (name);


--
-- Name: idx_cnatsyyuqicuvppghulkjizkidxqsgvzgrqh; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cnatsyyuqicuvppghulkjizkidxqsgvzgrqh ON public.commerce_discount_usergroups USING btree ("discountId", "userGroupId");


--
-- Name: idx_cpbbimgzffjjgwiyjeblhlpaymxvxbrdunig; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cpbbimgzffjjgwiyjeblhlpaymxvxbrdunig ON public.assetindexdata USING btree ("volumeId");


--
-- Name: idx_cpdvbuhjcbtfdjhlgkujgynfoekjkxfzbyvw; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cpdvbuhjcbtfdjhlgkujgynfoekjkxfzbyvw ON public.commerce_producttypes_shippingcategories USING btree ("productTypeId", "shippingCategoryId");


--
-- Name: idx_cqtitetydkfybjlepdetqqnrbjyhsaspqhuw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cqtitetydkfybjlepdetqqnrbjyhsaspqhuw ON public.commerce_orderhistories USING btree ("newStatusId");


--
-- Name: idx_criilhtrpmwctmkduvxobvfuxnonpbouycpu; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_criilhtrpmwctmkduvxobvfuxnonpbouycpu ON public.commerce_shippingzones USING btree (name);


--
-- Name: idx_crkixispsnxwuaukbnfokrlsklzwkvbsudws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crkixispsnxwuaukbnfokrlsklzwkvbsudws ON public.categorygroups USING btree (name);


--
-- Name: idx_crszhxfxihvkyoawvwtjmepghtsehxcmkitn; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_crszhxfxihvkyoawvwtjmepghtsehxcmkitn ON public.content USING btree ("elementId", "siteId");


--
-- Name: idx_crwemskghxjpeeudrfjbtctnrqaybzgirtwm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crwemskghxjpeeudrfjbtctnrqaybzgirtwm ON public.relations USING btree ("sourceId");


--
-- Name: idx_cscesuhvnsiiisfgljzggdcebcyywwjizxzo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cscesuhvnsiiisfgljzggdcebcyywwjizxzo ON public.commerce_taxzone_countries USING btree ("countryId");


--
-- Name: idx_cvbiarrbmgvzxzczaoylyaxnnznoeoerfqcs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cvbiarrbmgvzxzczaoylyaxnnznoeoerfqcs ON public.globalsets USING btree (name);


--
-- Name: idx_dcfcjckntfxvhhgwuhljqxomknrzaqkfckqp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dcfcjckntfxvhhgwuhljqxomknrzaqkfckqp ON public.elements USING btree (archived, "dateDeleted", "draftId", "revisionId");


--
-- Name: idx_demeweycgmroyzgcxtsfrlgahiaisdqwedbo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_demeweycgmroyzgcxtsfrlgahiaisdqwedbo ON public.commerce_shippingzone_countries USING btree ("countryId");


--
-- Name: idx_dhxltwilxngmcmlyfjxlaipbeftfzmgkwnwq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dhxltwilxngmcmlyfjxlaipbeftfzmgkwnwq ON public.matrixblocktypes USING btree ("fieldLayoutId");


--
-- Name: idx_dijgtktifyfoqykytovyicuecrohzdqumqhj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dijgtktifyfoqykytovyicuecrohzdqumqhj ON public.structures USING btree ("dateDeleted");


--
-- Name: idx_dqaskhnhcuynmihnklxwldebuzypnfdrafgv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dqaskhnhcuynmihnklxwldebuzypnfdrafgv ON public.taggroups USING btree ("dateDeleted");


--
-- Name: idx_drjqaggvukzgfvziyqgaaejmtcomhgeugamh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drjqaggvukzgfvziyqgaaejmtcomhgeugamh ON public.templatecachequeries USING btree ("cacheId");


--
-- Name: idx_dxqpptxjuiocdcvvwphzzlcffrrlilhcjitk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dxqpptxjuiocdcvvwphzzlcffrrlilhcjitk ON public.categories USING btree ("groupId");


--
-- Name: idx_ednuoljyujvirbhemwmkjtrjvdgbqsmjaoey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ednuoljyujvirbhemwmkjtrjvdgbqsmjaoey ON public.sections_sites USING btree ("siteId");


--
-- Name: idx_efztwmtejjhenjtdcwthujqlbxubnkvgvekm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_efztwmtejjhenjtdcwthujqlbxubnkvgvekm ON public.templatecacheelements USING btree ("cacheId");


--
-- Name: idx_egqftctiqgraqvswoqtrjoszaczsmwjdabxi; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_egqftctiqgraqvswoqtrjoszaczsmwjdabxi ON public.commerce_discounts USING btree (code);


--
-- Name: idx_ehgaapnmsuikyesmitntjuryejesrtbzjthm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ehgaapnmsuikyesmitntjuryejesrtbzjthm ON public.commerce_orders USING btree ("billingAddressId");


--
-- Name: idx_eivuntwvbmlkbhrqkieazmenggxbpsfvwjut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eivuntwvbmlkbhrqkieazmenggxbpsfvwjut ON public.sessions USING btree ("userId");


--
-- Name: idx_ekrxmwhslbfodecygunefzshrneiwqizubna; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ekrxmwhslbfodecygunefzshrneiwqizubna ON public.searchindex USING btree (keywords);


--
-- Name: idx_eseawstpsdvneykakvktlndabhvxxsfjqfvp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eseawstpsdvneykakvktlndabhvxxsfjqfvp ON public.fields USING btree ("groupId");


--
-- Name: idx_etuvyakpgajnsyjqprhcfuuvrbvwvqbiecsd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_etuvyakpgajnsyjqprhcfuuvrbvwvqbiecsd ON public.matrixblocks USING btree ("sortOrder");


--
-- Name: idx_eyzrepscwmvwxakxvqbhyvmoatsncsbrlrrq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eyzrepscwmvwxakxvqbhyvmoatsncsbrlrrq ON public.commerce_shippingzone_countries USING btree ("shippingZoneId");


--
-- Name: idx_fclqivugdrgyiyesmdmyvpzfsikoddapdjua; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fclqivugdrgyiyesmdmyvpzfsikoddapdjua ON public.entrytypes USING btree ("dateDeleted");


--
-- Name: idx_fdjqmdvnxkmiyqovhsonfkmxlbgsjwntfkok; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_fdjqmdvnxkmiyqovhsonfkmxlbgsjwntfkok ON public.commerce_countries USING btree (iso);


--
-- Name: idx_fdmdmzzajetxvuqlsqwtipefhlijcucywbcp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fdmdmzzajetxvuqlsqwtipefhlijcucywbcp ON public.entries USING btree ("postDate");


--
-- Name: idx_fgvzwfhauolbvjytfnvblzlgaeswsqusmchq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fgvzwfhauolbvjytfnvblzlgaeswsqusmchq ON public.commerce_orderstatus_emails USING btree ("orderStatusId");


--
-- Name: idx_fiotqomhfcfsoninveiwcfymynkuqykudnje; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fiotqomhfcfsoninveiwcfymynkuqykudnje ON public.usergroups USING btree (handle);


--
-- Name: idx_fjqlropkplcobfqkditsathkbrqvmbrgrvxp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fjqlropkplcobfqkditsathkbrqvmbrgrvxp ON public.entrytypes USING btree (handle, "sectionId");


--
-- Name: idx_fmbaokhngmmxhuuwgpbphnmcjowffwxkdsxn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fmbaokhngmmxhuuwgpbphnmcjowffwxkdsxn ON public.taggroups USING btree (name);


--
-- Name: idx_fmqfsuuigjqjudspsmzptxvbacyffpsxylxp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fmqfsuuigjqjudspsmzptxvbacyffpsxylxp ON public.commerce_addresses USING btree ("countryId");


--
-- Name: idx_fqemlkinixvocbduvasrclnrnkbahybwptys; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fqemlkinixvocbduvasrclnrnkbahybwptys ON public.commerce_subscriptions USING btree ("gatewayId");


--
-- Name: idx_fqyjgsrwmupaefcatotxuzuoebecnwblfryy; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_fqyjgsrwmupaefcatotxuzuoebecnwblfryy ON public.migrations USING btree (track, name);


--
-- Name: idx_frcpssdmjtoyxjvxsskysqzhzclxkntfxeqs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frcpssdmjtoyxjvxsskysqzhzclxkntfxeqs ON public.assetindexdata USING btree ("sessionId", "volumeId");


--
-- Name: idx_fyylavqtazchlpyjwachyvywtxfwggruwdsf; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_fyylavqtazchlpyjwachyvywtxfwggruwdsf ON public.commerce_lineitems USING btree ("orderId", "purchasableId", "optionsSignature");


--
-- Name: idx_gesxbragfdvugtymufinedkyodksjyahlbrt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gesxbragfdvugtymufinedkyodksjyahlbrt ON public.matrixblocktypes USING btree (handle, "fieldId");


--
-- Name: idx_gfabkpfjicfujzlhphyuskujepossskmdrxl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gfabkpfjicfujzlhphyuskujepossskmdrxl ON public.fieldlayouts USING btree ("dateDeleted");


--
-- Name: idx_ggbfqidqtoesxfgxikdhbpnrrvyiadxcynba; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ggbfqidqtoesxfgxikdhbpnrrvyiadxcynba ON public.commerce_plans USING btree ("gatewayId");


--
-- Name: idx_ggbvrxhmkotirxfmhnrcgmmvhtsjedwoytxt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ggbvrxhmkotirxfmhnrcgmmvhtsjedwoytxt ON public.commerce_lineitems USING btree ("taxCategoryId");


--
-- Name: idx_glraadhhdzxhdyhsxnalibezueqlaqxvbpvr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_glraadhhdzxhdyhsxnalibezueqlaqxvbpvr ON public.commerce_orders USING btree ("gatewayId");


--
-- Name: idx_gvkerckmoeffgjixtjhkkxddrbvbaphjbynk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gvkerckmoeffgjixtjhkkxddrbvbaphjbynk ON public.commerce_transactions USING btree ("userId");


--
-- Name: idx_gvoeatxhwrpipbwoyhyqmxpftjyzkhintlxo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gvoeatxhwrpipbwoyhyqmxpftjyzkhintlxo ON public.commerce_shippingrules USING btree ("methodId");


--
-- Name: idx_hcdqcjreuosatyjfeibrowtelvzdektrtjsg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hcdqcjreuosatyjfeibrowtelvzdektrtjsg ON public.categorygroups USING btree ("fieldLayoutId");


--
-- Name: idx_hhluumemidkzntavspsmcmgxgzakruirbqvl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hhluumemidkzntavspsmcmgxgzakruirbqvl ON public.widgets USING btree ("userId");


--
-- Name: idx_hijydsrtjpittnijhicmhlsiojoudvzlsedw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hijydsrtjpittnijhicmhlsiojoudvzlsedw ON public.commerce_shippingrules USING btree (name);


--
-- Name: idx_hlqzlzacntpfxdswhqsuekjjnsnjmylijxjj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hlqzlzacntpfxdswhqsuekjjnsnjmylijxjj ON public.entries USING btree ("typeId");


--
-- Name: idx_hlxdkszaodskubpgrzaiyxngjecvjgrkapas; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hlxdkszaodskubpgrzaiyxngjecvjgrkapas ON public.sites USING btree ("sortOrder");


--
-- Name: idx_hndorsrwqpvexmphmzvrcdhcpvfambrxmcbx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hndorsrwqpvexmphmzvrcdhcpvfambrxmcbx ON public.commerce_producttypes USING btree ("fieldLayoutId");


--
-- Name: idx_hvcuhaxzcevtghzhbkrhrhlfhxxvoglvwsez; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hvcuhaxzcevtghzhbkrhrhlfhxxvoglvwsez ON public.commerce_variants USING btree (sku);


--
-- Name: idx_hwzuvvauuejacoidpwbmdnvveqxykffqwbcr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hwzuvvauuejacoidpwbmdnvveqxykffqwbcr ON public.tags USING btree ("groupId");


--
-- Name: idx_iaocgizstkkzhwxxhinmnxbbacluktwiugmh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iaocgizstkkzhwxxhinmnxbbacluktwiugmh ON public.commerce_taxzone_states USING btree ("stateId");


--
-- Name: idx_igrfbgetyiqtfwhbkykssmcttytajwiohpan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_igrfbgetyiqtfwhbkykssmcttytajwiohpan ON public.commerce_customers USING btree ("userId");


--
-- Name: idx_ikvznhtlepdlemnamwxrlazkqwvszgrxdmtn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ikvznhtlepdlemnamwxrlazkqwvszgrxdmtn ON public.commerce_shippingrule_categories USING btree ("shippingCategoryId");


--
-- Name: idx_iljogqqmsgysdecymqlhlhjwtwvnqheyxyfe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iljogqqmsgysdecymqlhlhjwtwvnqheyxyfe ON public.entrytypes USING btree ("fieldLayoutId");


--
-- Name: idx_iniucavfkrtpaumfkagzfplejnuchsrjnouc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iniucavfkrtpaumfkagzfplejnuchsrjnouc ON public.fieldgroups USING btree ("dateDeleted", name);


--
-- Name: idx_itydklpssxkmrbnbpcjkvsbcsejprkcvwtlf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_itydklpssxkmrbnbpcjkvsbcsejprkcvwtlf ON public.changedattributes USING btree ("elementId", "siteId", "dateUpdated");


--
-- Name: idx_jctialjqobquviojlyfwthyjfazghqdnbnzl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jctialjqobquviojlyfwthyjfazghqdnbnzl ON public.fieldlayouts USING btree (type);


--
-- Name: idx_jefzljnhmlexodbngwznytsadsdqzpaayxeh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jefzljnhmlexodbngwznytsadsdqzpaayxeh ON public.sessions USING btree (uid);


--
-- Name: idx_jfdjbwksbzjluopyuhyhmdkueugalcyucxkt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jfdjbwksbzjluopyuhyhmdkueugalcyucxkt ON public.commerce_customers USING btree ("primaryShippingAddressId");


--
-- Name: idx_jgnracwztijwqegxtsfvxpolotxrcfbaftem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jgnracwztijwqegxtsfvxpolotxrcfbaftem ON public.commerce_orders USING btree (email);


--
-- Name: idx_jitalolaoaydplakhaitkaqichsptcznibiz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jitalolaoaydplakhaitkaqichsptcznibiz ON public.fields USING btree (handle, context);


--
-- Name: idx_juciovhxwhjfaqgtpenfwcxcofygagdapect; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_juciovhxwhjfaqgtpenfwcxcofygagdapect ON public.matrixblocktypes USING btree (name, "fieldId");


--
-- Name: idx_jvehjueeqcejszpgnzxsdjhxfwhhtgxqbktb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jvehjueeqcejszpgnzxsdjhxfwhhtgxqbktb ON public.commerce_pdfs USING btree (handle);


--
-- Name: idx_jyytzkwagjpmcvigzalmqcqmeofvfyorezys; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jyytzkwagjpmcvigzalmqcqmeofvfyorezys ON public.commerce_gateways USING btree ("isArchived");


--
-- Name: idx_jzefgisfjblbjsmkzljsbdjegpecqyhwqmdr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jzefgisfjblbjsmkzljsbdjegpecqyhwqmdr ON public.elements USING btree ("fieldLayoutId");


--
-- Name: idx_kawqxmqnnwnxfaugkgpcpwdoacocetwenjiz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kawqxmqnnwnxfaugkgpcpwdoacocetwenjiz ON public.fieldgroups USING btree (name);


--
-- Name: idx_kcbomxooutuozlehjmyautxujdethtejnxds; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kcbomxooutuozlehjmyautxujdethtejnxds ON public.commerce_products USING btree ("typeId");


--
-- Name: idx_kdzoyanmafeynmbekkywdmrbpimhwgfronow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kdzoyanmafeynmbekkywdmrbpimhwgfronow ON public.fieldlayoutfields USING btree ("fieldId");


--
-- Name: idx_kdzscdrepbblmgownvtysvrmbbcnkhggivte; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kdzscdrepbblmgownvtysvrmbbcnkhggivte ON public.fieldlayouttabs USING btree ("sortOrder");


--
-- Name: idx_kfuxnevougsusyvpbthykcmvvwvfwthgazss; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kfuxnevougsusyvpbthykcmvvwvfwthgazss ON public.commerce_orderhistories USING btree ("customerId");


--
-- Name: idx_kqggkxihbcwiwnnduvkxstecwpzffucruhim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kqggkxihbcwiwnnduvkxstecwpzffucruhim ON public.matrixblocks USING btree ("typeId");


--
-- Name: idx_kqiapgpbpsbhxyhrrtdmyupkqideucrhieoa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kqiapgpbpsbhxyhrrtdmyupkqideucrhieoa ON public.templatecacheelements USING btree ("elementId");


--
-- Name: idx_krcznfrladdzhbtjivleybwbndeipxhurnhq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_krcznfrladdzhbtjivleybwbndeipxhurnhq ON public.commerce_shippingrule_categories USING btree ("shippingRuleId");


--
-- Name: idx_ktkojjvwykyhyjtbwcnmtottywkaxuiianao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ktkojjvwykyhyjtbwcnmtottywkaxuiianao ON public.volumes USING btree ("fieldLayoutId");


--
-- Name: idx_kutijtogxhrffgxkuywlswnjpknxznzkqtng; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kutijtogxhrffgxkuywlswnjpknxznzkqtng ON public.elements USING btree (archived, "dateCreated");


--
-- Name: idx_kwfnkzttubeymglaontvkxvstcqttwqnvutf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kwfnkzttubeymglaontvkxvstcqttwqnvutf ON public.commerce_shippingzone_states USING btree ("stateId");


--
-- Name: idx_kwlpffymonrepyjbandvgjrgqbvebtleinno; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kwlpffymonrepyjbandvgjrgqbvebtleinno ON public.commerce_producttypes_sites USING btree ("siteId");


--
-- Name: idx_kxhroyycakkexzqrjwthcbxqhlbkflrilpgr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kxhroyycakkexzqrjwthcbxqhlbkflrilpgr ON public.structureelements USING btree ("elementId");


--
-- Name: idx_kzantqlbtibisjvuejfijhayhdwvrsyvgpro; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kzantqlbtibisjvuejfijhayhdwvrsyvgpro ON public.elements_sites USING btree (lower((uri)::text), "siteId");


--
-- Name: idx_kzmolfejubylvoujwnwmfzsduacscbocvale; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kzmolfejubylvoujwnwmfzsduacscbocvale ON public.volumefolders USING btree ("volumeId");


--
-- Name: idx_lasbvrnnighuxjwiguvgvcvwrchyqwbjtdhw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lasbvrnnighuxjwiguvgvcvwrchyqwbjtdhw ON public.users USING btree (lower((username)::text));


--
-- Name: idx_lbihxbdlgsnbbfxgpzyuicqlostunahaqspp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lbihxbdlgsnbbfxgpzyuicqlostunahaqspp ON public.commerce_discount_categories USING btree ("categoryId");


--
-- Name: idx_lbsudnurawtvixpzhmqufcbhtcethpzdmrqk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lbsudnurawtvixpzhmqufcbhtcethpzdmrqk ON public.userpermissions_users USING btree ("userId");


--
-- Name: idx_lfvskgltxlciazvgjcanwofwwcvoikxfgdyd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lfvskgltxlciazvgjcanwofwwcvoikxfgdyd ON public.categorygroups USING btree (handle);


--
-- Name: idx_lkvuiifvsecyyaoyqnzkrnjfsjcqobexnvrm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lkvuiifvsecyyaoyqnzkrnjfsjcqobexnvrm ON public.assettransformindex USING btree ("volumeId", "assetId", location);


--
-- Name: idx_lnojfsavsxdatsdpgbubvmxlcelqtfdqcihp; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_lnojfsavsxdatsdpgbubvmxlcelqtfdqcihp ON public.commerce_shippingzone_states USING btree ("shippingZoneId", "stateId");


--
-- Name: idx_loiklhvxxjgegyfuxjuarkefyrymyotpopuj; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_loiklhvxxjgegyfuxjuarkefyrymyotpopuj ON public.relations USING btree ("fieldId", "sourceId", "sourceSiteId", "targetId");


--
-- Name: idx_lpiimkelzpewzbwknzjbujcdegbuipcywfkj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lpiimkelzpewzbwknzjbujcdegbuipcywfkj ON public.commerce_transactions USING btree ("orderId");


--
-- Name: idx_lwzskedenaqunnndoltnundzbywvpagaqvcp; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_lwzskedenaqunnndoltnundzbywvpagaqvcp ON public.userpermissions USING btree (name);


--
-- Name: idx_mclpzytqzmfpywdqznjgcrlfdaxehtwyvppg; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mclpzytqzmfpywdqznjgcrlfdaxehtwyvppg ON public.fieldlayoutfields USING btree ("layoutId", "fieldId");


--
-- Name: idx_mebahqtgfflzurwlcvlnhhchhyvvlselqsss; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mebahqtgfflzurwlcvlnhhchhyvvlselqsss ON public.commerce_sale_categories USING btree ("saleId", "categoryId");


--
-- Name: idx_mfnjhqwawcroapgkxezdmiwlgymmuehzdqgq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mfnjhqwawcroapgkxezdmiwlgymmuehzdqgq ON public.categorygroups USING btree ("structureId");


--
-- Name: idx_mhngbldvqrdjpmbeyxkewpsfltfglmssiuko; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mhngbldvqrdjpmbeyxkewpsfltfglmssiuko ON public.commerce_products USING btree ("postDate");


--
-- Name: idx_mmmmwtdtsnizaayyddobtjtjygwtfcsbagqn; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mmmmwtdtsnizaayyddobtjtjygwtfcsbagqn ON public.commerce_countries USING btree (name);


--
-- Name: idx_mmrneqcbrttybkkcsreuzuyituyqfbyaxpum; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mmrneqcbrttybkkcsreuzuyituyqfbyaxpum ON public.gqltokens USING btree (name);


--
-- Name: idx_mskvnanygqxmvroopgnkycpabticwfoosixr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mskvnanygqxmvroopgnkycpabticwfoosixr ON public.fieldlayoutfields USING btree ("tabId");


--
-- Name: idx_myixkzaorhyxmnentkgycxlmgiwmlkjomtno; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_myixkzaorhyxmnentkgycxlmgiwmlkjomtno ON public.commerce_producttypes USING btree (handle);


--
-- Name: idx_nawwtyyaqzdaygnylqtpakfziwcwasjlpbsu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nawwtyyaqzdaygnylqtpakfziwcwasjlpbsu ON public.assets USING btree (filename, "folderId");


--
-- Name: idx_ncsppalwznqkkuwqeivventlroxtpqpychzm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ncsppalwznqkkuwqeivventlroxtpqpychzm ON public.entries USING btree ("sectionId");


--
-- Name: idx_ndmdsovmogvkaeppzwwmrhtevsxcvvictlmi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ndmdsovmogvkaeppzwwmrhtevsxcvvictlmi ON public.commerce_lineitems USING btree ("purchasableId");


--
-- Name: idx_neugrfdiawryaaaegixctvzhytkkycrqrcgy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_neugrfdiawryaaaegixctvzhytkkycrqrcgy ON public.commerce_customer_discountuses USING btree ("discountId");


--
-- Name: idx_nkhdpasqrdyaniwpapqsspaccvnxtsopkfcl; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_nkhdpasqrdyaniwpapqsspaccvnxtsopkfcl ON public.elementindexsettings USING btree (type);


--
-- Name: idx_nmedoqmnxclgkuujuxwotkoxqftjqnygmwfi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nmedoqmnxclgkuujuxwotkoxqftjqnygmwfi ON public.commerce_orderadjustments USING btree ("orderId");


--
-- Name: idx_nuzntsosdssqngtakjrmvakkanrdqgwvdycf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nuzntsosdssqngtakjrmvakkanrdqgwvdycf ON public.commerce_email_discountuses USING btree ("discountId");


--
-- Name: idx_octbfffcgqpzrzdzmfmiexjujexzjwygnzpu; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_octbfffcgqpzrzdzmfmiexjujexzjwygnzpu ON public.commerce_email_discountuses USING btree (email, "discountId");


--
-- Name: idx_odsplaxxickmpfiyhmjeoddvzekqlnthniqy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_odsplaxxickmpfiyhmjeoddvzekqlnthniqy ON public.commerce_orderhistories USING btree ("prevStatusId");


--
-- Name: idx_oebzdmjwiatuuwmeihafpbvxtnpsiwrcfhms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oebzdmjwiatuuwmeihafpbvxtnpsiwrcfhms ON public.userpermissions_usergroups USING btree ("groupId");


--
-- Name: idx_oimhxuvkdpiylwzetbwahvibrbxdtjervlqo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oimhxuvkdpiylwzetbwahvibrbxdtjervlqo ON public.changedfields USING btree ("elementId", "siteId", "dateUpdated");


--
-- Name: idx_opawetaljibjypvskvrzxobwgbworopztdjy; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_opawetaljibjypvskvrzxobwgbworopztdjy ON public.commerce_shippingzone_countries USING btree ("shippingZoneId", "countryId");


--
-- Name: idx_opejvfhowfbfojdhtbqazadlrqlnimfrtgcw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opejvfhowfbfojdhtbqazadlrqlnimfrtgcw ON public.sitegroups USING btree (name);


--
-- Name: idx_oqfraklzfisehbrmxhhbdqfbzpxybjjcmfdv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oqfraklzfisehbrmxhhbdqfbzpxybjjcmfdv ON public.elements USING btree (type);


--
-- Name: idx_otkqzvqdlfmengxykzcdocaomuohbcybdhsa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otkqzvqdlfmengxykzcdocaomuohbcybdhsa ON public.templatecaches USING btree ("siteId");


--
-- Name: idx_oudhtxxpwogoxomvhnfbdsopruretxecneps; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_oudhtxxpwogoxomvhnfbdsopruretxecneps ON public.categorygroups_sites USING btree ("groupId", "siteId");


--
-- Name: idx_oxliyzqcttlxnzjpolzmphbwlqlkyqmfryvh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oxliyzqcttlxnzjpolzmphbwlqlkyqmfryvh ON public.globalsets USING btree ("fieldLayoutId");


--
-- Name: idx_ozammsgzefcltindpnfzegyzcpoflxnatybv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ozammsgzefcltindpnfzegyzcpoflxnatybv ON public.sites USING btree ("dateDeleted");


--
-- Name: idx_pdfpchpclmsywlxzmejeuqjfboaqfdjvnuta; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_pdfpchpclmsywlxzmejeuqjfboaqfdjvnuta ON public.tokens USING btree (token);


--
-- Name: idx_phlwgdkvjubeswizrisfpthuxgqdmsmgohya; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_phlwgdkvjubeswizrisfpthuxgqdmsmgohya ON public.commerce_taxzone_countries USING btree ("taxZoneId");


--
-- Name: idx_pjuzdkzydylquvgccnmrgswzujkzlbwnqkkb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pjuzdkzydylquvgccnmrgswzujkzlbwnqkkb ON public.content USING btree ("siteId");


--
-- Name: idx_pxvvdrrepgwlyndjbucxowjsiuomsvblkruk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_pxvvdrrepgwlyndjbucxowjsiuomsvblkruk ON public.commerce_shippingmethods USING btree (name);


--
-- Name: idx_qbukyfxgpmzsllbtgrsgyhycfoxlzimhyknh; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_qbukyfxgpmzsllbtgrsgyhycfoxlzimhyknh ON public.usergroups_users USING btree ("groupId", "userId");


--
-- Name: idx_qcbgykhomzcqhmgrkjufymmmnkpvlyzdifks; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qcbgykhomzcqhmgrkjufymmmnkpvlyzdifks ON public.templatecaches USING btree ("cacheKey", "siteId", "expiryDate");


--
-- Name: idx_qdszqrcvonierkpgfihifafgtogzvrtovvgu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qdszqrcvonierkpgfihifafgtogzvrtovvgu ON public.elements_sites USING btree (enabled);


--
-- Name: idx_qfgmjnbvskqiyloicdqcvfdglfufjolwyhie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qfgmjnbvskqiyloicdqcvfdglfufjolwyhie ON public.matrixblocks USING btree ("fieldId");


--
-- Name: idx_qizeyjrrcbtcnnxtucjycgxfwbstwyxpxzpe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qizeyjrrcbtcnnxtucjycgxfwbstwyxpxzpe ON public.commerce_discount_usergroups USING btree ("userGroupId");


--
-- Name: idx_qkwmmfpegqeoizqlysihjnafonltktgcbrio; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_qkwmmfpegqeoizqlysihjnafonltktgcbrio ON public.commerce_states USING btree ("countryId", abbreviation);


--
-- Name: idx_qlebivigbrkldqdfovpkztnharieijjgvann; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qlebivigbrkldqdfovpkztnharieijjgvann ON public.commerce_shippingrules USING btree ("shippingZoneId");


--
-- Name: idx_qpkwcavrmmqzjpoczlldqmtjeidmatujeqrw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qpkwcavrmmqzjpoczlldqmtjeidmatujeqrw ON public.commerce_transactions USING btree ("gatewayId");


--
-- Name: idx_qxxccdqxqjzpdulzgwhydjqmtzmcddhrmzgc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qxxccdqxqjzpdulzgwhydjqmtzmcddhrmzgc ON public.structureelements USING btree (rgt);


--
-- Name: idx_qzpihsmqittuviwtvhhmebhqvasagyjvhzrw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qzpihsmqittuviwtvhhmebhqvasagyjvhzrw ON public.fields USING btree (context);


--
-- Name: idx_rezqwosdmpyfcafhxnmsqmbxwwzxnyvprack; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rezqwosdmpyfcafhxnmsqmbxwwzxnyvprack ON public.commerce_gateways USING btree (handle);


--
-- Name: idx_rfzkbbijpmmfvascmxwupifftekirqaflbxu; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_rfzkbbijpmmfvascmxwupifftekirqaflbxu ON public.commerce_customers_addresses USING btree ("customerId", "addressId");


--
-- Name: idx_rofnutryrpqjpwijamgxzmcnaclkulwqpxem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rofnutryrpqjpwijamgxzmcnaclkulwqpxem ON public.categorygroups USING btree ("dateDeleted");


--
-- Name: idx_rspbcdknclhxxofrygvnaznwwvbskcbavogi; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_rspbcdknclhxxofrygvnaznwwvbskcbavogi ON public.commerce_producttypes_sites USING btree ("productTypeId", "siteId");


--
-- Name: idx_rxiapgnmpdwtmschjwavgofoslfhpiiapqvx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rxiapgnmpdwtmschjwavgofoslfhpiiapqvx ON public.systemmessages USING btree (language);


--
-- Name: idx_ryedczukermyjzcuqvjpmweouavyodkcuuou; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ryedczukermyjzcuqvjpmweouavyodkcuuou ON public.systemmessages USING btree (key, language);


--
-- Name: idx_sctvnbctykajfdpcheytqcvtkxmgkkghmnse; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sctvnbctykajfdpcheytqcvtkxmgkkghmnse ON public.commerce_taxrates USING btree ("taxCategoryId");


--
-- Name: idx_sgyuzsccjdvrtvksahcnzsuazqelvtxhnbvi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sgyuzsccjdvrtvksahcnzsuazqelvtxhnbvi ON public.matrixblocks USING btree ("ownerId");


--
-- Name: idx_skaspxiuhgyxxyupdqqowxdmewzixifhodmx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skaspxiuhgyxxyupdqqowxdmewzixifhodmx ON public.content USING btree (title);


--
-- Name: idx_sxqdfiapnozrwolhiyezodyjxbtulizebvwk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sxqdfiapnozrwolhiyezodyjxbtulizebvwk ON public.commerce_producttypes USING btree ("variantFieldLayoutId");


--
-- Name: idx_tfijseowtulmbnkjuynkmjaccxeqgjpellfs; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_tfijseowtulmbnkjuynkmjaccxeqgjpellfs ON public.commerce_producttypes_taxcategories USING btree ("productTypeId", "taxCategoryId");


--
-- Name: idx_tksxbdjxowdqzvjwxecrvubwektkfgomjqgf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tksxbdjxowdqzvjwxecrvubwektkfgomjqgf ON public.structureelements USING btree (root);


--
-- Name: idx_tmyvxuyirjthsakzwdymuysijvpxxtxoncie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tmyvxuyirjthsakzwdymuysijvpxxtxoncie ON public.fieldlayoutfields USING btree ("sortOrder");


--
-- Name: idx_tpcwtwrutekaxwpfpjigzxvbkdvgswqopzot; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tpcwtwrutekaxwpfpjigzxvbkdvgswqopzot ON public.volumefolders USING btree ("parentId");


--
-- Name: idx_trjsjcmjpwotssywpfgvpllfdqhhkafkzniz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trjsjcmjpwotssywpfgvpllfdqhhkafkzniz ON public.commerce_taxzone_states USING btree ("taxZoneId");


--
-- Name: idx_trpagvyghogqsqvwknidugmtwuiplstgebpo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trpagvyghogqsqvwknidugmtwuiplstgebpo ON public.commerce_producttypes_shippingcategories USING btree ("shippingCategoryId");


--
-- Name: idx_tvaynuqjgduivyslheposyobtsxfcrisvhbv; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_tvaynuqjgduivyslheposyobtsxfcrisvhbv ON public.structureelements USING btree ("structureId", "elementId");


--
-- Name: idx_tviuvfpsfptmwrdcvowibkenifafzkexyvrp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tviuvfpsfptmwrdcvowibkenifafzkexyvrp ON public.taggroups USING btree (handle);


--
-- Name: idx_twpeunwyimjwqqrtpikkyjlwivkflfdgbexv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_twpeunwyimjwqqrtpikkyjlwivkflfdgbexv ON public.commerce_sale_purchasables USING btree ("purchasableId");


--
-- Name: idx_twtphdthxflvqvigxeeyqswrynwjvwiwstgf; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_twtphdthxflvqvigxeeyqswrynwjvwiwstgf ON public.commerce_taxcategories USING btree (handle);


--
-- Name: idx_tyoviyocctyycjaepmpmloqrlzwtokqevuth; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tyoviyocctyycjaepmpmloqrlzwtokqevuth ON public.elements_sites USING btree ("siteId");


--
-- Name: idx_tyzmkafkkssbgemudiizjcgpdjijhdtyfrsd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tyzmkafkkssbgemudiizjcgpdjijhdtyfrsd ON public.structureelements USING btree (level);


--
-- Name: idx_udjhnfcjwbgowhbuqlyxfrtiovcizgdvmacq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_udjhnfcjwbgowhbuqlyxfrtiovcizgdvmacq ON public.sessions USING btree ("dateUpdated");


--
-- Name: idx_udjuowwwvtorvqynstrrqcnxijztckyjvmqw; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_udjuowwwvtorvqynstrrqcnxijztckyjvmqw ON public.commerce_plans USING btree (handle);


--
-- Name: idx_uflrpihiyvleyzfzlyrztakxcuevttzinoku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uflrpihiyvleyzfzlyrztakxcuevttzinoku ON public.volumes USING btree (handle);


--
-- Name: idx_ullkthcynpucynbvtyklifeqfmsmgucurpxf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ullkthcynpucynbvtyklifeqfmsmgucurpxf ON public.commerce_taxrates USING btree ("taxZoneId");


--
-- Name: idx_umltwpvzlmytwlbagereibbvbjmiyykyhukq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_umltwpvzlmytwlbagereibbvbjmiyykyhukq ON public.volumes USING btree (name);


--
-- Name: idx_usjqnqhqgcaayrtditivklumkqinzhtfknkz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usjqnqhqgcaayrtditivklumkqinzhtfknkz ON public.commerce_discounts USING btree ("dateFrom");


--
-- Name: idx_uttzkejlkohajdcatqwyiklavhdnvuluqydc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uttzkejlkohajdcatqwyiklavhdnvuluqydc ON public.entries USING btree ("expiryDate");


--
-- Name: idx_utwcdtsabclrfgitwkldsknkuvrybujtssrm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_utwcdtsabclrfgitwkldsknkuvrybujtssrm ON public.entrytypes USING btree (name, "sectionId");


--
-- Name: idx_uxhofdmtlqcpuwaprxjldgyabxjumysyzzwu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uxhofdmtlqcpuwaprxjldgyabxjumysyzzwu ON public.elements USING btree (enabled);


--
-- Name: idx_uzgsewbvmvwhluxsoycdfwynnguiopxopyje; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_uzgsewbvmvwhluxsoycdfwynnguiopxopyje ON public.commerce_states USING btree ("countryId", name);


--
-- Name: idx_vcuhlwaccfhpakjnrchipglfipslgixmjhqr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vcuhlwaccfhpakjnrchipglfipslgixmjhqr ON public.commerce_products USING btree ("shippingCategoryId");


--
-- Name: idx_vdpmbpoecqkdrxnttlawfkzvejmotrugteuq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vdpmbpoecqkdrxnttlawfkzvejmotrugteuq ON public.entrytypes USING btree ("sectionId");


--
-- Name: idx_vdtwjdudbgoppnlzugsvdjoptndfauxtjwiw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vdtwjdudbgoppnlzugsvdjoptndfauxtjwiw ON public.volumes USING btree ("dateDeleted");


--
-- Name: idx_vhxqvaeqrccsljednchxbamkojmmuwesxedb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vhxqvaeqrccsljednchxbamkojmmuwesxedb ON public.commerce_transactions USING btree ("parentId");


--
-- Name: idx_vibbxigkzzwmedtfrwotpitpssczkumfbawz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vibbxigkzzwmedtfrwotpitpssczkumfbawz ON public.categorygroups_sites USING btree ("siteId");


--
-- Name: idx_vjfuugibixmdvtfcfdxqsumzxeewoctzjnfq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vjfuugibixmdvtfcfdxqsumzxeewoctzjnfq ON public.usergroups USING btree (name);


--
-- Name: idx_vknzmoaqxavafnatagglvavshkubtixqbfhu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vknzmoaqxavafnatagglvavshkubtixqbfhu ON public.commerce_orderhistories USING btree ("orderId");


--
-- Name: idx_vmejvhqdmikcozjnibwtemsempfgpgdgehgg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vmejvhqdmikcozjnibwtemsempfgpgdgehgg ON public.commerce_addresses USING btree ("stateId");


--
-- Name: idx_vnbyvdtmfuuxaqlblamcngpiktotgoqnabva; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vnbyvdtmfuuxaqlblamcngpiktotgoqnabva ON public.commerce_orders USING btree ("customerId");


--
-- Name: idx_vnvccgelzalvsphbjmkgargwzikvwwtskhej; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vnvccgelzalvsphbjmkgargwzikvwwtskhej ON public.searchindex USING gin (keywords_vector) WITH (fastupdate=yes);


--
-- Name: idx_vtzhkhbqggrefmnjxazxdalujhdcphmmmojr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vtzhkhbqggrefmnjxazxdalujhdcphmmmojr ON public.commerce_shippingzone_states USING btree ("shippingZoneId");


--
-- Name: idx_vxifsastwygflrbjjsqlxammjiwzzsneasgs; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vxifsastwygflrbjjsqlxammjiwzzsneasgs ON public.commerce_shippingcategories USING btree (handle);


--
-- Name: idx_wncuqptutgwoftsidzrlfkzcpenjyjicnevj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wncuqptutgwoftsidzrlfkzcpenjyjicnevj ON public.commerce_subscriptions USING btree ("nextPaymentDate");


--
-- Name: idx_wpigaplsfribrqyxeezmtbumlgjlgdlsodud; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wpigaplsfribrqyxeezmtbumlgjlgdlsodud ON public.assets USING btree ("volumeId");


--
-- Name: idx_wrikeprjzsrgtmhjsyvnwnvwvbtftqfulpjq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wrikeprjzsrgtmhjsyvnwnvwvbtftqfulpjq ON public.commerce_lineitems USING btree ("shippingCategoryId");


--
-- Name: idx_wsllyoxqgxxminqcrximlhgbgbumguskqtdn; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_wsllyoxqgxxminqcrximlhgbgbumguskqtdn ON public.volumefolders USING btree (name, "parentId", "volumeId");


--
-- Name: idx_wusonvxsdodtreykagtbifqekpkubphrltro; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wusonvxsdodtreykagtbifqekpkubphrltro ON public.commerce_subscriptions USING btree ("userId");


--
-- Name: idx_wwhddddbdohpvqnytqfoqewbnbpyygqfdlow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wwhddddbdohpvqnytqfoqewbnbpyygqfdlow ON public.commerce_orders USING btree ("shippingAddressId");


--
-- Name: idx_xgglropxjhkjmhdhjfaheocawicdsqqjjjnd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xgglropxjhkjmhdhjfaheocawicdsqqjjjnd ON public.users USING btree ("verificationCode");


--
-- Name: idx_xigsxqpcsmgbkytpnqywomdbadowvgxofgqp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xigsxqpcsmgbkytpnqywomdbadowvgxofgqp ON public.commerce_subscriptions USING btree ("dateExpired");


--
-- Name: idx_xkvxdtgbyuvvmkvkckfcrkpyegzsqtizagsz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xkvxdtgbyuvvmkvkckfcrkpyegzsqtizagsz ON public.commerce_plans USING btree (reference);


--
-- Name: idx_xlgxshojwabhxyioocsedraxwxplqaxuflsp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xlgxshojwabhxyioocsedraxwxplqaxuflsp ON public.commerce_subscriptions USING btree ("planId");


--
-- Name: idx_xqvdevkgmhavxluxzgdwebtqsknzzccwwoag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xqvdevkgmhavxluxzgdwebtqsknzzccwwoag ON public.sections USING btree (handle);


--
-- Name: idx_xrchggkiavhnbioqhzlugdnqsfnzrlmjqjyg; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xrchggkiavhnbioqhzlugdnqsfnzrlmjqjyg ON public.commerce_taxzone_states USING btree ("taxZoneId", "stateId");


--
-- Name: idx_xsifkizwgnuycnsvvtsbmucxaritjydkwjwl; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xsifkizwgnuycnsvvtsbmucxaritjydkwjwl ON public.deprecationerrors USING btree (key, fingerprint);


--
-- Name: idx_xwtohhgbngjyythdpdfuhoxfawemhcawpvyy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xwtohhgbngjyythdpdfuhoxfawemhcawpvyy ON public.drafts USING btree (saved);


--
-- Name: idx_xwxkytqdrbqlapsgxzlinixjqjyaswfcfogf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xwxkytqdrbqlapsgxzlinixjqjyaswfcfogf ON public.commerce_producttypes_taxcategories USING btree ("taxCategoryId");


--
-- Name: idx_xykgsykuowfsqbrwcbknnadfhhltdmnqzgnu; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xykgsykuowfsqbrwcbknnadfhhltdmnqzgnu ON public.commerce_paymentcurrencies USING btree (iso);


--
-- Name: idx_xzsubmwjpknpzfbydgwfgnfbwehmxsfvzazq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xzsubmwjpknpzfbydgwfgnfbwehmxsfvzazq ON public.userpermissions_users USING btree ("permissionId", "userId");


--
-- Name: idx_ycazfojrlasibaewyuxwuvcdvogmvwcrqzai; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ycazfojrlasibaewyuxwuvcdvogmvwcrqzai ON public.elements_sites USING btree ("elementId", "siteId");


--
-- Name: idx_ygsllzriyzesushuxxbgjcbwbovtchcrmwmb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ygsllzriyzesushuxxbgjcbwbovtchcrmwmb ON public.elements_sites USING btree (slug, "siteId");


--
-- Name: idx_ygsrpbzxenwodgrhisvlzawlgsmakipagysz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ygsrpbzxenwodgrhisvlzawlgsmakipagysz ON public.sections USING btree ("dateDeleted");


--
-- Name: idx_ygwwmkxgwwifzbwzdidljxodebfcazimipzc; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ygwwmkxgwwifzbwzdidljxodebfcazimipzc ON public.userpermissions_usergroups USING btree ("permissionId", "groupId");


--
-- Name: idx_yjpxdcltmhwhiuoxxapsdbhadklpcdzrpftl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yjpxdcltmhwhiuoxxapsdbhadklpcdzrpftl ON public.relations USING btree ("sourceSiteId");


--
-- Name: idx_ykqsqtwifdqkvpzjimbeawdwecfblxabtsov; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ykqsqtwifdqkvpzjimbeawdwecfblxabtsov ON public.matrixblocktypes USING btree ("fieldId");


--
-- Name: idx_yoyxytjmvtzllpduepfzeawusontlpyogbfj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yoyxytjmvtzllpduepfzeawusontlpyogbfj ON public.sections USING btree ("structureId");


--
-- Name: idx_ystwmqgzihreewcmvhkglrxcssagsvyerryc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ystwmqgzihreewcmvhkglrxcssagsvyerryc ON public.commerce_purchasables USING btree (sku);


--
-- Name: idx_yswayfjjbvyjhbpvtilnqlbamsllnukktbip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yswayfjjbvyjhbpvtilnqlbamsllnukktbip ON public.structureelements USING btree (lft);


--
-- Name: idx_yuiemuqdfwqegtakvuzimvsxeskzqmkjksmn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yuiemuqdfwqegtakvuzimvsxeskzqmkjksmn ON public.commerce_customers USING btree ("primaryBillingAddressId");


--
-- Name: idx_yvqjnicbhqionvkhzsilexyejolgyefffexd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yvqjnicbhqionvkhzsilexyejolgyefffexd ON public.commerce_discount_purchasables USING btree ("purchasableId");


--
-- Name: idx_ywohovlunfgtmrxxkuexmfxaqwnytxerijok; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ywohovlunfgtmrxxkuexmfxaqwnytxerijok ON public.templatecaches USING btree ("cacheKey", "siteId", "expiryDate", path);


--
-- Name: idx_yxisactfpkuyzxmwzdokphxmncmjlpaxltaq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yxisactfpkuyzxmwzdokphxmncmjlpaxltaq ON public.queue USING btree (channel, fail, "timeUpdated", "timePushed");


--
-- Name: idx_zhgjnzsfuoetkcvqjtdmkgdyuvdofofhighg; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_zhgjnzsfuoetkcvqjtdmkgdyuvdofofhighg ON public.commerce_taxzone_countries USING btree ("taxZoneId", "countryId");


--
-- Name: idx_zjepwigkkluwcirxnwncrxcpjrfmrtxehial; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zjepwigkkluwcirxnwncrxcpjrfmrtxehial ON public.entries USING btree ("authorId");


--
-- Name: idx_zjiqmoxikfilqcgnvtdihnyfmiiblhdamsug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zjiqmoxikfilqcgnvtdihnyfmiiblhdamsug ON public.templatecachequeries USING btree (type);


--
-- Name: idx_zkdcfmgquvbtkfthynczzncficjjzoyvzfwq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zkdcfmgquvbtkfthynczzncficjjzoyvzfwq ON public.usergroups_users USING btree ("userId");


--
-- Name: idx_zpsukvmedbenatxbmfnvdaolfkfqzfvhuyph; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zpsukvmedbenatxbmfnvdaolfkfqzfvhuyph ON public.tokens USING btree ("expiryDate");


--
-- Name: idx_zqsdglsfsadeplqdqibbxnepbwjsfyjqfffk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zqsdglsfsadeplqdqibbxnepbwjsfyjqfffk ON public.commerce_states USING btree ("countryId");


--
-- Name: idx_zthkypdkrmnlzwwpelgwixmghdaggqzbeubo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zthkypdkrmnlzwwpelgwixmghdaggqzbeubo ON public.sessions USING btree (token);


--
-- Name: idx_ztrezchlaifvmtpuzxtopodvapspfevdwxcj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ztrezchlaifvmtpuzxtopodvapspfevdwxcj ON public.commerce_products USING btree ("taxCategoryId");


--
-- Name: idx_zxfwrqshbxjgnxxavhmnwhxqjoezrpdotqac; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_zxfwrqshbxjgnxxavhmnwhxqjoezrpdotqac ON public.sections_sites USING btree ("sectionId", "siteId");


--
-- Name: matrixblocktypes fk_aagdbbwnjqddpkaatzusnkomevwsgzldvtzr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT fk_aagdbbwnjqddpkaatzusnkomevwsgzldvtzr FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: commerce_producttypes fk_aarjcjmwbimwdlzwivdliocpsipfxjbgifpa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes
    ADD CONSTRAINT fk_aarjcjmwbimwdlzwivdliocpsipfxjbgifpa FOREIGN KEY ("variantFieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: templatecachequeries fk_akhiihbwxcxibdxemypylnzragwxtmvdyhob; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecachequeries
    ADD CONSTRAINT fk_akhiihbwxcxibdxemypylnzragwxtmvdyhob FOREIGN KEY ("cacheId") REFERENCES public.templatecaches(id) ON DELETE CASCADE;


--
-- Name: widgets fk_alwtcqgtbusmplowojkyhvkrgnvjiicvyzcj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT fk_alwtcqgtbusmplowojkyhvkrgnvjiicvyzcj FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications_notifications fk_arsuzfopecbadxsxxdbahdqgghpuhcqetivb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications_notifications
    ADD CONSTRAINT fk_arsuzfopecbadxsxxdbahdqgghpuhcqetivb FOREIGN KEY (notifiable) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: changedattributes fk_bhiqypmupmsdxpfzgkgbwrycyuzhmtsyzoma; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_bhiqypmupmsdxpfzgkgbwrycyuzhmtsyzoma FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_orders fk_bhnmihgmrefiavmaiyfccamsmvxxzhwvoywo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_bhnmihgmrefiavmaiyfccamsmvxxzhwvoywo FOREIGN KEY ("customerId") REFERENCES public.commerce_customers(id) ON DELETE SET NULL;


--
-- Name: categorygroups fk_bivwaryjolykbyveoiqifgjwbzcbwfprtyav; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT fk_bivwaryjolykbyveoiqifgjwbzcbwfprtyav FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: revisions fk_bpdgoamdevklyqxybqwbmwzhqhdatyoypoii; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT fk_bpdgoamdevklyqxybqwbmwzhqhdatyoypoii FOREIGN KEY ("sourceId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_orders fk_bucvikkiowhlzvcvircegqppzwrbjzitvbbg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_bucvikkiowhlzvcvircegqppzwrbjzitvbbg FOREIGN KEY ("estimatedShippingAddressId") REFERENCES public.commerce_addresses(id) ON DELETE SET NULL;


--
-- Name: categories fk_bwgbalogcuuppqcyovrwmpqalrzxhiqkcqvk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_bwgbalogcuuppqcyovrwmpqalrzxhiqkcqvk FOREIGN KEY ("groupId") REFERENCES public.categorygroups(id) ON DELETE CASCADE;


--
-- Name: commerce_taxzone_states fk_bxkplcrjnaaivqeqcktajlqgxntfukxtyrec; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_states
    ADD CONSTRAINT fk_bxkplcrjnaaivqeqcktajlqgxntfukxtyrec FOREIGN KEY ("taxZoneId") REFERENCES public.commerce_taxzones(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: entries fk_byzuriukcsbojpsbmxjhgxscnbyofbnknyda; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_byzuriukcsbojpsbmxjhgxscnbyofbnknyda FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: taggroups fk_cclroktevzvmuqlgznoywykyajttjbepqpqq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggroups
    ADD CONSTRAINT fk_cclroktevzvmuqlgznoywykyajttjbepqpqq FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: commerce_sale_purchasables fk_cebldfzvgnqdzdigtxxjiweupmgcpbboxwgg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_purchasables
    ADD CONSTRAINT fk_cebldfzvgnqdzdigtxxjiweupmgcpbboxwgg FOREIGN KEY ("saleId") REFERENCES public.commerce_sales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_chskglbafppyotpzwlyimopienlhbznjzzve; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_chskglbafppyotpzwlyimopienlhbznjzzve FOREIGN KEY ("layoutId") REFERENCES public.fieldlayouts(id) ON DELETE CASCADE;


--
-- Name: templatecacheelements fk_ckssdngslanhifzfhtksmxcvbnxzpvrpfjco; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements
    ADD CONSTRAINT fk_ckssdngslanhifzfhtksmxcvbnxzpvrpfjco FOREIGN KEY ("cacheId") REFERENCES public.templatecaches(id) ON DELETE CASCADE;


--
-- Name: commerce_discount_categories fk_cmzdwaxylwaomxxrnsmtzdqbqaohvzobaxcf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_categories
    ADD CONSTRAINT fk_cmzdwaxylwaomxxrnsmtzdqbqaohvzobaxcf FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_discount_purchasables fk_cndvkjbcyjriltlbsapwfoqvtwsjwpwbcdwx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_purchasables
    ADD CONSTRAINT fk_cndvkjbcyjriltlbsapwfoqvtwsjwpwbcdwx FOREIGN KEY ("purchasableId") REFERENCES public.commerce_purchasables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_producttypes_taxcategories fk_cokusibyztqlztjazfmtjljarezxhpddvoze; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_taxcategories
    ADD CONSTRAINT fk_cokusibyztqlztjazfmtjljarezxhpddvoze FOREIGN KEY ("taxCategoryId") REFERENCES public.commerce_taxcategories(id) ON DELETE CASCADE;


--
-- Name: commerce_states fk_coqoyiieslftvvfrzzvbbiphgijrxtaizgiq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_states
    ADD CONSTRAINT fk_coqoyiieslftvvfrzzvbbiphgijrxtaizgiq FOREIGN KEY ("countryId") REFERENCES public.commerce_countries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_shippingrules fk_ctlzerjobspxwnisozhssczwpciqncwqzvma; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrules
    ADD CONSTRAINT fk_ctlzerjobspxwnisozhssczwpciqncwqzvma FOREIGN KEY ("shippingZoneId") REFERENCES public.commerce_shippingzones(id) ON DELETE SET NULL;


--
-- Name: commerce_products fk_cywwdreigvvzmihwqdcthyhrcntgsvbbdouh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_products
    ADD CONSTRAINT fk_cywwdreigvvzmihwqdcthyhrcntgsvbbdouh FOREIGN KEY ("taxCategoryId") REFERENCES public.commerce_taxcategories(id);


--
-- Name: commerce_orderadjustments fk_dcynjqnuzcivtmqtghekarskmmgukqslutas; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderadjustments
    ADD CONSTRAINT fk_dcynjqnuzcivtmqtghekarskmmgukqslutas FOREIGN KEY ("orderId") REFERENCES public.commerce_orders(id) ON DELETE CASCADE;


--
-- Name: assets fk_demhfioylqipieutnxxuyqqrnegbrxrkctkp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_demhfioylqipieutnxxuyqqrnegbrxrkctkp FOREIGN KEY ("uploaderId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: entries fk_dewoijnjekuklnkywolfyftxsovmjiifgysa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_dewoijnjekuklnkywolfyftxsovmjiifgysa FOREIGN KEY ("authorId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userpermissions_usergroups fk_dnwuuemmwurbfvgahslhcdcbxlhfkkbzwdsf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT fk_dnwuuemmwurbfvgahslhcdcbxlhfkkbzwdsf FOREIGN KEY ("permissionId") REFERENCES public.userpermissions(id) ON DELETE CASCADE;


--
-- Name: commerce_products fk_duzbffkikulrjqibflhljqremaxandqbiuhd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_products
    ADD CONSTRAINT fk_duzbffkikulrjqibflhljqremaxandqbiuhd FOREIGN KEY ("typeId") REFERENCES public.commerce_producttypes(id) ON DELETE CASCADE;


--
-- Name: commerce_lineitems fk_dwrleecjoueozeelsvdxknltbhmyrxpmpatx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitems
    ADD CONSTRAINT fk_dwrleecjoueozeelsvdxknltbhmyrxpmpatx FOREIGN KEY ("orderId") REFERENCES public.commerce_orders(id) ON DELETE CASCADE;


--
-- Name: commerce_orders fk_dwsskpbpbakyiemdswumuvvhhkjrbaxmvmyf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_dwsskpbpbakyiemdswumuvvhhkjrbaxmvmyf FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: users fk_dzwohcvcrwjkvmwoojiunqstckvntqsdzfih; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_dzwohcvcrwjkvmwoojiunqstckvntqsdzfih FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: tags fk_ebzclfrkjucqnkydcbtjdeeobedusbljfzlv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_ebzclfrkjucqnkydcbtjdeeobedusbljfzlv FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: assets fk_ehghabarawarwfwlkgmtbuqipjlefyouzbqv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_ehghabarawarwfwlkgmtbuqipjlefyouzbqv FOREIGN KEY ("folderId") REFERENCES public.volumefolders(id) ON DELETE CASCADE;


--
-- Name: volumes fk_ejckjanqqirnogycweueaihtotwswmidnlue; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumes
    ADD CONSTRAINT fk_ejckjanqqirnogycweueaihtotwswmidnlue FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: matrixblocks fk_emhmsvpvioooucrgsoyycisowmoilrretrng; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_emhmsvpvioooucrgsoyycisowmoilrretrng FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: tags fk_enmhxzjvdnallfrjxfxfgmgpldwigpxikzjv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_enmhxzjvdnallfrjxfxfgmgpldwigpxikzjv FOREIGN KEY ("groupId") REFERENCES public.taggroups(id) ON DELETE CASCADE;


--
-- Name: revisions fk_eqywjdtxlsckxykjhqxrmeqpqofwdetfdthq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT fk_eqywjdtxlsckxykjhqxrmeqpqofwdetfdthq FOREIGN KEY ("creatorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: volumefolders fk_erkezfmmaweyijmffzroookhgxeqvqqoennm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT fk_erkezfmmaweyijmffzroookhgxeqvqqoennm FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: commerce_lineitems fk_eumuwfwseqfmzjzjthccguwgiccidnrxwcla; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitems
    ADD CONSTRAINT fk_eumuwfwseqfmzjzjthccguwgiccidnrxwcla FOREIGN KEY ("purchasableId") REFERENCES public.elements(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: commerce_orders fk_ewzbndystyuncxsfzemxoeukpwnrnsdrzikx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_ewzbndystyuncxsfzemxoeukpwnrnsdrzikx FOREIGN KEY ("billingAddressId") REFERENCES public.commerce_addresses(id) ON DELETE SET NULL;


--
-- Name: commerce_plans fk_fbdheoqedxrirelolmdzecbwayfmjdbpwcym; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_plans
    ADD CONSTRAINT fk_fbdheoqedxrirelolmdzecbwayfmjdbpwcym FOREIGN KEY ("gatewayId") REFERENCES public.commerce_gateways(id) ON DELETE CASCADE;


--
-- Name: usergroups_users fk_fvcedqiogpwqhkcnrfslrxwuppviaqfrwsge; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT fk_fvcedqiogpwqhkcnrfslrxwuppviaqfrwsge FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: commerce_orders fk_fyvnujmjatlukvdxdlhgdootvrbcsjodadgt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_fyvnujmjatlukvdxdlhgdootvrbcsjodadgt FOREIGN KEY ("paymentSourceId") REFERENCES public.commerce_paymentsources(id) ON DELETE SET NULL;


--
-- Name: commerce_transactions fk_ggijmtqswancldbfvlshogavfzpnacrsqkuq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_transactions
    ADD CONSTRAINT fk_ggijmtqswancldbfvlshogavfzpnacrsqkuq FOREIGN KEY ("orderId") REFERENCES public.commerce_orders(id) ON DELETE CASCADE;


--
-- Name: categorygroups_sites fk_gyutpopgtaaqingdvcgcfmrhlzznpbjvvcua; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT fk_gyutpopgtaaqingdvcgcfmrhlzznpbjvvcua FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: entries fk_gznynmxvrhcqvdfphatgspbkduxyzmbtasbi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_gznynmxvrhcqvdfphatgspbkduxyzmbtasbi FOREIGN KEY ("parentId") REFERENCES public.entries(id) ON DELETE SET NULL;


--
-- Name: commerce_orderstatus_emails fk_hagysabttydfugwwjangxlihjokbpwpdrfto; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderstatus_emails
    ADD CONSTRAINT fk_hagysabttydfugwwjangxlihjokbpwpdrfto FOREIGN KEY ("emailId") REFERENCES public.commerce_emails(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sections_sites fk_hbddztvxpjokcjrfujgzmpdvauxtnkjuxvoc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT fk_hbddztvxpjokcjrfujgzmpdvauxtnkjuxvoc FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_orderhistories fk_himbsabwyqkpnfflhqwpsbbvxoealdshgegt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderhistories
    ADD CONSTRAINT fk_himbsabwyqkpnfflhqwpsbbvxoealdshgegt FOREIGN KEY ("orderId") REFERENCES public.commerce_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_discount_purchasables fk_hoffcvenhgkjqphittqhvwxpginqitstfufl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_purchasables
    ADD CONSTRAINT fk_hoffcvenhgkjqphittqhvwxpginqitstfufl FOREIGN KEY ("discountId") REFERENCES public.commerce_discounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_transactions fk_hpvfqluevhgbtdgbyqsdvxbsocudroqtlmss; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_transactions
    ADD CONSTRAINT fk_hpvfqluevhgbtdgbyqsdvxbsocudroqtlmss FOREIGN KEY ("gatewayId") REFERENCES public.commerce_gateways(id) ON UPDATE CASCADE;


--
-- Name: relations fk_hrlmnvkeokqgemfsmemjtwayavqsoyzgujln; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_hrlmnvkeokqgemfsmemjtwayavqsoyzgujln FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: changedfields fk_hshdlicugirhtidtswvwmpxulglmsqnbejfp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_hshdlicugirhtidtswvwmpxulglmsqnbejfp FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: entrytypes fk_hwoweujuyowcvdujyhegqhumsamsfpkduyal; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT fk_hwoweujuyowcvdujyhegqhumsamsfpkduyal FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: commerce_lineitems fk_ibjldchdrevnwvgdpngivaozeevjakgxbvwk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitems
    ADD CONSTRAINT fk_ibjldchdrevnwvgdpngivaozeevjakgxbvwk FOREIGN KEY ("shippingCategoryId") REFERENCES public.commerce_shippingcategories(id) ON UPDATE CASCADE;


--
-- Name: commerce_producttypes fk_iinztdpfbsqcauntlpugezfpphjaddcrrkbt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes
    ADD CONSTRAINT fk_iinztdpfbsqcauntlpugezfpphjaddcrrkbt FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: elements_sites fk_imuyfgkkupfoyyeskijpskbqrqchqqqzcbso; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT fk_imuyfgkkupfoyyeskijpskbqrqchqqqzcbso FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_addresses fk_invewoxhrrodemfpfeygzpxoxywxpglxnucm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_addresses
    ADD CONSTRAINT fk_invewoxhrrodemfpfeygzpxoxywxpglxnucm FOREIGN KEY ("countryId") REFERENCES public.commerce_countries(id) ON DELETE SET NULL;


--
-- Name: content fk_itwkpifhrypitgjqntfxyczmcmyrfhgyyvmd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT fk_itwkpifhrypitgjqntfxyczmcmyrfhgyyvmd FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_subscriptions fk_jayhyvpmjehooqsavksuxnpswcyskcaydxct; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_subscriptions
    ADD CONSTRAINT fk_jayhyvpmjehooqsavksuxnpswcyskcaydxct FOREIGN KEY ("gatewayId") REFERENCES public.commerce_gateways(id) ON DELETE RESTRICT;


--
-- Name: matrixblocks fk_jehjjxybmpyaknxflepsgotydenphiclzzww; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_jehjjxybmpyaknxflepsgotydenphiclzzww FOREIGN KEY ("ownerId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_customers_addresses fk_jevtjnhebcvcbdpzphpxwpgytuptwxevkwmm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers_addresses
    ADD CONSTRAINT fk_jevtjnhebcvcbdpzphpxwpgytuptwxevkwmm FOREIGN KEY ("addressId") REFERENCES public.commerce_addresses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_transactions fk_jjlwvskbjtvtkgawpckdzyqvtumlkmrrsxab; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_transactions
    ADD CONSTRAINT fk_jjlwvskbjtvtkgawpckdzyqvtumlkmrrsxab FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: elements fk_jjseedhwpbvxlnywkoaseemsybghspkorbih; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_jjseedhwpbvxlnywkoaseemsybghspkorbih FOREIGN KEY ("revisionId") REFERENCES public.revisions(id) ON DELETE CASCADE;


--
-- Name: commerce_customers fk_jpxjqurnkwvqpoadpkyjyusgqwtbussffdmu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers
    ADD CONSTRAINT fk_jpxjqurnkwvqpoadpkyjyusgqwtbussffdmu FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sections fk_jselgxbbpwgjecdmawqlepafwaawkoqopetw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT fk_jselgxbbpwgjecdmawqlepafwaawkoqopetw FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE SET NULL;


--
-- Name: commerce_lineitems fk_jypvvjjnotneeqqkyonlhqcyhxglahzoanys; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_lineitems
    ADD CONSTRAINT fk_jypvvjjnotneeqqkyonlhqcyhxglahzoanys FOREIGN KEY ("taxCategoryId") REFERENCES public.commerce_taxcategories(id) ON UPDATE CASCADE;


--
-- Name: users fk_kjpskunohsohggrmjbbxldximbzfchqxkjua; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_kjpskunohsohggrmjbbxldximbzfchqxkjua FOREIGN KEY ("photoId") REFERENCES public.assets(id) ON DELETE SET NULL;


--
-- Name: userpreferences fk_kjypmgdrnirmrxdqztjhdpffgcytxuhrngma; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpreferences
    ADD CONSTRAINT fk_kjypmgdrnirmrxdqztjhdpffgcytxuhrngma FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: commerce_shippingrule_categories fk_klleobhmxetqmgquaecovcujdaxloreyabcb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrule_categories
    ADD CONSTRAINT fk_klleobhmxetqmgquaecovcujdaxloreyabcb FOREIGN KEY ("shippingRuleId") REFERENCES public.commerce_shippingrules(id) ON DELETE CASCADE;


--
-- Name: drafts fk_krqilftiftzlmfjsftkcahppldhvfyoyfhga; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT fk_krqilftiftzlmfjsftkcahppldhvfyoyfhga FOREIGN KEY ("sourceId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_orderhistories fk_ktegpncvwbjpltwaxzugcapiibcmuwwpdafv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderhistories
    ADD CONSTRAINT fk_ktegpncvwbjpltwaxzugcapiibcmuwwpdafv FOREIGN KEY ("prevStatusId") REFERENCES public.commerce_orderstatuses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: commerce_orderstatus_emails fk_kwtmclqojbcdcpfufbmukcusjolzgqtjgvmy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderstatus_emails
    ADD CONSTRAINT fk_kwtmclqojbcdcpfufbmukcusjolzgqtjgvmy FOREIGN KEY ("orderStatusId") REFERENCES public.commerce_orderstatuses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: commerce_shippingzone_states fk_kzrpcdqlvnyeipcnvlvdzkfvwinzcdfnjtjc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_states
    ADD CONSTRAINT fk_kzrpcdqlvnyeipcnvlvdzkfvwinzcdfnjtjc FOREIGN KEY ("shippingZoneId") REFERENCES public.commerce_shippingzones(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_email_discountuses fk_lamxnjvafmnxjhphklpxhxosvfrpukgvnycj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_email_discountuses
    ADD CONSTRAINT fk_lamxnjvafmnxjhphklpxhxosvfrpukgvnycj FOREIGN KEY ("discountId") REFERENCES public.commerce_discounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_producttypes_shippingcategories fk_lganxxedadmjwfedtsttsmthwwmobjvpsfox; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_shippingcategories
    ADD CONSTRAINT fk_lganxxedadmjwfedtsttsmthwwmobjvpsfox FOREIGN KEY ("productTypeId") REFERENCES public.commerce_producttypes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_sale_categories fk_lldpcflccowawihanxkiiawasripexhoonvk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_categories
    ADD CONSTRAINT fk_lldpcflccowawihanxkiiawasripexhoonvk FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: volumefolders fk_lowfilqtyknwtiglaztplxcwhaxcbrexwudo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT fk_lowfilqtyknwtiglaztplxcwhaxcbrexwudo FOREIGN KEY ("parentId") REFERENCES public.volumefolders(id) ON DELETE CASCADE;


--
-- Name: elements fk_lxtitebyqvrghmuskchakjmchejvbgaiaxgj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_lxtitebyqvrghmuskchakjmchejvbgaiaxgj FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: commerce_plans fk_lzxjarxgeaswatxvmvmaxvpbneoygwlvkito; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_plans
    ADD CONSTRAINT fk_lzxjarxgeaswatxvmvmaxvpbneoygwlvkito FOREIGN KEY ("planInformationId") REFERENCES public.elements(id) ON DELETE SET NULL;


--
-- Name: commerce_addresses fk_mhgrggnsypidyaqephacydxekbyfhmusdale; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_addresses
    ADD CONSTRAINT fk_mhgrggnsypidyaqephacydxekbyfhmusdale FOREIGN KEY ("stateId") REFERENCES public.commerce_states(id) ON DELETE SET NULL;


--
-- Name: commerce_subscriptions fk_mixoikxypmrrngeropmreetlnbwrkifwmcyc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_subscriptions
    ADD CONSTRAINT fk_mixoikxypmrrngeropmreetlnbwrkifwmcyc FOREIGN KEY ("planId") REFERENCES public.commerce_plans(id) ON DELETE RESTRICT;


--
-- Name: commerce_orderhistories fk_mnnwtyclnbeyymbbrbgpwcjwejmwehfcojko; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderhistories
    ADD CONSTRAINT fk_mnnwtyclnbeyymbbrbgpwcjwejmwehfcojko FOREIGN KEY ("customerId") REFERENCES public.commerce_customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_purchasables fk_mqawjvsalsbcmayqacqirtptgwrouwjhpwxq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_purchasables
    ADD CONSTRAINT fk_mqawjvsalsbcmayqacqirtptgwrouwjhpwxq FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_taxzone_countries fk_mxlrudcpixcgsyflxetuwopeepxkmgqvpmcy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_countries
    ADD CONSTRAINT fk_mxlrudcpixcgsyflxetuwopeepxkmgqvpmcy FOREIGN KEY ("countryId") REFERENCES public.commerce_countries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_customers_addresses fk_nfidazuslptrablqmxwbndiheprckmmsngkw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers_addresses
    ADD CONSTRAINT fk_nfidazuslptrablqmxwbndiheprckmmsngkw FOREIGN KEY ("customerId") REFERENCES public.commerce_customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_customer_discountuses fk_nfqgesvmmtnxyyuqioguemkrrgqlhatgpppz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customer_discountuses
    ADD CONSTRAINT fk_nfqgesvmmtnxyyuqioguemkrrgqlhatgpppz FOREIGN KEY ("customerId") REFERENCES public.commerce_customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_sale_usergroups fk_njednqwwqxpcsniopaavbtjudrqjaqylpoqf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_usergroups
    ADD CONSTRAINT fk_njednqwwqxpcsniopaavbtjudrqjaqylpoqf FOREIGN KEY ("userGroupId") REFERENCES public.usergroups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: changedfields fk_nrrdiueuhgzxtekzikcwrycymitvndawmdrd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_nrrdiueuhgzxtekzikcwrycymitvndawmdrd FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_shippingrules fk_nthunomqjpqrqpguyrwzzqcqczutsuuqrpdb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrules
    ADD CONSTRAINT fk_nthunomqjpqrqpguyrwzzqcqczutsuuqrpdb FOREIGN KEY ("methodId") REFERENCES public.commerce_shippingmethods(id);


--
-- Name: commerce_paymentsources fk_nynvvrshkdbeggkggxdiwdligxijmoemowcd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_paymentsources
    ADD CONSTRAINT fk_nynvvrshkdbeggkggxdiwdligxijmoemowcd FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sites fk_nzehdwtxfhfwsaqgynbygyjdfztgzllilhkd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT fk_nzehdwtxfhfwsaqgynbygyjdfztgzllilhkd FOREIGN KEY ("groupId") REFERENCES public.sitegroups(id) ON DELETE CASCADE;


--
-- Name: commerce_variants fk_nzhsulufsfbzxomrsmskpgkvpbsckcqfiuwj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_variants
    ADD CONSTRAINT fk_nzhsulufsfbzxomrsmskpgkvpbsckcqfiuwj FOREIGN KEY ("productId") REFERENCES public.commerce_products(id) ON DELETE SET NULL;


--
-- Name: commerce_discount_usergroups fk_obwtyrbtpzwectmtaobyqvqhjdvuxouyrcld; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_usergroups
    ADD CONSTRAINT fk_obwtyrbtpzwectmtaobyqvqhjdvuxouyrcld FOREIGN KEY ("discountId") REFERENCES public.commerce_discounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: globalsets fk_ogdylokqoylyddcujmdzakfzbrdzltuzpwrg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT fk_ogdylokqoylyddcujmdzakfzbrdzltuzpwrg FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_orders fk_ojrlnoxsziehjsxlwrfyysswfnbldhfmpoqb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_ojrlnoxsziehjsxlwrfyysswfnbldhfmpoqb FOREIGN KEY ("gatewayId") REFERENCES public.commerce_gateways(id) ON DELETE SET NULL;


--
-- Name: changedattributes fk_omfmbudyfyhvftclwrflvevjjjkhcajvreut; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_omfmbudyfyhvftclwrflvevjjjkhcajvreut FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_taxrates fk_oprsbrebmsbyxwzfbmmohkdpbsnazjtqmssl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxrates
    ADD CONSTRAINT fk_oprsbrebmsbyxwzfbmmohkdpbsnazjtqmssl FOREIGN KEY ("taxCategoryId") REFERENCES public.commerce_taxcategories(id) ON UPDATE CASCADE;


--
-- Name: globalsets fk_oryyniaekcvinsozexsabdwngvytgadnfzrq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT fk_oryyniaekcvinsozexsabdwngvytgadnfzrq FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: commerce_sale_purchasables fk_otgcmsyqrznnnqzfxzkmxmkccwvazkuxkmqs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_purchasables
    ADD CONSTRAINT fk_otgcmsyqrznnnqzfxzkmxmkccwvazkuxkmqs FOREIGN KEY ("purchasableId") REFERENCES public.commerce_purchasables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_customers fk_ouwsplykiudgkdumolgolgegmmrctnympzbo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers
    ADD CONSTRAINT fk_ouwsplykiudgkdumolgolgegmmrctnympzbo FOREIGN KEY ("primaryBillingAddressId") REFERENCES public.commerce_addresses(id) ON DELETE SET NULL;


--
-- Name: craftidtokens fk_ovytnsnwdcmjrzcsrifqhvorytvlyxvomilg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.craftidtokens
    ADD CONSTRAINT fk_ovytnsnwdcmjrzcsrifqhvorytvlyxvomilg FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: matrixblocks fk_owjzpiguwgikpjzveslrcyqvycbpnnykoomn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_owjzpiguwgikpjzveslrcyqvycbpnnykoomn FOREIGN KEY ("typeId") REFERENCES public.matrixblocktypes(id) ON DELETE CASCADE;


--
-- Name: changedattributes fk_oxxypvaalxiywstbnbodgcfcobscwijnbozl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_oxxypvaalxiywstbnbodgcfcobscwijnbozl FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: entries fk_pfhgrtmyuzovolnivsxpfuvaxjpudvdvyzrr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_pfhgrtmyuzovolnivsxpfuvaxjpudvdvyzrr FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: changedfields fk_phzzzasfcazktgobzsppyygcmhgpdhdetgdm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_phzzzasfcazktgobzsppyygcmhgpdhdetgdm FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: matrixblocktypes fk_pjmkygolxfdcvthjxrdjtluckbpoahtywwcx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT fk_pjmkygolxfdcvthjxrdjtluckbpoahtywwcx FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: commerce_products fk_poczrokpjiczhtbotqemlmqvacgeyvdbvfan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_products
    ADD CONSTRAINT fk_poczrokpjiczhtbotqemlmqvacgeyvdbvfan FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: sections_sites fk_ppbsgtvnlzvkcywesqzyqjpqwhesmgncihpy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT fk_ppbsgtvnlzvkcywesqzyqjpqwhesmgncihpy FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: commerce_producttypes_sites fk_psdzohfjqzxuhaguetanbqbgyasirdpdqnkg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_sites
    ADD CONSTRAINT fk_psdzohfjqzxuhaguetanbqbgyasirdpdqnkg FOREIGN KEY ("productTypeId") REFERENCES public.commerce_producttypes(id) ON DELETE CASCADE;


--
-- Name: relations fk_pypiirbrwykotzhvobizivhqzibzulyujadh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_pypiirbrwykotzhvobizivhqzibzulyujadh FOREIGN KEY ("sourceId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: entrytypes fk_qgjmuniermdubmgrusprqqasnpzccibdgnpg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT fk_qgjmuniermdubmgrusprqqasnpzccibdgnpg FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: commerce_sale_usergroups fk_qobbdlalhkyauyuuireriivjsncsbkrojxmf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_usergroups
    ADD CONSTRAINT fk_qobbdlalhkyauyuuireriivjsncsbkrojxmf FOREIGN KEY ("saleId") REFERENCES public.commerce_sales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: templatecaches fk_qphihgnecgrwdvxoffndjnquxntyauuowivq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecaches
    ADD CONSTRAINT fk_qphihgnecgrwdvxoffndjnquxntyauuowivq FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fields fk_qrbrttegfrazrbihemawpspoiodcjmrubdbr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fk_qrbrttegfrazrbihemawpspoiodcjmrubdbr FOREIGN KEY ("groupId") REFERENCES public.fieldgroups(id) ON DELETE CASCADE;


--
-- Name: commerce_discount_usergroups fk_qvjhtzohxnjjyuxvcukbdewlylpyvrhkzswb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_usergroups
    ADD CONSTRAINT fk_qvjhtzohxnjjyuxvcukbdewlylpyvrhkzswb FOREIGN KEY ("userGroupId") REFERENCES public.usergroups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_producttypes_shippingcategories fk_qvsjyqgsywqopnbhjkiwaqcbirehtcduyqna; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_shippingcategories
    ADD CONSTRAINT fk_qvsjyqgsywqopnbhjkiwaqcbirehtcduyqna FOREIGN KEY ("shippingCategoryId") REFERENCES public.commerce_shippingcategories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions fk_qzieetwqqbjjpexjonmghimgvzasqkjdrowg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT fk_qzieetwqqbjjpexjonmghimgvzasqkjdrowg FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: matrixblocks fk_rbpmceytubfouwgueqvpqixikrazlemtsleq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_rbpmceytubfouwgueqvpqixikrazlemtsleq FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: assets fk_rpnkophnczddnocvormwqkrdkfzuraszxdbx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_rpnkophnczddnocvormwqkrdkfzuraszxdbx FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_customers fk_rrwfcpbwiggmrpdwsjtohcftcygtdnevixcr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customers
    ADD CONSTRAINT fk_rrwfcpbwiggmrpdwsjtohcftcygtdnevixcr FOREIGN KEY ("primaryShippingAddressId") REFERENCES public.commerce_addresses(id) ON DELETE SET NULL;


--
-- Name: commerce_subscriptions fk_srtkisydkrdowzjgdsakxwivybiulteddvmw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_subscriptions
    ADD CONSTRAINT fk_srtkisydkrdowzjgdsakxwivybiulteddvmw FOREIGN KEY ("orderId") REFERENCES public.commerce_orders(id) ON DELETE SET NULL;


--
-- Name: usergroups_users fk_tblbjnbtkediapdbaztdebojofnkiretntvl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT fk_tblbjnbtkediapdbaztdebojofnkiretntvl FOREIGN KEY ("groupId") REFERENCES public.usergroups(id) ON DELETE CASCADE;


--
-- Name: commerce_emails fk_tdxdzebexebdjywgcpzbrsgkoxklmwfvdixl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_emails
    ADD CONSTRAINT fk_tdxdzebexebdjywgcpzbrsgkoxklmwfvdixl FOREIGN KEY ("pdfId") REFERENCES public.commerce_pdfs(id) ON DELETE SET NULL;


--
-- Name: commerce_producttypes_sites fk_tmybzuncpsjxptlncqcucyhvafdchaxrmvfo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_sites
    ADD CONSTRAINT fk_tmybzuncpsjxptlncqcucyhvafdchaxrmvfo FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_taxrates fk_tobrfkbgtqgzoexewtmqrtqaukcfpdyqdreo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxrates
    ADD CONSTRAINT fk_tobrfkbgtqgzoexewtmqrtqaukcfpdyqdreo FOREIGN KEY ("taxZoneId") REFERENCES public.commerce_taxzones(id) ON UPDATE CASCADE;


--
-- Name: commerce_discount_categories fk_txmojydogibkubdzxpjltpvcxidrqclafikq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_discount_categories
    ADD CONSTRAINT fk_txmojydogibkubdzxpjltpvcxidrqclafikq FOREIGN KEY ("discountId") REFERENCES public.commerce_discounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_orders fk_uacaclprlcoxnhmotwwrajyeesmwrunvfqyy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_uacaclprlcoxnhmotwwrajyeesmwrunvfqyy FOREIGN KEY ("shippingAddressId") REFERENCES public.commerce_addresses(id) ON DELETE SET NULL;


--
-- Name: userpermissions_users fk_uiymkzvvrmprdqgtznecusmojqkandzholai; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT fk_uiymkzvvrmprdqgtznecusmojqkandzholai FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: categories fk_ukpxsfnerzuibcpnlgxviuexctytfuupuhzt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_ukpxsfnerzuibcpnlgxviuexctytfuupuhzt FOREIGN KEY ("parentId") REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: assets fk_unkajiuadccacytxlgjabzfcqoksfwmojnnd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_unkajiuadccacytxlgjabzfcqoksfwmojnnd FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: categorygroups_sites fk_uqapugytroxucxuoajsjndcpdjcarlvevgdq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT fk_uqapugytroxucxuoajsjndcpdjcarlvevgdq FOREIGN KEY ("groupId") REFERENCES public.categorygroups(id) ON DELETE CASCADE;


--
-- Name: assetindexdata fk_usikblbmsghhumhrvtvseafvrrvmxhpzumpw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assetindexdata
    ADD CONSTRAINT fk_usikblbmsghhumhrvtvseafvrrvmxhpzumpw FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: commerce_subscriptions fk_uucznzsqflipvyewxtyczedkuwvxfbgzumls; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_subscriptions
    ADD CONSTRAINT fk_uucznzsqflipvyewxtyczedkuwvxfbgzumls FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: relations fk_uwspafvvdmapcpedznzpdhewdisftenrimqj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_uwspafvvdmapcpedznzpdhewdisftenrimqj FOREIGN KEY ("targetId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_shippingrule_categories fk_uzzvqfirraecrsjnwxdwsddtvovhtvmfxwbw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingrule_categories
    ADD CONSTRAINT fk_uzzvqfirraecrsjnwxdwsddtvovhtvmfxwbw FOREIGN KEY ("shippingCategoryId") REFERENCES public.commerce_shippingcategories(id) ON DELETE CASCADE;


--
-- Name: commerce_shippingzone_countries fk_vfcjzeigahwkcsdiznepaqgttswuaorjlxxz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_countries
    ADD CONSTRAINT fk_vfcjzeigahwkcsdiznepaqgttswuaorjlxxz FOREIGN KEY ("shippingZoneId") REFERENCES public.commerce_shippingzones(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: drafts fk_vjfzebffuevnmwcuftbrlessixdmxznqincq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT fk_vjfzebffuevnmwcuftbrlessixdmxznqincq FOREIGN KEY ("creatorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: commerce_paymentsources fk_vjgnsbcnqyitnmrzgjksudfzjulmpaptbyhw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_paymentsources
    ADD CONSTRAINT fk_vjgnsbcnqyitnmrzgjksudfzjulmpaptbyhw FOREIGN KEY ("gatewayId") REFERENCES public.commerce_gateways(id) ON DELETE CASCADE;


--
-- Name: gqltokens fk_vkvlviiwvndcsefqtzuoiqaryjgvzqjrxcun; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqltokens
    ADD CONSTRAINT fk_vkvlviiwvndcsefqtzuoiqaryjgvzqjrxcun FOREIGN KEY ("schemaId") REFERENCES public.gqlschemas(id) ON DELETE SET NULL;


--
-- Name: commerce_variants fk_vvcndfnmwagipzozjwgazahvitutucfzerhx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_variants
    ADD CONSTRAINT fk_vvcndfnmwagipzozjwgazahvitutucfzerhx FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: categories fk_vyjoaswidmyesgqpfcxcvrqglvuqxzhujqzu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_vyjoaswidmyesgqpfcxcvrqglvuqxzhujqzu FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_donations fk_wcgoomxirjhhtovawqvixbrlhtrpidilwoea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_donations
    ADD CONSTRAINT fk_wcgoomxirjhhtovawqvixbrlhtrpidilwoea FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_orders fk_wczcrgfcvdtvxiqcwbuqduiekbdepxlyelbg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_wczcrgfcvdtvxiqcwbuqduiekbdepxlyelbg FOREIGN KEY ("orderStatusId") REFERENCES public.commerce_orderstatuses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: changedfields fk_wdgjmspxcaguulajfwnpiiayweefcjntndff; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_wdgjmspxcaguulajfwnpiiayweefcjntndff FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_whftarriaittdruyuvtvaakunjwzayxatjwc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_whftarriaittdruyuvtvaakunjwzayxatjwc FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: commerce_transactions fk_wmxshmafawkzckrvtgsrmhcobolnlnxrongb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_transactions
    ADD CONSTRAINT fk_wmxshmafawkzckrvtgsrmhcobolnlnxrongb FOREIGN KEY ("parentId") REFERENCES public.commerce_transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_sale_categories fk_wngjmzrwdhmbwvvznsyffnmehiflagjtpweu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_sale_categories
    ADD CONSTRAINT fk_wngjmzrwdhmbwvvznsyffnmehiflagjtpweu FOREIGN KEY ("saleId") REFERENCES public.commerce_sales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_shippingzone_states fk_wphsueehprkhmyfdqxngaizfeuvmvmvouodl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_states
    ADD CONSTRAINT fk_wphsueehprkhmyfdqxngaizfeuvmvmvouodl FOREIGN KEY ("stateId") REFERENCES public.commerce_states(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_producttypes_taxcategories fk_wqcyyvjaffbvgbjyehhbeqcfemvggvorzclq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_producttypes_taxcategories
    ADD CONSTRAINT fk_wqcyyvjaffbvgbjyehhbeqcfemvggvorzclq FOREIGN KEY ("productTypeId") REFERENCES public.commerce_producttypes(id) ON DELETE CASCADE;


--
-- Name: commerce_customer_discountuses fk_wtryfwtrhislfmholtvytujqpcgmkvvstnun; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_customer_discountuses
    ADD CONSTRAINT fk_wtryfwtrhislfmholtvytujqpcgmkvvstnun FOREIGN KEY ("discountId") REFERENCES public.commerce_discounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: entries fk_wwkgjkrgpvwizznwnnewxkqffbxlvesyyarq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_wwkgjkrgpvwizznwnnewxkqffbxlvesyyarq FOREIGN KEY ("typeId") REFERENCES public.entrytypes(id) ON DELETE CASCADE;


--
-- Name: commerce_taxzone_countries fk_xseqvwupygzzlgyzidghtsbwlamffliidcpk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_countries
    ADD CONSTRAINT fk_xseqvwupygzzlgyzidghtsbwlamffliidcpk FOREIGN KEY ("taxZoneId") REFERENCES public.commerce_taxzones(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commerce_subscriptions fk_xtkmvflcclrxanaysntrvvhwldshliywgdbw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_subscriptions
    ADD CONSTRAINT fk_xtkmvflcclrxanaysntrvvhwldshliywgdbw FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: elements fk_xuaecucojibdspbhpblagfegjhmupsjsryam; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_xuaecucojibdspbhpblagfegjhmupsjsryam FOREIGN KEY ("draftId") REFERENCES public.drafts(id) ON DELETE CASCADE;


--
-- Name: elements_sites fk_yazgezehqickjsziauckasmcuawxugrtngma; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT fk_yazgezehqickjsziauckasmcuawxugrtngma FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_orders fk_yazytdfmchonrcycbcgihezkqnrosanusqai; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orders
    ADD CONSTRAINT fk_yazytdfmchonrcycbcgihezkqnrosanusqai FOREIGN KEY ("estimatedBillingAddressId") REFERENCES public.commerce_addresses(id) ON DELETE SET NULL;


--
-- Name: relations fk_ybetntyltxnhvzlvszelynyvomwezazlgdbs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_ybetntyltxnhvzlvszelynyvomwezazlgdbs FOREIGN KEY ("sourceSiteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: userpermissions_users fk_ycfpbpyxrjseuzhfwavvqdrhrqizgylimgjc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT fk_ycfpbpyxrjseuzhfwavvqdrhrqizgylimgjc FOREIGN KEY ("permissionId") REFERENCES public.userpermissions(id) ON DELETE CASCADE;


--
-- Name: structureelements fk_ycmfqrjvmukoeqemsuzdtxarsfbktxvdalkj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT fk_ycmfqrjvmukoeqemsuzdtxarsfbktxvdalkj FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: templatecacheelements fk_ydmzllmuzdeekqicibyduyatadmcibdeupiv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements
    ADD CONSTRAINT fk_ydmzllmuzdeekqicibyduyatadmcibdeupiv FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: commerce_shippingzone_countries fk_yfuwplypuzwybvggselnynigntfskklmwwwt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_shippingzone_countries
    ADD CONSTRAINT fk_yfuwplypuzwybvggselnynigntfskklmwwwt FOREIGN KEY ("countryId") REFERENCES public.commerce_countries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_yitauxmmtnuwiwvwzwqgwvxkvwzkbxqwwuzv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_yitauxmmtnuwiwvwzwqgwvxkvwzkbxqwwuzv FOREIGN KEY ("tabId") REFERENCES public.fieldlayouttabs(id) ON DELETE CASCADE;


--
-- Name: categorygroups fk_yolklpaershtaaglydqfjprdujlgpeehciwl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT fk_yolklpaershtaaglydqfjprdujlgpeehciwl FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE CASCADE;


--
-- Name: userpermissions_usergroups fk_yqulmbimpxudzmyrwaoegvybemclvkboyogy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT fk_yqulmbimpxudzmyrwaoegvybemclvkboyogy FOREIGN KEY ("groupId") REFERENCES public.usergroups(id) ON DELETE CASCADE;


--
-- Name: commerce_taxzone_states fk_ywbfahqrzqbtxhdndfmltmglvmomgplbjeqp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_taxzone_states
    ADD CONSTRAINT fk_ywbfahqrzqbtxhdndfmltmglvmomgplbjeqp FOREIGN KEY ("stateId") REFERENCES public.commerce_states(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: content fk_zfktpyropeyfmwjohmdnbncuptamnexjuelw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT fk_zfktpyropeyfmwjohmdnbncuptamnexjuelw FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: structureelements fk_zgcnsikamldxpcfakavjqxdepiimfvrylzbn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT fk_zgcnsikamldxpcfakavjqxdepiimfvrylzbn FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE CASCADE;


--
-- Name: fieldlayouttabs fk_zgmmkwatoyerbkmsbjqmbhmshbqkfxpsnknc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouttabs
    ADD CONSTRAINT fk_zgmmkwatoyerbkmsbjqmbhmshbqkfxpsnknc FOREIGN KEY ("layoutId") REFERENCES public.fieldlayouts(id) ON DELETE CASCADE;


--
-- Name: commerce_products fk_zhzomzhhqamzcudcgpyabwwqyasanhadcixx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_products
    ADD CONSTRAINT fk_zhzomzhhqamzcudcgpyabwwqyasanhadcixx FOREIGN KEY ("shippingCategoryId") REFERENCES public.commerce_shippingcategories(id);


--
-- Name: shunnedmessages fk_zmytnqzwxvwyxlalwmuzfihwzzfwiakuzkrw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shunnedmessages
    ADD CONSTRAINT fk_zmytnqzwxvwyxlalwmuzfihwzzfwiakuzkrw FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: commerce_orderhistories fk_zoqodqekmfnrxukizczvmkaspyrshlkxfjmx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commerce_orderhistories
    ADD CONSTRAINT fk_zoqodqekmfnrxukizczvmkaspyrshlkxfjmx FOREIGN KEY ("newStatusId") REFERENCES public.commerce_orderstatuses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

